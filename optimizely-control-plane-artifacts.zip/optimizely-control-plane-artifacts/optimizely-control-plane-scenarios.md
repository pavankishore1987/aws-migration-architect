# Optimizely Feature Flag Control Plane Scenarios

Working-session draft for Optimizely discussion

## Purpose

This document describes the target journey for a centralized SDLC control plane that integrates spec-driven development, LLM-assisted code generation, and Optimizely-based feature flag management.

The goal of the working session is to validate what Optimizely can support through APIs, what must remain manual or custom-built, and how our UI should manage flag creation, modification, promotion, release, rollback, and retirement across tenant-specific environments.

## Executive Summary

We are building a centralized UI for managing software delivery lifecycle activities across tenants. A tenant logs into the control plane, works through an SDD flow, and generates code that may require feature flags. The control plane should help create, reference, promote, activate, deactivate, and eventually retire those flags.

The expected release model is vertical-slice delivery. Large features are split into smaller production-safe slices. Code can be deployed through environments while release remains controlled by flags. Tenants can enable or disable flags in their own environments when they are ready to test or release.

The core question for Optimizely is: which parts of this lifecycle can be automated through Optimizely APIs, and which parts require custom UI, governance, approval, or operational controls outside Optimizely?

## Key Principles

1. Every large feature should be decomposed into smaller vertical slices.
2. Each vertical slice should be independently deployable and releasable through a feature flag.
3. Code promotion and feature release are related but separate lifecycle events.
4. Tenants should only manage flags for their own project and permitted environments.
5. Feature flags should support controlled rollout, shadow validation, live activation, rollback, kill switch behavior, and cleanup.
6. The UI should maintain audit evidence for who created, changed, promoted, enabled, disabled, or retired a flag.

## Actors

| Actor | Role |
| --- | --- |
| Tenant user | Creates features, tests flags, promotes releases, and requests production activation. |
| Control Plane UI | Centralized interface for SDD workflow, feature flag lifecycle, promotion, release, rollback, and governance. |
| SDD / LLM workflow | Generates specs, implementation plan, code changes, and feature-flag usage. |
| Feature Flag Service Adapter | Internal integration layer between the control plane and Optimizely APIs. |
| Optimizely | System of record or execution platform for feature flag configuration and evaluation. |
| CI/CD pipeline | Builds, tests, scans, deploys code, and emits deployment evidence. |
| Runtime services | Application services that evaluate flags and execute old or new behavior. |
| Governance / audit | Reviews ownership, approvals, expiry, cleanup, and operational evidence. |

## Proposed Environment Model

| Stage | Environments | Purpose | Flag Behavior |
| --- | --- | --- | --- |
| Lower environment validation | Dev, QA, UAT | Tenant validates the feature slice before production release. | Tenant can enable, disable, and test flags within permitted environments. |
| Production shadow validation | Shadow production | New code receives mirrored or parallel live traffic for validation. | Flag can be enabled in shadow without exposing behavior to live customers. |
| Production live release | Live production | Customer-facing release. | Flag controls actual exposure to production users. |
| Operational rollback | Live production | Reduce blast radius when an issue is detected. | Kill switch or release flag can be disabled quickly. |
| Governance cleanup | All environments | Remove stale temporary flags and preserve required permanent flags. | Release flags are retired after stabilization; permanent kill switches remain governed. |

## Tenant Isolation Model

Each tenant should have a clear mapping to its allowed Optimizely project, environments, flags, and permissions.

Open design question: should each tenant have a dedicated Optimizely project, or should tenants be isolated within a shared project using naming, audiences, permissions, and metadata?

Initial desired model:

1. Tenant logs into the centralized control plane.
2. Control plane resolves the tenant context.
3. Control plane shows only the tenant's flags, environments, releases, and approvals.
4. Tenant can create or modify flags only for authorized environments.
5. Production activation may require additional approval depending on governance policy.

## End-to-End Journey

```mermaid
flowchart TD
    A["Tenant logs into Control Plane UI"] --> B["SDD workflow creates feature slice"]
    B --> C["Flag strategy identified"]
    C --> D["Create or select feature flag"]
    D --> E["Generate code using flag"]
    E --> F["CI/CD deploys same codebase"]
    F --> G["Tenant validates by environment"]
    G --> H["Promote toward production"]
    H --> I["Shadow validation or live release"]
    I --> J["Monitor, rollback, or retire flag"]
```

## Scenario 1: Feature Flag Creation During SDD

### Intent

When the SDD workflow determines that a feature slice needs a release flag, the control plane should create the flag or request creation through an internal adapter.

### Scenario Steps

1. Tenant starts a new feature slice in the control plane.
2. Constitution or guardrail checks confirm the feature is small enough to be released independently.
3. SDD workflow generates or updates the spec and technical implementation plan.
4. SDD workflow identifies that a feature flag is needed.
5. Tenant reviews the proposed flag name, description, owner, environments, expiry, and type.
6. Control plane calls the Feature Flag Service Adapter.
7. Adapter attempts to create the flag in Optimizely or records a pending manual action if the API is unavailable.
8. SDD workflow uses the approved flag key in generated code.

### Diagram

```mermaid
sequenceDiagram
    participant Tenant
    participant UI as Control Plane UI
    participant SDD as SDD / LLM Workflow
    participant Adapter as Feature Flag Adapter
    participant Opt as Optimizely

    Tenant->>UI: Start feature slice
    UI->>SDD: Generate spec and implementation plan
    SDD-->>UI: Feature flag required
    UI->>Tenant: Review flag proposal
    Tenant->>UI: Approve flag creation
    UI->>Adapter: Create flag request
    Adapter->>Opt: Create or map flag
    Opt-->>Adapter: Flag result or unsupported API
    Adapter-->>UI: Flag key and status
    UI->>SDD: Use approved flag key in code
```

## Scenario 2: Code Generation and Deployment with Flag Usage

### Intent

The generated code should reference the approved flag key. The same codebase progresses through environments, but behavior is controlled by environment-specific flag values.

### Scenario Steps

1. SDD workflow generates code using the approved flag key.
2. CI/CD pipeline builds, tests, scans, and deploys the same codebase.
3. Runtime services evaluate the flag from the current environment.
4. Old or new behavior executes based on flag state.
5. Deployment evidence and flag usage evidence are stored for audit.

### Diagram

```mermaid
sequenceDiagram
    participant SDD as SDD / LLM Workflow
    participant Repo as Code Repository
    participant Pipe as CI/CD Pipeline
    participant Runtime as Runtime Service
    participant Opt as Optimizely
    participant Audit as Evidence Store

    SDD->>Repo: Commit code with flag key
    Repo->>Pipe: Trigger build and deployment
    Pipe->>Runtime: Deploy same codebase
    Runtime->>Opt: Evaluate flag for environment
    Opt-->>Runtime: Flag variation
    Runtime->>Audit: Emit deployment and flag evidence
```

## Scenario 3: Lower Environment Flag Promotion

### Intent

Tenants validate the feature across dev, QA, and UAT by enabling and disabling flags in their authorized environments.

### Scenario Steps

1. Code is deployed to dev.
2. Tenant enables the feature flag in dev.
3. Tenant validates the feature and records outcome.
4. If validation fails, tenant disables the flag and the team makes changes.
5. If validation passes, the flag configuration is promoted or recreated for QA.
6. The same pattern repeats for QA and UAT.
7. UAT approval becomes evidence for production readiness.

### Diagram

```mermaid
stateDiagram-v2
    [*] --> Dev
    Dev --> QA: Dev validation passed
    Dev --> Rework: Dev validation failed
    QA --> UAT: QA validation passed
    QA --> Rework: QA validation failed
    UAT --> ProdReady: UAT validation passed
    UAT --> Rework: UAT validation failed
    Rework --> Dev: Fix and redeploy
    ProdReady --> [*]
```

## Scenario 4: Production Shadow Validation

### Intent

Before exposing new behavior to live customers, the team may validate the new code in a shadow production environment using mirrored or parallel traffic.

### Scenario Steps

1. Same codebase is deployed to production shadow.
2. Shadow environment receives live-like traffic alongside current production.
3. New behavior runs behind a flag in shadow.
4. Metrics, logs, traces, and business outcome comparisons are collected.
5. If results are acceptable, tenant requests live production activation.
6. If results are not acceptable, flag remains disabled in live production and code changes continue.

### Diagram

```mermaid
flowchart TD
    A["Live production request"] --> B["Current production path"]
    A --> C["Shadow production path"]
    C --> D["New code behind flag"]
    D --> E["Compare technical and business outcomes"]
    E --> F{"Acceptable results?"}
    F -->|Yes| G["Request live activation"]
    F -->|No| H["Keep live flag off and rework"]
```

## Scenario 5: Live Production Release

### Intent

Once validation is complete, the tenant can release the feature by turning on the production flag according to the approved rollout policy.

### Scenario Steps

1. Tenant reviews production readiness evidence.
2. Required approver approves live activation.
3. Control plane updates the live production flag state or rollout rule.
4. Runtime services evaluate the updated flag state.
5. Control plane monitors technical and business metrics after release.
6. Tenant can continue rollout, pause rollout, or rollback.

### Diagram

```mermaid
sequenceDiagram
    participant Tenant
    participant UI as Control Plane UI
    participant Gov as Governance
    participant Adapter as Feature Flag Adapter
    participant Opt as Optimizely
    participant Runtime as Runtime Service

    Tenant->>UI: Request production release
    UI->>Gov: Check evidence and approvals
    Gov-->>UI: Approved
    UI->>Adapter: Enable production flag or rollout rule
    Adapter->>Opt: Update production flag state
    Runtime->>Opt: Evaluate production flag
    Opt-->>Runtime: New behavior enabled
```

## Scenario 6: Kill Switch and Emergency Rollback

### Intent

Some flags must remain permanent or long-lived as operational kill switches. If production issues are detected, the control plane should allow authorized users to disable behavior quickly and reduce blast radius.

### Scenario Steps

1. Monitoring detects an issue or tenant reports a problem.
2. Authorized user opens the live release in the control plane.
3. User clicks disable, rollback, or kill switch.
4. Control plane captures reason, approver, timestamp, and affected environments.
5. Control plane updates Optimizely through the adapter.
6. Runtime behavior returns to the safe path.
7. Incident evidence is linked to the flag event.

### Diagram

```mermaid
flowchart TD
    A["Production issue detected"] --> B["Authorized user opens flag"]
    B --> C["Disable flag or activate kill switch"]
    C --> D["Capture reason and approval evidence"]
    D --> E["Update Optimizely flag state"]
    E --> F["Runtime returns to safe behavior"]
    F --> G["Link event to incident and audit trail"]
```

## Scenario 7: Flag Governance and Cleanup

### Intent

Temporary release flags should not live forever. The control plane should identify stale flags, enforce ownership, and guide teams through cleanup.

### Scenario Steps

1. Each flag is created with owner, feature, tenant, environment scope, type, and expected expiry.
2. Control plane periodically identifies stale flags.
3. Tenant or owner receives cleanup task.
4. Team removes code branches guarded by stale release flags.
5. CI/CD verifies the cleanup.
6. Control plane retires or deletes the flag configuration.
7. Audit evidence is retained.

### Diagram

```mermaid
stateDiagram-v2
    [*] --> Proposed
    Proposed --> Active: Approved and created
    Active --> Promoted: Environment validation passed
    Promoted --> Released: Production enabled
    Released --> CleanupDue: Stabilization window reached
    CleanupDue --> Retired: Code and flag cleaned up
    Active --> Permanent: Classified as kill switch
    Permanent --> Reviewed: Periodic governance review
    Reviewed --> Permanent: Still required
    Retired --> [*]
```

## Flag Types

| Flag Type | Expected Lifetime | Purpose | Governance |
| --- | --- | --- | --- |
| Release flag | Temporary | Control release of a vertical feature slice. | Must have expiry and cleanup plan. |
| Operational kill switch | Long-lived or permanent | Quickly disable risky behavior in production. | Must have owner, review cadence, and incident playbook. |
| Experiment flag | Temporary | Compare variants or customer treatments. | Must have experiment owner and end criteria. |
| Permission or entitlement flag | Long-lived | Enable behavior for approved customer or tenant groups. | Must have strong access and audit controls. |

## Control Plane UI Capabilities

| Capability | Description |
| --- | --- |
| Tenant-scoped flag catalog | Show only flags owned by or visible to the logged-in tenant. |
| Create flag | Create a new flag from SDD workflow or manual UI request. |
| Modify flag metadata | Edit owner, description, expiry, linked spec, and governance fields. |
| Environment activation | Turn flags on or off in dev, QA, UAT, shadow, and live production based on permission. |
| Promotion workflow | Move flag readiness from dev to QA to UAT to production readiness. |
| Production release approval | Require evidence and approval before live production enablement. |
| Shadow validation | Enable and observe behavior in shadow production without live exposure. |
| Emergency rollback | Disable live behavior quickly with reason capture and audit evidence. |
| Cleanup workflow | Track stale flags, required code cleanup, and retirement. |
| Audit trail | Preserve who, what, when, why, and environment for each flag event. |

## Required API Capability Questions for Optimizely

### Project and Tenant Isolation

1. Can a project be created through API?
2. Can projects be mapped cleanly per tenant?
3. What permission model exists for restricting users to tenant-specific projects or environments?
4. Can custom metadata be stored for tenant id, feature id, spec id, owner, expiry, and governance status?

### Flag Creation and Modification

1. Can feature flags be created through API?
2. Can flag keys, names, descriptions, variables, rules, and variations be modified through API?
3. Can flag state be updated independently per environment?
4. Can the API support idempotent create or upsert behavior?
5. Can the API validate whether a flag key already exists before creation?

### Environment Promotion

1. Can a flag configuration be promoted from dev to QA to UAT?
2. If direct promotion is unavailable, can the configuration be read from one environment and recreated in another?
3. Can approvals or custom status be represented inside Optimizely, or must that live in our control plane?
4. Can rollout percentages, audiences, and rules be copied across environments?

### Production Release and Rollback

1. Can the API enable or disable a flag in production?
2. Can production changes require approval?
3. Can changes be scheduled?
4. Can emergency disable be executed with low latency?
5. Are there rate limits, propagation delays, or caching considerations that affect rollback?

### Shadow Testing

1. Does Optimizely support separate shadow environments as first-class environments?
2. Can shadow and live production use separate SDK keys or environment keys?
3. Can flag evaluation be isolated between shadow and live traffic?
4. Can events or metrics from shadow be separated from live production analytics?

### Audit and Governance

1. Does Optimizely provide audit logs through API?
2. Can we retrieve who changed a flag, when, and what changed?
3. Can stale flags be discovered through API?
4. Can flags be deleted, archived, or marked retired through API?
5. Can Optimizely emit events or webhooks when flags change?

## Decisions Needed

| Decision | Options | Recommendation for Discussion |
| --- | --- | --- |
| Tenant isolation | Project per tenant, shared project with metadata, or hybrid | Validate Optimizely limits and permission model before deciding. |
| System of record | Optimizely, control plane, or split ownership | Control plane likely owns workflow/audit; Optimizely owns runtime evaluation. |
| Promotion model | Native promotion, recreate configuration, or control-plane-managed status | Ask Optimizely what API supports. |
| Production activation | Tenant self-service, approval-gated, or operations-managed | Approval-gated for live production. |
| Kill switch model | Release flag reuse or dedicated operational flag | Dedicated operational flags for critical permanent controls. |
| Cleanup enforcement | Advisory reminders or hard governance gate | Hard gate for expired release flags after stabilization. |

## Proposed Working Session Agenda

1. Align on target journey and environment model.
2. Validate Optimizely project, environment, and permission capabilities.
3. Confirm API support for create, modify, promote, enable, disable, archive, and audit.
4. Identify gaps that require custom control-plane workflow.
5. Decide how shadow and live production environments should be represented.
6. Define next-step spike: API proof-of-concept, permission model, or UI workflow mock.

## Open Assumptions

1. The same codebase is deployed across environments, and runtime behavior is controlled through flags.
2. Tenants should not manage other tenants' flags.
3. Live production activation should be governed more strictly than lower environment activation.
4. Shadow validation should be isolated from live customer exposure.
5. Some flags are temporary release flags, while others are permanent operational controls.
6. The control plane may need to own workflow state even when Optimizely owns runtime flag evaluation.

## Desired Outcome From Optimizely

At the end of the discussion, we need a clear answer to:

1. Which lifecycle operations are supported through Optimizely APIs today?
2. Which operations require manual work, custom workflow, or a different product capability?
3. What tenant isolation model is recommended?
4. What environment model is recommended for dev, QA, UAT, shadow production, and live production?
5. What audit, governance, and rollback guarantees can Optimizely provide?
6. What proof-of-concept should we build next?

