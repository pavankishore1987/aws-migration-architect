# Optimizely Control Plane Scenario Diagrams

Use the SVG files for GitHub and editable documentation. Use the PNG files for slides, Word docs, or quick sharing.

## 1. End-to-End Journey

![End-to-End Journey](diagrams/svg/01-end-to-end-journey.svg)

## 2. Feature Flag Creation During SDD

![Feature Flag Creation During SDD](diagrams/svg/02-flag-creation-during-sdd.svg)

## 3. Code Deployment With Flag Usage

![Code Deployment With Flag Usage](diagrams/svg/03-code-deploy-flag-usage.svg)

## 4. Lower Environment Promotion

![Lower Environment Promotion](diagrams/svg/04-lower-environment-promotion.svg)

## 5. Production Shadow Validation

![Production Shadow Validation](diagrams/svg/05-production-shadow-validation.svg)

## 6. Live Production Release

![Live Production Release](diagrams/svg/06-live-production-release.svg)

## 7. Kill Switch and Emergency Rollback

![Kill Switch and Emergency Rollback](diagrams/svg/07-kill-switch-rollback.svg)

## 8. Flag Governance and Cleanup

![Flag Governance and Cleanup](diagrams/svg/08-flag-governance-cleanup.svg)
