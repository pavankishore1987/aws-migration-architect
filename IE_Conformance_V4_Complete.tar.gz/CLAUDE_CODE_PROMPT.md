# Prompt for Claude Code — I=E architecture and implementation PoC

Copy the following prompt to Claude Code at the root of the target repository. Place `CLAUDE_CONTEXT_PACK.md` and the architecture `README.md` in a separate handoff directory (e.g. `docs/ie-handoff/`) so they don't overwrite the existing project README. Adjust the paths if needed.

---

Act as a senior Java platform engineer working on the Intent = Execution (I=E) conformance framework for our customized OpenSpec lifecycle. Read `docs/ie-handoff/CLAUDE_CONTEXT_PACK.md` and `docs/ie-handoff/README.md` first. Treat those files as the target design, not proof that their example paths and APIs exist.

## Objective

Implement a repository-aligned, independently testable vertical slice of all three fail-closed conformance gates, their shared scoring and evaluator benchmarking, and the runtime invariant controls described in the V4 context. Start with Gate 1, then proceed through the implementation stages below. I want evidence of the actual implementation, not just a conceptual architecture or generated skill instructions.

## Non-negotiable placement

`propose-intent` captures/persists the exact original PRD/prose and creates draft `spec.md` and BPMN. The spec remains unfinalized at the end of that command. The first steps of `propose-design` ask clarification questions inside `spec.md`, accept answers, revise the spec, and obtain authorized final-spec approval. Reconcile BPMN with the final spec. **Run Gate 1 after these steps, inside `propose-design`, before technical design generation.** Gate 1 PASS alone (for the approved snapshot) authorizes generation of proposal/design/tasks. Gate 2 controls apply; Gate 3 controls downstream delivery after implementation/verify. FAIL and HUMAN REVIEW block. Do not move Gate 1 to the end of propose-intent. Do not depend on Claude memory to retrieve the PRD. Preserve original intent and explicit approved amendments; evaluate effective intent independently of the target spec.

## Step 1 — discover, then propose a repository-specific implementation plan

Inspect the repo read-only first. Run git status and preserve any existing changes. Locate OpenSpec configuration/templates, command/skill definitions, the exact spec approval and clarification mechanism, files that trigger design generation, BPMN validation and extraction tooling, Java/Graphite graph registration and tests, and any CI/hook/wrapper mechanisms. Identify relevant file paths and code references. Determine what is real, missing, or unknown; do not invent an API. Explain where a deterministic gate can interrupt the command and how to resume. Identify local vs authoritative enforcement; if the current harness cannot safely interrupt generation, propose splitting into protected phases under one command wrapper, rather than claiming prompt instructions enforce it.

Produce a concise plan with a file-level change list, interfaces, assumptions and tests. If a required business decision or risky/destructive change is necessary, stop for clarification before that change. Otherwise implement the small non-destructive PoC below, preserving existing behavior outside the new gate path. Do not commit, push, deploy, call production systems, expose secrets, or alter unrelated files.

## Step 2 — implement a thin vertical slice

- Persist original intent verbatim with change ID, source provenance and digest at propose-intent ingestion. Preserve the original baseline rather than rewriting it. Reuse the existing spec clarification/approval mechanism; capture accepted decisions and any explicit authorized supersession. Bind approval to exact spec revision.
- Establish the Gate 1 entry checkpoint after finalized/spec-approved readiness and synchronized BPMN, before design-generation tool execution. Capture a frozen snapshot. Add deterministic checks for readiness, artifact provenance, BPMN syntax and supported graph integrity; add an interface for semantic checks of effective intent → spec and spec → BPMN scenario coverage. If a real isolated semantic evaluator is not available, implement a clearly identified test fake and return HUMAN REVIEW in actual unsupported cases. Do not pretend a test mock is calibrated production validation.
- Implement shared finding and gate report contracts, policy engine, artifact hashes/provenance, PASS/FAIL/HUMAN REVIEW outcomes, block-by-default handling, and re-evaluation on changes. Make the design continuation depend on current PASS, not on the model interpreting a report. Include interfaces or minimal adapters for Gate 2 and Gate 3; clearly distinguish scaffolding from working functionality.
- Investigate whether an actual executable Graphite DAG can be exported safely. Prototype expected BPMN -> normalized workflow IR and actual executable workflow -> normalized IR with two-way node/edge comparison. Keep traceability tags but never use them as the sole actual graph source. Generate reconstructed BPMN only for visualization if feasible. If there is no trustworthy extractor, provide the adapter interface and documented blocker; do not invent executable graph evidence. Separate node semantic and invariant checks from topology.
- Add a synthetic demonstration fixture: initial intent requires approval-before-disbursement, user clarifies the exact approved state, approval is recorded, and final BPMN must preserve it. Test the valid path, stale BPMN after clarification, absent source PRD, stale approval, and a Java branch mutation with unchanged tags. Avoid production calls. Run existing unit/component tests relevant to the changes and all new tests.

## Step 3 — benchmark scaffolding and evidence

Create a minimal labeled benchmark manifest and runner for G1/G2/G3 using synthetic fixtures. Include expected verdict, workflow family, mutation ID, obligation ID, evidence, criticality, evaluator/config versions. Include valid equivalents and unresolved cases. Report gate-specific unsafe progression, critical escapes, false acceptance, false rejection, review/automation coverage, repeat stability, latency, and cost where measurable. Keep data splits by workflow family. Mark unmeasured metrics as unmeasured; do not invent benchmark results or statistical confidence. Confidence thresholds must remain provisional until labeled calibration and held-out measurement support them.

## Acceptance criteria

1. No design artifacts can be authorized by a draft or unapproved specification, by missing source intent, or by Gate 1 FAIL/REVIEW. Verify this with negative tests at the actual enforcement boundary; distinguish local protections from authoritative CI protections.
2. A spec-approved snapshot with legitimate clarified intent and consistent BPMN may receive PASS and continue design if all configured mandatory checks are satisfied. Changing a relevant artifact invalidates authorization. Unauthorized amendments, stale BPMN, and missing evidence never silently pass.
3. Report formats, evidence provenance and policy behavior are reusable at Gate 2 and Gate 3; neither can automatically pass missing mandatory checks.
4. Reverse extraction demonstrably compares actual executable control flow (not annotations alone), or limitations are reported and the gate remains unresolved. Show the branch mutation counterexample if extraction is feasible.
5. No silent bypass on timeout, malformed output, stale record, or direct protected invocation within the implemented trust boundary. Explicitly describe any remaining bypass surface.
6. Code and tests follow the project's existing build, conventions and dependency policies. No fabricated measurements, implementation status, or API names.

## Final deliverables

Return: (a) repository discovery results with actual file references, (b) architecture/ADR and phase sequence, (c) list of changed files and what each does, (d) exact build/test commands and observed results, (e) sample gate reports from the fixture, (f) a short reproducible demo runbook, (g) remaining blockers and rollout decisions. Separate implemented behavior, test stubs, proposed behavior, and deferred work. If real integration is blocked, deliver the independently testable PoC and the precise gap rather than making speculative changes.

---

## V4 implementation mandate — execute the staged prompt pack

The preceding instructions are the foundation, not the complete scope. Read `docs/ie-handoff/IMPLEMENTATION_SEQUENCE.md` and every numbered file under `docs/ie-handoff/prompts/`. Execute the eight stages in order, using actual repository conventions. At the end of each stage run its acceptance tests and update a durable local implementation status and evidence ledger. Continue through independent stages when a dependency is blocked; do not fabricate the missing capability or force a gate PASS. Stop for authorization only for sensitive data access, unapproved inference calls, destructive changes or material business policy decisions. All other safe local implementation can proceed.

Required additions beyond the initial thin slice:

- Implement a versioned obligation/dimension registry, evidence-backed findings, per-gate and per-dimension scores with explicit numerator/denominator, applicability and due-phase semantics, and deterministic non-compensatory decisions. Implement Gate 2 and Gate 3 adapters as working checks wherever repository evidence supports them; scaffold unsupported checks explicitly and fail closed.
- Implement the three overlapping invariant mechanism categories CODE, LLM_INFERENCE and DATA_DEPENDENT, and separate G3 enforcement-readiness from actual per-transaction satisfaction. Test schema resolution and approved as-of file binding, schema drift, actual inference output/evidence validation, deterministic runtime guard and side-effect prevention. No raw secrets or real data committed to Git. Real model calls require approved configuration.
- Implement both fixed-artifact gate benchmarks and actual end-to-end business authoring/transaction replay. Use a real authorized PRD, actual propose-intent/propose-design/apply/verify commands and newly generated code where available. Do not invent the domain or its requirements. Keep synthetic fixtures separate and record blocked real-data steps. Test as-of JIT schemas, nominal and adverse transactions, independent SME oracles and fresh worktrees; never bypass a blocked gate to collect downstream results.
- Measure artifact conformance, evaluator reliability, authoring effectiveness, runtime inference correctness, runtime invariant satisfaction, latency, token/cost and actual enforcement as defined by the context pack. Implement three-class confusion matrices, critical escapes, false acceptance/rejection, unsafe progression, defect precision/recall/F1, review and coverage, stability and confidence bounds. Compare one/two/three judge and adaptive configurations with the same held-out family partitions. Do not call a mock a benchmark of the real model.
- Implement empirical calibration with support counts and explicit UNCALIBRATED status, independent calibration/holdout partitions, threshold selection under agreed risk limits, and gate-level residual risk checks. Never average gate scores, treat model self-confidence as calibrated, or allow arbitrary score thresholds to compensate for mandatory failures.
- Produce versioned reports, exact test commands, actual results, a business demo runbook and remaining blockers. Distinguish implementing the benchmark machinery from successfully measuring or certifying it.

The context pack is authoritative for evaluation definitions. The numbered prompts add implementation detail; if an example conflicts with approved business policy or repository conventions, document the discrepancy and preserve the fail-closed semantics.


## V4 mandatory delivery — per-gate reporting and certification

Read `GATE_REPORTING_AND_BENCHMARK_CONTRACT.md` before implementing any stage. It is normative for gate timing, report layout, score denominators, execution statuses and benchmark isolation. Implement all acceptance tests there, not merely Markdown prototypes. The common engine must produce independent G1/G2/G3 conformance reports and blocking decisions on every reached attempt. In benchmark mode persist a separate expected-vs-actual case result at each reached gate and finalize separate aggregate G1/G2/G3 benchmark reports, matrices, metrics and calibration/certification results. Keep benchmark labels out of authoring and evaluation. Support ISOLATED_GATE and END_TO_END with distinct cohorts. Never bypass blockers; mark downstream NOT_EXECUTED without verdict/score. Track first attempt and remediation separately. Implement the reporting contract and examples, verify output counts and denominators with independent tests, and demonstrate gate-specific report files and actual deny/allow behavior. Compare the real generated workflow independently with original effective intent and runtime transaction oracles. Show where a missing SDK, real PRD, approved model or schema is blocking. Run stages sequentially with an implementation ledger; safe local implementation is authorized, production changes are not.
