# Implementation sequence and how to run it

Copy the contents of this archive into `docs/ie-handoff/` in the existing repository (do not overwrite its root README). Launch Claude Code from the repository root. Paste the instruction below, or use the master prompt directly. The numbered prompts can also be used one at a time in separate sessions; read the context and the latest implementation ledger first. These are prompts, not an installed Claude skill or working code.

> Read docs/ie-handoff/CLAUDE_CONTEXT_PACK.md, docs/ie-handoff/README.md, docs/ie-handoff/CLAUDE_CODE_PROMPT.md and docs/ie-handoff/IMPLEMENTATION_SEQUENCE.md. Follow the master prompt and the eight numbered implementation prompts in order. Implement and test the actual repository changes, preserving existing work. Record findings, metrics and evidence; do not merely generate a plan. Use only authorized local data and model endpoints. Never auto-approve a real business requirement, commit, push, or deploy.

| Stage | Prompt | Outcome |
|---|---|---|
| 0 | 00-discovery.md | Current-state map, supported constructs, enforcement boundary, input inventory |
| 1 | 01-scoring-and-policy.md | Reusable scoring, evidence, policy, report contracts |
| 2 | 02-intent-gate.md | Persisted intent, approval, Gate 1 inside propose-design |
| 3 | 03-design-implementation-gates.md | Gate 2 and Gate 3, true graph extraction |
| 4 | 04-runtime-invariants.md | Code, inference, JIT data and runtime control |
| 5 | 05-end-to-end-conformance-benchmark.md | Fixed fixtures plus actual fresh code generation and sandbox transaction replay |
| 6 | 06-metrics-and-calibration.md | Evaluation metrics, calibration, reproducible comparisons |
| 7 | 07-integration-and-demo.md | Negative enforcement tests and demonstration |

Use an implementation ledger (choose repo-appropriate path) with stage, status (IMPLEMENTED / PARTIAL / BLOCKED), changed files, command, actual outcome, evidence ref, missing dependencies, and next step. On a new session, read it before continuing. Keep artifacts or references access-controlled. The supplied diagrams are design references, not evidence from this repository.

Completion means code, independent tests, and truthful reports exist for each supported capability; an unsupported feature remains blocked/review, not a successful gate. Production thresholds and real data access require separate approval. Use a sandbox/worktree for experiments; no disabling production controls. Stage 6 is required even if there is insufficient data to estimate calibration: implement the calculation and report why the estimate is unavailable.


## V4 execution checklist

Read `GATE_REPORTING_AND_BENCHMARK_CONTRACT.md` before Stage 0. Stage 1 must implement a shared schema and deterministic policy; Stages 2–3 integrate report emission at each blocking boundary; Stage 5 builds isolated and sequential runners; Stage 6 computes three separate benchmark reports and calibration profiles per configuration; Stage 7 proves actual enforcement, missing report denial, NOT_EXECUTED and remediation tracking. Include both synthetic fixtures and authorized real PRD/code/transaction experiments where available. The consolidated dashboard is informational only.
