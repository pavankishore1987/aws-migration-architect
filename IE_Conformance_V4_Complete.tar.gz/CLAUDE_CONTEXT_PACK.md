# I=E conformance — repository implementation context

**V4 reporting requirement:** Each gate emits an independent conformance report, dimension scorecard and blocking verdict. During benchmarking each reached gate also emits an independent benchmark case result and gate-level aggregate report. See [Gate reporting and benchmark contract](GATE_REPORTING_AND_BENCHMARK_CONTRACT.md) for the authoritative execution, reporting, metrics and authorization rules.

Revision 3 | Handoff for Claude Code | Proposed architecture, not a claim of implemented capabilities

## What we are building

We are extending a customized OpenSpec spec-driven authoring flow running in the Claude Code CLI. OpenSpec supplies artifact templates and command instructions; Claude Code coordinates model/tool calls using command instructions, repository context, configuration, and guardrails. The target application is a Java-based business workflow engine (Graphite), with a process model expressed in BPMN XML. Conformance is an independent engineering control, not another authoring self-check. Each of three gates has a separate blocking decision. The full design, benchmark and trade-offs are in `README.md` in this handoff.

## Confirmed lifecycle (do not change the placement)

1. `propose-intent`: original PRD or prose is passed to this command only. It generates a DRAFT Gherkin-style `spec.md` and DRAFT BPMN. Capture exact original intent at ingestion and preserve provenance and business invariants. Do not reconstruct the PRD from the generated spec or rely on LLM memory.
2. `propose-design`, initial steps: continue authoring intent, ask clarifying questions in `spec.md`, accept human answers, revise the spec and obtain authorized user approval of the finalized spec. Reconcile BPMN to the finalized spec. Preserve the clarification and explicit amendment decisions; they supplement the PRD, rather than invisibly replacing it.
3. **Gate 1 is INSIDE `propose-design`, AFTER final spec approval and BPMN synchronization, BEFORE the technical design phase.** Do not put it after `propose-intent` or merely at the entrance or exit of `propose-design`. A draft is waiting for finalization, not an automatically approved or failed Gate 1. The design phase must remain unavailable while approval is missing or Gate 1 is unresolved.
4. On Gate 1 PASS, continue `propose-design` and generate `proposal.md`, `design.md`, `tasks.md` using the certified snapshot.
5. Gate 2 checks the design artifacts against the Gate 1-approved intent. PASS authorizes `apply`.
6. `apply` implements tasks in Java, runs unit and component tests, and iterates on feedback. `verify` validates authoring completion and consistency. Gate 3 independently evaluates the resulting implementation before protected downstream delivery.
7. FAIL and HUMAN REVIEW both block the relevant phase; remediation or adjudication must lead to a fresh decision. Gate records are independent and are not averaged across phases.

The exact installed command aliases (e.g. `/opsx:...`), skill files, approval marker, templates, graph APIs, hooks, build tool, artifact paths and CI controls have NOT been inspected here. Discover the real conventions rather than treating these conceptual names as repository facts.

## Source intent and evidence

The original PRD/prose should be captured verbatim in a change-scoped baseline such as `prd.md` (proposed name), along with referenced source file content where authorized. Capture digest, source, change identifier, and provenance; never overwrite the original silently. Protect source intent and approvals using the actual trust boundary. A hash alone is not an access control. Avoid storing sensitive data in a public repository. Keep clarification questions and answers in `spec.md` as currently intended; normalize a ledger from those sections or reuse existing metadata. Record question, answer, affected requirement, actor, decision status, and timestamp. Distinguish ordinary clarification from a scope change: contradictory requirements require explicit authorized amendment and precedence. Human approval must reference the specific final spec. Effective intent = original baseline + approved decisions. The target spec is not its own ground truth.

Conceptual state: DRAFT → CLARIFICATION_REQUIRED / UNDER_REVIEW → APPROVED → CONFORMANCE_PENDING → CONFORMANCE_PASSED; failures and human review block the protected continuation. Map to existing state conventions. If approved spec/effective intent changes, invalidate approval and dependent gate records; obtain new approval. If BPMN changes, invalidate affected gate results and require any artifact approval specified by policy. Resume only with current valid evidence and authorization.

## Gate obligations

| Gate | Structural / deterministic | Semantic / hybrid | Evidence and decision |
|---|---|---|---|
| G1 | Approval readiness, source snapshot/decision provenance, XML validity, supported BPMN constructs, reachability, edges, path extraction | Effective intent → spec completeness and soundness; clarified scenarios → BPMN; branch/gateway conditions; invariant coverage | Approved spec, reconciled BPMN and original PRD/decisions. Compare expected scenarios independently; avoid claim of exhaustive traces in loops/parallel flows. |
| G2 | Trace IDs, references, task mappings/dependencies | Design fidelity, scope, required tasks, testability, invariant strategy, errors/recovery | Gate 1 authorization + design artifact hashes. |
| G3 | Tag/ArchUnit traceability, extraction of effective Java DAG, normalized graph comparison | Node behavior, predicates, exception semantics, tests, runtime traces, invariant enforcement | Gate 2 authorization + source/build/configuration/test snapshot. |

## Gate 3: reverse extraction is required in the design direction

Tagging is traceability, not graph equivalence. Prefer an independent extractor of the actual executable Graphite registration/initialized workflow and its edges, conditions, gateway types and supported exception transitions. Initialize safely without business side effects. If unavailable, investigate Java AST/bytecode analysis or framework adapter. Do not regenerate the intended graph from the approved BPMN or from annotations alone. Normalize an expected IR parsed from BPMN and an actual IR extracted from executable Java. Preserve semantic distinctions (exclusive vs parallel, guards, default/exception flows, terminal outcomes), explicitly define allowable abstraction/normalization. Compare nodes and edges in both directions. Reconstructed BPMN is useful for visualization, not raw XML byte equality. Missing extraction evidence or unsupported dynamic routing requires review unless stronger evidence resolves it; a matching topology does not establish node semantics or universal invariant validity. Test behavior and side effects independently. Do not execute production workflows or access external systems for discovery.

## Evaluator contract and policy

An obligation is an independently verifiable requirement, scenario, graph property, or invariant. Give it a stable ID, source reference, gate, mandatory/advisory classification, acceptance condition, and evidence needs. Findings contain obligation ID, evaluator type/version, SATISFIED/VIOLATED/INCONCLUSIVE status, severity, source/target evidence references, counterexample if available, rationale and optional raw confidence. Gate runner is deterministic and loads frozen snapshots; structural checks first, semantic checks where needed, behavioral/invariant evidence. Author and judge contexts must be isolated. Judges do not see one another's initial results. A single validated counterexample outranks an unsubstantiated majority.

Scores for diagnostics: satisfied/applicable; resolved/applicable; unresolved/applicable. Graph node/edge recall = matched/expected; precision = matched/actual. Do not average these into a probability of correctness. For mandatory exact graph correspondence, require 100% subject to complete extraction and supported normalization. Confirmed mandatory violation -> FAIL. Missing or inconclusive material evidence, invalid approval, low calibrated confidence or material unresolved disagreement -> HUMAN REVIEW (or wait before gate readiness). All required obligations conclusively satisfied and approved policy met -> PASS. Human review is blocking; record resolution and rerun. Do not silently override mandatory violations. Use fail-closed deterministic policy for timeouts and malformed evaluator output.

## Benchmark and calibration

Create independently reviewed golden workflow families with original PRD, draft artifacts, clarifications/amendments, final approval, finalized spec/BPMN, design, Java and tests. Mutate one boundary at a time and label expected PASS/FAIL/REVIEW plus defect/obligation IDs. Include equivalent valid variations, genuine ambiguity, multiple defects, and real observed failures. Split development, calibration and held-out by workflow family; repeats are stability tests, not independent cases. Compare existing verify, deterministic only, one/two/three isolated judges, adaptive escalation, and G3 tagging-only vs reverse extraction. Do not assume three judges are best.

Metrics by gate: false acceptance (defective cases passed / defective cases), unsafe progression (expected FAIL or REVIEW passed / those cases), critical invariant escape, defect recall and precision, false rejection, review/automation coverage, stability, latency/cost and calibration. Empirical confidence requires labeled outcomes; judge agreement is not calibrated confidence. Choose thresholds on calibration data, check on held-out; separate gate-level risk from obligation-level confidence. With zero errors in n independent representative defective cases the one-sided 95% upper bound is 1−0.05^(1/n), approximately 3/n. A proposed exploratory corpus is 100 cases per gate (30 valid/50 defective/20 review), not production certification. Start in shadow mode with synthetic data; risk owners decide when authoritative blocking is justified.

## Required enforcement tests

- `propose-intent` produces drafts and durable original intent; it does NOT trigger Gate 1.
- Missing original PRD, unanswered blocking question, unapproved/stale spec: no technical design generation.
- Approved clarification changes a business condition: conformant updated spec/BPMN can pass; stale BPMN fails when mismatch is confirmed; unauthorized contradiction cannot pass.
- Gate 1 FAIL or HUMAN REVIEW prevents creation/update of protected proposal/design/tasks in the design phase. PASS for the exact snapshot permits it.
- Gate 2 FAIL or REVIEW prevents apply; Gate 3 FAIL or REVIEW prevents protected delivery.
- Missing or forged record, stale hashes, evaluator failure, direct invocation and resume/retry do not bypass controls.
- Gate 3 keep all tags but misroute a branch: structural FAIL from actual edge differences; graph-correct but wrong node behavior or invariant: separate FAIL; unsupported extraction: REVIEW.
- Legitimate approved amendments/equivalent implementation pass when all other requirements are met.

## Implementation constraints and unresolved decisions

Use current repo structure and tooling; preserve unrelated work. First inspect the existing command scripts, instructions, state/approval mechanism, BPMN tools, Java graph registration, tests and CI. Determine the enforcement mechanism that actually controls tool execution. A Markdown instruction alone cannot block arbitrary CLI file writes or direct invocation. A local wrapper/hook can coordinate phase transitions; authoritative merge/delivery needs protected enforcement outside agent control. Evidence artifacts and authorization must be bound to exact inputs, policy, evaluator and revision; prevent time-of-check/time-of-use mismatches. Prefer a narrow deterministic PoC before adding a large agent orchestration platform. No verified knowledge of Graphite internals or current command scaffold is implied by this pack.


## Evaluation specification — gate dimensions, scoring and runtime evidence (V4)

### 1. Three different things being evaluated

Do not conflate the authoring system's ability to generate a conformant artifact, the conformance evaluator's ability to detect defects, and the generated application's runtime behavior. Measure all three. A gate verdict applies to the exact artifact snapshot and the obligations due at that gate; it does not certify every future execution. Gate 1 still runs inside `propose-design` after the final spec approval and BPMN reconciliation. Gate 2 authorizes `apply`; Gate 3 authorizes protected delivery. Both FAIL and HUMAN_REVIEW block the corresponding next phase.

### 2. Gate-specific dimensions and evidence

Each row defines an evaluation dimension (not an arbitrary weight). Derive atomic obligations independently from the effective intent and applicable platform policy, then link each dimension to checks and evidence. Count each mandatory obligation once in the gate aggregate, even when several evaluators assess it. Report each dimension separately. Define mandatory/advisory status before running evaluation. A bidirectional mapping is required to detect both omissions and invented behavior. Human review is required for missing source truth, unsupported constructs, or genuinely unresolved semantic findings.

| ID / Gate | Dimension | Measure / evidence | Example defect |
|---|---|---|---|
| G1.1 | Intent baseline and approval integrity | Required baseline/clarification/approval checks satisfied; artifact hashes and authorization | Edited approved spec, missing PRD, unauthorized amendment |
| G1.2 | Requirement completeness | Satisfied source requirements / applicable approved source requirements; citations into spec | Dropped eligibility rule |
| G1.3 | Semantic correctness and scope soundness | Supported target obligations / applicable target obligations, with independent source evidence; contradictions and hallucinations counted | Reversed predicate, invented fee |
| G1.4 | Spec quality and testability | Valid required scenario fields / applicable fields; measurable acceptance criteria, explicit assumptions, unresolved blocking questions | Ambiguous threshold |
| G1.5 | BPMN structural integrity | XML/schema and graph checks, valid endpoints, reachability, supported gateways, loop/termination claims where supported | Dangling transition, disconnected node |
| G1.6 | BPMN semantic fidelity and path coverage | Mapped required scenarios / expected scenarios; guarded paths checked for intended and forbidden behaviors; independently derived expected scenarios | Missing reject branch or wrong gateway |
| G1.7 | Invariant capture | Correctly specified invariant obligations / approved invariant obligations; enforcement scope and data dependency defined | Missing invariant or unknown schema dependency glossed over |
| G2.1 | Requirement realization | Approved requirements satisfied by design / applicable requirements; source-to-design links and evidence | Design omits authorization |
| G2.2 | Design fidelity and cross-artifact consistency | Satisfied semantic constraints / applicable constraints; proposal/design/tasks consistent with spec and BPMN | Architecture contradicts retry semantics |
| G2.3 | Task coverage and dependencies | Required implementation/test work mapped / required work; invalid references and dependencies; not just checkbox count | Missing negative test |
| G2.4 | Technical feasibility and failure handling | Applicable platform/contract/error/recovery constraints satisfied; evidence from real SDK and dependencies | Unsupported Graphite construct |
| G2.5 | Invariant enforceability and test strategy | Invariants with sufficient enforcement, runtime decision point, evidence plan and failure action / applicable invariants | LLM controls irreversible side effect without guard |
| G2.6 | JIT input contract readiness | Required policies for schema acquisition, validation, compatibility, timing, trust and unavailable inputs satisfied | Missing policy for schema drift |
| G3.1 | Architectural traceability | Required business nodes mapped / required nodes; ArchUnit or equivalent checks | Missing node annotation |
| G3.2 | Structural/control-flow equivalence | Node/edge precision and recall, reachability, gateway/join/exception semantics from actual executable graph | All tags intact but wrong transition |
| G3.3 | Node/predicate semantic fidelity | Satisfied node behavior and guard obligations / applicable obligations; source/target evidence, tests | Reversed condition with correct topology |
| G3.4 | Behavioral scenario conformance | Expected business scenarios independently exercised / applicable scenarios; expected vs observed outcomes, traces, side effects; distinguish test coverage from test success | Happy-path-only testing, incorrect terminal state |
| G3.5 | Code-enforced invariant assurance | Required invariant implementation obligations satisfied; proof/static/transactional/test evidence as required | Duplicate disbursement, race |
| G3.6 | Inference-enforced invariant assurance | Runtime inference policy and guard integration verified; labeled inference cases measured for accuracy/recall/unsafe acceptance and evidence | Model accepts unsupported conclusion |
| G3.7 | Data/JIT-schema-dependent invariant assurance | Runtime adapter/contract/validation/evidence and failure behavior verified against representative snapshots, missing/stale/malformed/drift cases | Evaluates against stale file/schema |
| G3.8 | Verification and release evidence | Required tests executed and passed, exact source/build/config/model/policy provenance, no stale or bypassed authorizations | Changed implementation after PASS |

Do not count absence of an evaluator finding as conformance. For an inventory of expected paths, use bounded exploration or formal reachability/model checking appropriate to the supported BPMN subset; parallel interleavings and loops need an explicit bound or property-based reasoning. A path count without a trustworthy expected denominator is diagnostic only. For normalized graph comparisons, match transitions using identities, endpoints and supported transition semantics rather than merely matching source and target node pairs when multiple edges are possible. Compare against the actual executable definition with no dependency on the intended BPMN in the actual-graph extractor.

### 3. Invariant taxonomy: enforcement and evidence are separate axes

An invariant is a business property with a scope, trigger, predicate, required evidence and consequence when violated or unknown. The categories below are not mutually exclusive. A single invariant may need data acquisition, inference, and deterministic enforcement. Store the classification as two axes: `executionMechanisms` (CODE, LLM_INFERENCE, DATA_DEPENDENT; multiple allowed) and `evaluationMethods` (STATIC, DETERMINISTIC_TEST, FORMAL, SEMANTIC_JUDGE, LABELED_INFERENCE_EVAL, RUNTIME_TRACE, DATA_CONTRACT, HUMAN). Criticality and when the obligation is due (G1, G2, G3, RUNTIME) are independent attributes. Do not automatically use an LLM judge simply because a business action uses an LLM.

| Category | Gate 1 | Gate 2 | Gate 3 (pre-delivery) | Runtime |
|---|---|---|---|---|
| Code-enforced | Capture exact predicate and scope | Define guard, transaction boundary, recovery, tests | Verify actual enforcement; boundary, negative, failure, concurrency/property tests and stronger proof when required | Assert before side effects; audit violation; enforce atomicity/idempotency |
| LLM-inference-dependent | Identify semantic judgment and acceptable outputs, grounding and abstention expectations | Choose model/evidence/rubric, structured output, independent guard or human escalation | Benchmark actual inference and decision guard against SME labels, red-team and repeated trials; test malformed output/timeout | Validate output/evidence, apply calibrated policy and deterministic allow/deny/abstain guard before action |
| Data-dependent / just-in-time schema | Capture required facts, source/owner, timing, semantic field meaning and unknown behavior | Define schema acquisition/authorization, mapping, versions, validation, snapshot/freshness and compatibility policy | Test adapters with representative approved file snapshots, alternate schema versions and hostile/missing inputs; verify gating/instrumentation | Resolve approved file and schema as of transaction time; validate schema and data, evaluate predicate, bind finding to exact input/version; fail closed or route to review if unresolved |

Examples are illustrative; map to actual business transaction requirements instead of making up business policy. CODE: no transaction may commit twice for the same idempotency key. LLM_INFERENCE: a free-text reason must be supported by the supplied evidence under an approved rubric (a model's confidence alone is not evidence). DATA_DEPENDENT: a transaction must satisfy an eligibility/limit rule using the authoritative file and schema effective at the relevant instant. HYBRID: extract the relevant evidence with an LLM, validate against a trusted schema, and allow the transactional side effect only through a deterministic guard. An inherently semantic rule must not become a deterministic assertion merely because the LLM returns JSON.

**Data/JIT design:** Define a trusted schema resolver or contract (source, schema ID/version or digest, effective interval, semantic mapping, authorization) separately from raw file input. A schema inferred from a file/LLM is provisional until validated against approved semantics; validating against a self-invented schema is circular. For each transaction, capture `transactionId`, event time, source/locator and snapshot version or file digest, schema identity/digest, resolver version, freshness and validation outcomes, selected fields or redacted evidence refs, invariant ID, actual result and action. Keep raw sensitive data out of Git and prompts unless specifically authorized. Test syntactically valid but semantically wrong files, missing required fields, incompatible type/unit/effective-date changes, stale/late data, duplicates, corrupt files, schema/data mismatch, unavailable dependency, and unauthorized source. No silent defaults. For time-sensitive data or updates between validation and action, bind the decision to the exact snapshot and revalidate or use an atomic operation as required. Replay using the as-of snapshots rather than present-day values.

**Important lifecycle distinction:** Before release, G3 can assess that the runtime invariant enforcement mechanism is correctly implemented and validated using representative data and tests. It cannot assert satisfaction of an invariant for a future transaction whose real file or schema does not yet exist. Represent these as two linked obligations: the mandatory G3 `ENFORCEMENT_READINESS` obligation and the mandatory per-transaction `RUNTIME_SATISFACTION` obligation with a trigger and guard. The latter is not due at G3 only when the approved business policy permits deferral; it remains explicit in the report. If a file/schema is already required for G3 evidence, its absence is HUMAN_REVIEW. Do not mark it satisfied or simply omit it. A G3 PASS is not a runtime PASS. At runtime, only authorized PASS can enable the protected side effect; FAIL or HUMAN_REVIEW prevents it (or follows another explicitly authorized safe outcome), including missing schema, data or inference evidence. This is a runtime enforcement control in addition to the three authoring gates, not a relocation of Gate 3. If current scope does not permit runtime integration, report that gap and do not claim certification of runtime-dependent invariants.

### 4. Evaluation contracts and score calculation

Version a registry of `obligationId`, `gate`, `dimensionId`, `phaseDue`, `sourceRefs`, `criticality`, `mandatory`, `applicabilityRule`, `acceptancePredicate`, `executionMechanisms`, `evaluationMethods`, `evidenceRequirements`, `dependencies`, and `failureAction`. Evaluate applicability independently, and record justified NOT_APPLICABLE/NOT_DUE separately. An unclassified obligation cannot be silently dropped. Separate checks from obligations: multiple checks produce one consolidated obligation status using a predefined evidence policy. Findings contain status, check/evaluator/model/prompt versions, input and output evidence revisions, citations or counterexample, timestamp, and reason codes. Missing mandatory check or untrusted/incomplete evidence = INCONCLUSIVE unless another valid check conclusively establishes violation; a verified counterexample wins. Never count judge votes as separate obligations.

For each gate and dimension, let `N=S+V+U` applicable mandatory obligations due now; `S` satisfied, `V` confirmed violated, `U` inconclusive (including missing/unexecuted). Compute:

- confirmed conformance `C = S/N`; evidence coverage `E = (S+V)/N`; uncertainty `U/N`; violation rate `V/N`.
- trace/requirement recall `matched approved obligations / expected obligations`; precision `supported target obligations / target obligations`; use directional metrics where appropriate. Node/edge precision and recall use the same definitions on normalized graph entities.
- scenario coverage `distinct required scenarios exercised / required scenarios`; outcome success `scenarios with verified expected outcomes / exercised scenarios`. Report missing scenarios, forbidden-path counterexamples and runtime data/inference cases separately. Do not claim exhaustive coverage outside the supported domain/bounds.
- invariant enforcement coverage `verified mandatory enforcement-readiness obligations / applicable readiness obligations`; runtime satisfaction rate `satisfied due invariant instances / all due invariant instances`; also report runtime inconclusive and violations. Runtime denominator is invariant instances keyed by transaction ID and invariant ID, not number of source files or judge votes.
- Optional advisory or weighted diagnostic scores may be reported separately with versioned weights and rationale. Never use an aggregate to compensate for a mandatory failure. Zero denominator is N/A, never an automatic 100%; empty mandatory scope requires independently validated applicability. Do not average the three gate scores or interpret `C` as probability of correctness.

Gate policy (deterministic, versioned, independently testable): missing final approval means NOT_READY and design cannot begin. For a ready gate, confirmed mandatory violation -> FAIL; otherwise any mandatory obligation unresolved, evidence stale/untrusted, material disagreement unresolved, extraction incomplete, or applicable calibrated confidence policy unmet -> HUMAN_REVIEW; otherwise PASS when all mandatory obligations are satisfied and evidence/policy/authorization checks pass. Technical failures use explicit reason codes and block. Shadow verdicts are never release authorization. Human review needs auditable resolution and rerun; exceptions require an explicit separate authorized policy and cannot be a silent PASS. Record artifact/approval/policy hashes, applicable counts, dimension scorecard, unresolved obligations, semantic calibration support, verdict and action. Test decision table including 99% conformance with one critical failure, 100% reported satisfaction with an untrusted evidence dependency, N=0, duplicate checks and missing outputs.

### 5. Metrics to measure the evaluators, authoring pipeline and runtime inference

For the benchmark, use independently labeled obligations, defects and expected gate verdicts. Report raw numerator/denominator, confidence intervals where valid, and stratification by gate, dimension, severity, invariant category, model/config version, workflow family, complexity and schema/data version. Use positive = actual defect when computing detection precision/recall. Do not treat a REVIEW as a confirmed detection; distinguish it from prevention of unsafe progression. Report a three-class confusion matrix (expected vs actual PASS/FAIL/REVIEW) for each gate, plus separate NOT_READY/technical error counts if applicable.

| Metric | Definition |
|---|---|
| Gate error: false acceptance | Known nonconformant cases actually PASS / known nonconformant cases |
| Unsafe progression | Expected FAIL or REVIEW actually permitted to progress / expected FAIL or REVIEW cases; separately report unsafe PASS vs enforcement bypass |
| Critical escape | Critical-defective cases allowed / critical-defective cases; also report defects by invariant ID |
| False rejection | Expected PASS cases actually FAIL / expected PASS cases |
| Unnecessary review | Expected PASS cases reviewed / expected PASS cases |
| Defect precision, recall, F1 | TP/(TP+FP), TP/(TP+FN), 2PR/(P+R); match defects to labeled obligation IDs and evidence; unmatched findings are false positives after adjudication |
| Gate accuracy and automation | Correct three-way verdicts / labeled cases; definitive automated PASS or FAIL / eligible cases |
| Review rate and approved residual risk | REVIEW / eligible cases; defective PASS / all PASS (depends on sample prevalence) |
| Verdict stability | Same-case repeat agreement (report pairwise agreement or fraction all repeats identical and definition); inter-judge agreement reported separately |
| Calibration | Reliability plot by predicted-probability bin, observed correctness, sample counts, Brier score = mean((p-y)^2) for defined binary outcome, ECE = frequency-weighted absolute bin gap; gate-level PASS reliability separately |
| Runtime invariant enforcement | Actual violations blocked / known violating runtime events; violating events allowed / known violating events; due invariant instance completeness; unavailable-data and stale-schema rates; false blocks and runtime review |
| Runtime LLM inference | Class-wise precision/recall/F1 and confusion matrix on SME labels, abstention rate, evidence citation correctness/groundedness, unsafe inference acceptance, stability across repeats and model/prompt versions; numeric extraction exact/ tolerance match if applicable |
| Data/schema contracts | Schema retrieval success, required-field validity, freshness/compatibility compliance, mismatch detection recall, unavailable-source rate; separate business-data truth from schema validity |
| Authoring system | First-attempt gate pass rate, final pass rate after bounded remediation, requirement/defect counts by stage, clarification rounds, remediation attempts, generated tests vs independent oracle results, full-chain safe delivery rate |
| Operations | Evaluation and full-chain p50/p95 latency, token input/output, actual model/tool cost when available, timeout rate, human review effort; report runtime overhead separately |

An escaped defect at Gate 1 might cause Gate 2 and Gate 3 to agree with its incorrect spec. Test end-to-end against original effective intent, not only against the previous artifact. Report conditional performance among cases reaching each gate and separately isolated gate performance using valid frozen predecessor artifacts. Report blocked/not reached explicitly. A system that blocks everything has zero escapes but no useful automation, so report both risk and coverage.

### 6. Calibration and configuration selection

A score is not calibrated confidence. Compare current verify, deterministic only, deterministic + one isolated LLM judge, + two/+ three independent judges, and adaptive escalation. For G3 ablate tagging, reverse extraction, semantic and runtime checks. Use same frozen cases and versioned rubric for fairness. Judges see source, target and obligation evidence, not author history or other initial votes. Support findings with verifiable citations/counterexamples; unresolved disagreement routes to review. Never use the authoring model as the sole source of ground truth. Record raw judge signals, evidence completeness and observed outcome; initial empirical buckets may use agreement pattern, check family and evidence quality. An estimate of P(conclusion correct | evidence pattern) needs labeled calibration data; calibrate automatic PASS risk directly at gate level (or explicitly validate aggregation), not by averaging per-obligation probabilities. Distinguish runtime inference calibration from evaluator calibration and from authoring success. Use separate development, calibration and held-out workflow families (and tenant/time/schema versions where applicable); no label leakage or repeated cases counted as independent. Use prospective real prevalence to estimate approved residual risk; defect-rich tests estimate conditional detection, not deployment prevalence.

Choose policies on calibration data by minimizing review/cost subject to risk-owner-approved limits on critical escapes and false acceptance, then test untouched held-out cases. With zero observed false accepts in n independent representative known defective cases, the exact one-sided 95% upper error bound is `1 - 0.05^(1/n)` (approximately `3/n`); ~300 such cases bound error around 1%, not a guarantee. For nonzero errors use an appropriate interval; clustered mutations/repeats need dependence-aware analysis. Insufficient samples mean uncalibrated, not 100% confidence. Do not invent 90/95/98% thresholds; provisional policy may run in shadow/review only. Deterministic checks still need benchmarked correctness and coverage. Compare performance by dimension and risk stratum, not just pooled mean.

### 7. Real-world end-to-end conformance benchmark — two complementary tracks

The actual repository paths, data contracts and business rules have not been supplied to this handoff. Discover them in the authorized local repo or request the exact PRD, transaction samples, source files and JIT schema providers; do not invent domain requirements. Start with one real, approved, versioned business PRD and expand to multiple distinct workflow families. Use a sandbox/worktree and approved, de-identified representative transaction/file snapshots. Never run live financial operations, mutate production data, or upload proprietary PRDs/files to an unapproved model. If real inputs are unavailable, label synthetic substitutes and report the real-data track as blocked.

**Track A — isolated gate benchmark (fixed artifacts):** Obtain the real PRD and authorized clarifications and have business/engineering SMEs create a requirement/invariant oracle, scenario inputs, expected outputs and forbidden side effects independently of the generated files. Capture a clean reviewed artifact chain (including one or more valid alternative implementations), approval provenance and expected verdicts. Freeze it. For each gate inject a single known defect only in the target artifact, keeping prior artifacts and approvals valid as appropriate; label expected outcomes and target obligation IDs. Add combinations, equivalent refactors, genuinely unresolved inputs and naturally observed defects. Run evaluator configurations on the identical frozen cases. This isolates detection from generation quality. For G1 exercise mutations after finalization, ensure authorized approval references the intended test snapshot (or deliberately stale approval if that is the defect), and test clarified intent and BPMN synchronization. For G3 mutate actual executable transitions and node logic while keeping annotations intact; run independent behavioral tests, not only generated unit tests. Include schema/data and runtime-inference mutations, including failures with unchanged graph structure.

**Track B — end-to-end actual authoring (real PRD -> newly generated code -> sandbox execution):**

1. Capture exact authorized PRD bytes/prose, source commit, config, model/prompt version, workflow family and run ID. Preserve baseline independent of Claude memory. Store private evidence under approved access; commit only de-identified manifests/fixtures as allowed.
2. Run the actual customized `propose-intent` command to generate draft spec/BPMN. Use scripted SME-approved answers only for repeatability, while preserving the true clarification/approval boundary. No fake production authority; use a test approver in the sandbox.
3. Start actual `propose-design`, resolve questions and obtain approval of exact finalized spec, reconcile BPMN, run G1, capture findings, raw dimensions, verdict and enforcement trace. If blocked, record and stop for a first-attempt run. For remediation track, explicitly repair and rerun on a new snapshot. No force-pass to collect downstream data; use Track A for isolated downstream testing.
4. On G1 PASS generate actual proposal/design/tasks, then run G2; only pass may invoke actual `apply`. Measure newly generated Java and generated tests; run build, component tests and verify. Use independently authored scenario/invariant oracles, not just tests generated by the same agent. Run G3 with actual workflow extraction and reverse comparison, node semantics and enforcement-readiness checks.
5. If allowed in the sandbox, execute the generated workflow with real representative business transaction snapshots; resolve actual approved JIT schemas and files as of the transaction time (or replay versioned snapshots), invoke the real approved inference integration for inference-dependent cases, use safe stubs only for irreversible external actions, and capture execution traces, results and attempted side effects. Test both nominal and fault-injected input cases. Compare observations to the independent oracle. Confirm runtime FAIL/REVIEW blocks side effects. Distinguish actual inference, live-but-authorized data access, replay, and mocks in evidence. No production deployment.
6. Repeat using controlled versions and distinct run IDs in clean worktrees, keeping the oracle fixed and evaluator configurations recorded. Track first-attempt and final safe pass rates, variance, remediation cost and stage where defects originate/caught. Repeated generations from one PRD measure stochastic behavior, not independent population size. If model cannot be pinned exactly, record available identity and timestamp. Label natural defects through SME adjudication before scoring.
7. Compare pipeline with and without the new framework in an isolated shadow-only baseline (same input families/config where possible); never disable production controls. Compare overall safe delivery and actual defect escapes, not just gate decisions. Report blocked downstream stages and effect of review, cost and latency. Select a pilot subset with risk owner approval before rollout.

Minimum initial cases (adapt expected rules to the PRD): correct nominal flow; boundary condition and negative condition; clarified business rule; missing or invented requirement; correct alternative implementation; same tags but invalid edge; correct graph but wrong code predicate; missing invariant guard; duplicate/retry/concurrent request; inference supported vs unsupported evidence, ambiguity, malformed response and timeout; real file/schema version A and approved version B; missing/stale/incompatible file or schema; semantic field/unit mismatch; valid schema with invalid business data; unavailable runtime dependency; invalidation after source/approval/data changes. Include attempted production side effect simulation and assert no external call is made on FAIL/REVIEW. Plan at least a small pilot with one real approved PRD and multiple transaction fixtures; expand across families, data contracts and risk categories before calibration/certification. No sample counts presented as empirical results.

### 8. Evidence artifacts and reporting expected from implementation

Machine-readable artifacts (names conceptual; align with repo): `obligation-registry.json`, `gate-policy.yaml`, `dimension-metrics.json`, `gate-report.json`, `calibration-profile.json`, `benchmark-manifest.jsonl`, `benchmark-results.jsonl`, `runtime-invariant-results.jsonl`, aggregate CSV/Markdown scorecards and a reproducible command/runbook. Benchmark manifest fields: caseId, runId, familyId, gate or runtime phase, source/revision hashes, data/schema version IDs, expected verdict (or NOT_READY), expected defect IDs/criticality, oracle refs, injected/natural/control variant, actual evaluator profile, observed verdict, enforcement observation, duration/tokens/cost, evidence refs and adjudication. Keep labels inaccessible to evaluators. For each dimension emit applicable/satisfied/violated/inconclusive/not-due counts, value/numerator/denominator, status, evidence coverage, calibration status and reason codes. Show runtime readiness vs transaction satisfaction separately. Record actual observations only; absent metrics are UNMEASURED with reasons. Separate benchmark-run outcomes from gate-policy authorization and preserve exact artifact hashes. No fabricated results.

Illustrative scorecard: G3 has 40 due mandatory obligations, 38 satisfied, 1 confirmed code invariant violation, 1 inconclusive JIT adapter readiness. Conformance 38/40=95%, evidence coverage 39/40=97.5%, unresolved 1/40=2.5%, verdict FAIL, protected delivery blocked. Separately two future transaction properties are not due at G3 under an approved deferral policy; report them as runtime obligations, not as satisfied. If the violation were fixed while the required JIT readiness evidence remained missing, verdict HUMAN_REVIEW. With all due obligations and policy satisfied, G3 PASS only certifies the snapshot/readiness; a later transaction with a missing required schema is runtime REVIEW and cannot proceed through its protected action.


---

## V4 mandatory reporting and benchmark contract

This is the authoritative refinement to the prior I=E design. Apply it to Gate 1, Gate 2 and Gate 3 independently. A gate is an executable control, not a quality dashboard. The current artifact can progress only on a current, valid PASS issued by the gate policy and verified at the protected boundary. Benchmark results qualify the evaluator/configuration for use; they do not authorize an individual change. A benchmark case's expected label is never an input to the live evaluator or verdict engine.

## 1. Execution boundaries and report timing

| Gate | Trigger and inputs | Protected next phase |
|---|---|---|
| G1 | Inside propose-design, after human approval of finalized spec and reconciliation of BPMN. Original persisted PRD plus authorized clarifications/amendments, final spec/BPMN, approval provenance | Technical proposal/design/tasks generation within the same command |
| G2 | After technical design artifacts are generated; current G1 authorization and exact approved spec/BPMN, proposal/design/tasks | Apply / code generation |
| G3 | After actual Java implementation/build/test/verify; current upstream authorizations, approved artifacts, executable workflow and independent test evidence | Protected downstream delivery (e.g. CI release authorization, exact boundary to discover) |

At each reached gate, freeze input revisions, evaluate due obligations, aggregate evidence, calculate scores, resolve confidence and apply policy. Persist immutable attempt-specific findings, dimension scorecard and verdict atomically before issuing a PASS authorization. Record actual enforcement at the boundary, including rejected attempts. For benchmark runs, join the private expected label to the observed gate result only after the decision and record a case-level benchmark result immediately; update the gate-specific aggregate report for that run. Finalize it when that gate's benchmark batch completes. Do not delay normal gate authorization to compute aggregate benchmark statistics; a previously validated policy/profile or explicit pilot policy controls authorization. If reporting or authorization persistence fails, deny continuation. No cross-gate score or global verdict can override a blocked gate.

Execution status and verdict are separate. `NOT_EXECUTED` means an upstream block prevented entry; `NOT_READY` means the prerequisite/approval was absent at the attempted entry; neither is a conformance verdict. A started evaluator with missing evidence or technical failure yields HUMAN_REVIEW unless a confirmed mandatory violation establishes FAIL. Record the reason and deny progression. Human adjudication supplies evidence or approved requirement change and reruns; it is not an arbitrary override. Benchmark mode labels are `PASS`, `FAIL`, `HUMAN_REVIEW` on ready cases, with additional readiness/enforcement cases tracked separately. Persist downstream NOT_EXECUTED placeholders in the lifecycle ledger, not fake conformance scores or verdicts. Across remediation attempts preserve the first outcome and all subsequent results under distinct attempt IDs; do not overwrite failures.

## 2. Independent gate and end-to-end modes

**ISOLATED_GATE:** select a gate, freeze independently validated predecessor artifacts and approvals, inject or select known defects at the target gate. Run its actual evaluator + deterministic decision policy and exercise a test-only protected operation. The test harness may provision approved predecessor fixtures in an isolated worktree; it cannot disable or mint real production authorization. Compare with independently labeled obligations, expected verdict, required block/allow and forbidden effects. Generate a separate report for each gate even if another gate fails a different test. Positive cases must include equivalent representations/refactors. Negative cases include a single defect, combined defects and natural real authoring errors. Include unresolved/ambiguous cases, schema failures and technical errors.

**END_TO_END:** ingest a real authorized PRD; execute actual propose-intent, propose-design clarification/approval and G1, design and G2, apply/verify and G3 in sequence. No bypass. Record an independent case result at each reached gate; independently adjudicate whether each frozen output matches effective original intent (not merely its predecessor), including authoring errors propagated across gates. On block record downstream NOT_EXECUTED and reason. A remediation experiment uses a new attempt and rechecks affected approvals/revisions. After G3 PASS, execute newly generated code in a safe sandbox with authorized representative transaction/file snapshots, actual approved inference, as-of trusted JIT schema resolution and no irreversible effects. Capture runtime invariant instance results separately, not as a fourth authoring gate. If real data/model/SDK is unavailable, report BLOCKED and keep synthetic/mocked experiments distinct.

End-to-end results at G2/G3 are conditional on reaching that gate. Do not pool with isolated results for certification. Report both a progression funnel (eligible, reached, completed, pass, fail, review, not-ready, not-executed) and gate-local metrics. First-attempt and final-after-remediation are separate cohorts. Report counts of unique workflow families and repeated runs. Synthetic mutation clusters and repeated model calls are not independent population samples.

## 3. Mandatory output layout

Use equivalent paths in the actual repo; retain the following logical separations. Reports are run- and attempt-scoped; never overwrite. JSON is authoritative; Markdown is an accessible rendering. Access-controlled stores hold private data and evidence; Git stores only allowed redacted references.

```text
conformance/<change-id>/<run-id>/
  gate-1/<attempt-id>/{findings.json,evidence.json,dimension-scores.json,verdict.json,conformance-report.md}
  gate-2/<attempt-id>/{...same contract...}
  gate-3/<attempt-id>/{...same contract...}
  lifecycle-summary.json
benchmarks/<experiment-id>/<mode>/<evaluator-config-id>/
  gate-1/{case-results.jsonl,confusion-matrix.json,metrics.json,benchmark-report.md}
  gate-2/{...same contract...}
  gate-3/{...same contract...}
  progression-funnel.json  # end-to-end only
  runtime/{case-results.jsonl,metrics.json,report.md}  # if reached and authorized
  summary.md               # cross-gate visibility, not authorization
calibration/<gate>/<config-id>/<profile-version>/
  profile.json             # immutable validated profile, support counts, split IDs
  certification-report.md  # risk limits, uncertainty, coverage, held-out assessment
```

Authorization remains in the trusted policy/enforcement store, bound to gate, change/run/snapshot IDs, upstream verdict digests, approved inputs, policy/evaluator/config versions, scope and freshness; verify current hashes at use. Prevent TOCTOU using immutable snapshots/transactional checks. A mutable report file is not itself permission to proceed. Gate and benchmark service identities should be distinct; label store is unavailable to author/evaluator. Benchmark reports may link to the verdict digest; never write or mutate that verdict.

## 4. Metric contract per gate

For every metric return `{metricId, value, numerator, denominator, unit, status, reason, cohort, gate, dimension, configId}`. Use null/NOT_APPLICABLE for undefined zero-denominator metrics and null/UNMEASURED for unavailable data. Never substitute 0 or 100. For latency/quantile/calibration metrics include sample count and method instead of a misleading ratio. Each scorecard includes obligation counts S/V/U and not-due/not-applicable counts; deduplicate checks to one obligation. Define N=S+V+U for applicable due mandatory obligations; conformance=S/N, coverage=(S+V)/N. Report dimensions G1.1–G3.8 from the context and directional precision/recall for traceability, graph and coverage. Report invariant mechanism, evidence type and due phase separately. A missing required obligation must not vanish from N. The policy may use calibrated evidence reliability for probabilistic checks, but a confirmed mandatory violation always FAILs regardless of aggregate score or majority vote.

For each gate and each isolated or end-to-end cohort publish all of the following, including absolute counts:

| Metric | Numerator / denominator or definition |
|---|---|
| Three-way verdict matrix | Expected PASS/FAIL/HUMAN_REVIEW by actual PASS/FAIL/HUMAN_REVIEW on labeled ready completed cases; publish missing/error/not-ready counts outside matrix |
| False acceptance | Known FAIL cases receiving PASS / all known FAIL cases attempted (report technical/noncompleted counts and completed-only rate too) |
| Unsafe progression | Expected FAIL or HUMAN_REVIEW cases actually allowed / all expected FAIL or HUMAN_REVIEW cases attempted; separate wrong PASS from bypass |
| Critical escape | Known critical-defective cases actually allowed / known critical-defective cases attempted |
| False rejection | Expected PASS cases returning FAIL / expected PASS cases attempted |
| Unnecessary review | Expected PASS returning HUMAN_REVIEW / expected PASS attempted |
| Defect precision / recall / F1 | Match adjudicated findings to labeled defect IDs; TP/(TP+FP), TP/(TP+FN), harmonic mean; REVIEW is not defect detection by itself |
| Accuracy | Exact three-way matches / labeled ready completed cases; also report completion coverage |
| Automation / review | PASS or FAIL / ready attempted; HUMAN_REVIEW / ready attempted; report uncompleted separately |
| Stability | Same-case repeated verdict agreement (state definition), separate inter-judge agreement |
| Calibration | Gate-level automatic PASS correctness and risk bounds; reliability bins, support counts, Brier score and ECE for a defined probabilistic outcome; no probability when uncalibrated |
| Operational measures | p50/p95 latency, tokens, cost, human effort, evaluator errors, remediation; store observation count and provenance |

Break down by gate, dimension, defect type, severity, workflow family/complexity, invariant mechanism, schema/config version and real/synthetic/replay/mock provenance. Report per-gate and per-configuration certification separately from per-artifact verdict. Compare isolated configurations on same held-out cases, with independent development/calibration/holdout families. Set decision thresholds based on calibrated risk-coverage trade-off and approved false-acceptance/critical escape bounds. Report uncertainty and sample support; no invented thresholds or fake measured values. At runtime measure actual inference classification, grounding, abstention, contract/data quality and transaction-level invariant escapes separately from G3 readiness.

## 5. Worked illustrative case (not measured)

| Gate | Expected | Actual | Allowed? | Interpretation |
|---|---|---|---|---|
| G1, run A | PASS | PASS | Yes | approved spec and reconciled BPMN satisfy due checks |
| G2, run A | FAIL | FAIL | No | design omits mandatory idempotency guard, even if other 19/20 obligations satisfied |
| G3, run A | not reached | NOT_EXECUTED | No | do not count as correct verdict, or as a failed implementation |
| G3, isolated run B | FAIL | PASS | Yes (test stub) | all annotations intact, wrong executable edge escaped; unsafe progression and false acceptance increment |
| G3, isolated run C | PASS | PASS | Yes (test stub) | correct graph and all readiness obligations satisfied; future data-dependent properties still due at runtime |

No benchmark labels should be visible to the gate when it produces these outcomes. A G3 FAIL fixture in isolation uses a valid frozen G1/G2 predecessor. No actual delivery occurs in the test sandbox.

## 6. Required implementation acceptance tests

1. Each ready gate emits a complete conformance report and independent verdict with scores and validated evidence. Fixture expected PASS/FAIL/REVIEW for every gate. Gate 1 runs at the intra-command boundary, after spec approval; no premature design writes.
2. Benchmark runner emits case result per reached gate and separate aggregate G1/G2/G3 reports with the same metric definitions. Verify expected labels are excluded from evaluator context and reports cannot authorize delivery.
3. G1 FAIL and REVIEW block design; G2 blocks apply; G3 blocks delivery; timeouts, malformed output, report write failure, missing evidence and stale snapshot block. Test actual protected invocation including direct invocation within trust boundary. Record attempted vs allowed operations.
4. In end-to-end run, G1 FAIL -> G2/G3 NOT_EXECUTED; G2 FAIL -> G3 NOT_EXECUTED. No downstream phantom scores or labels in confusion matrix. Test pass-all run and blocker remediation under new attempt IDs. Validate all cohort denominators manually on a small known fixture.
5. Isolated G3 cases run independently using validated upstream fixtures regardless of failures in separate G1/G2 cases. Mutate actual executable graph while annotation tags remain correct; distinguish node semantics and runtime invariant checks.
6. Distinguish actual real code generation, representative transaction replay, approved real model inference and synthetic fakes. Missing JIT file/schema or ungrounded inference blocks the runtime action; future not-due properties do not count as satisfied at G3.
7. Calibration records are versioned per gate/config and benchmark cohort. A changed rubric/model/checker invalidates applicability until reviewed/revalidated. Uncalibrated semantic decisions requiring calibration cannot auto-pass production. Verify 99% conformance with a mandatory violation fails, unresolved obligations review, zero denominators nonnumeric, and audit trail reproducible.

## 7. Decisions still required from the repository and risk owners

Discover the actual Graphite executable DAG introspection API, supported BPMN subset, intra-command protection, CI trust boundary, approved models, real PRDs, transaction access, schema resolver, and independent SME oracle. Proposed layout and field names can adapt to existing conventions; semantic requirements and blocking boundaries cannot. Neither these design documents nor illustrative fixtures are empirical certification. Do not claim production readiness or implement live financial side effects.


## Visual references

- [Authoring lifecycle and independent reports](diagrams/lifecycle.svg)
- [Gate engine and reporting separation](diagrams/gate-reporting.svg)
- [Isolated vs sequential benchmark modes](diagrams/benchmark-modes.svg)
- [Reverse extraction](diagrams/round-trip.svg)
- [Runtime invariant checks](diagrams/runtime-invariants.svg)
