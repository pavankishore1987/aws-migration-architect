# Start implementing — I=E V4

Extract this package into `docs/ie-handoff/` in your existing repository (keep the repository itself as your working directory). The full package includes leadership decks; the implementation-only package omits decks. Start Claude Code in the repository root and paste the following prompt.

```text
Act as a senior Java platform engineer and AI evaluation architect. Read docs/ie-handoff/README.md, CLAUDE_CONTEXT_PACK.md, GATE_REPORTING_AND_BENCHMARK_CONTRACT.md, CLAUDE_CODE_PROMPT.md, IMPLEMENTATION_SEQUENCE.md and all numbered prompts under docs/ie-handoff/prompts/ (all paths relative to docs/ie-handoff). Follow the staged implementation instructions, starting with read-only repository discovery. Implement working components and independent tests, not just architecture prose. Preserve existing changes and record an implementation ledger with exact commands, observed results and blockers. Gate 1 must run inside propose-design after finalized spec approval and BPMN reconciliation. Each gate must independently emit a conformance report, dimension scorecard and blocking verdict; in benchmark mode emit its own benchmark report and metrics. Implement isolated gate and strict sequential end-to-end benchmarking with NOT_EXECUTED downstream when blocked. Include Java-to-workflow reverse extraction, code/inference/JIT data invariant verification and independent calibration. Do not fabricate repository APIs, real PRDs, transaction data or measurements. Do not commit, push, deploy or execute irreversible effects. Use authorized models and data only. Continue safe local stages and report unresolved dependencies.
```

## What to implement first

Stage 0 inventory actual hooks, paths and boundaries. Stage 1 common score/report/policy contract and unit tests. Stage 2 wire Gate 1 using persisted intent. Stage 3 wire Gate 2/3 and actual graph extraction. Stage 4 implement invariant checks. Stages 5–6 build and measure independent gate and end-to-end benchmarks. Stage 7 prove real enforcement and demo. `examples/` contains deliberately hypothetical contract outputs for math tests, not real data. All production thresholds and integrations remain subject to discovery and approval.

V4 supersedes earlier handoffs; no presumed business acronym or domain is required.
