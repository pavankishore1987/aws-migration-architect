# I=E Conformance — Leadership presentation (V7)

**15 slides** · Architecture proposal · All example results are illustrative.

[PowerPoint](IE_Conformance_Runtime_Leadership_V7.pptx) · [PDF](IE_Conformance_Runtime_Leadership_V7.pdf) · [Back to architecture](../README.md) · [Meeting script](../TEAM_MEETING_SCRIPT.md)

This GitHub-friendly edition includes the original monochrome slide images and searchable slide text and speaker notes. GitHub renders the Markdown as a scrolling page; use the PowerPoint or PDF for full-screen presentation.

## Contents

[01. Conformance in the agentic authoring loop](#slide-01)  

[02. Static correspondence is not enough](#slide-02)  

[03. Why conformance if OpenSpec already verifies?](#slide-03)  

[04. The gates follow artifact maturity, not command boundaries](#slide-04)  

[05. Conformance becomes a tool-backed feedback loop](#slide-05)  

[06. Compare the approved model and observed execution](#slide-06)  

[07. Protect the transaction when its actual data arrives](#slide-07)  

[08. Benchmark and report each gate independently](#slide-08)  

[09. Where the measurements come from](#slide-09)  

[10. What is a score and what makes a gate pass?](#slide-10)  

[11. How we establish that the gate is trustworthy](#slide-11)  

[12. A defect the existing checks can miss](#slide-12)  

[13. Make evidence retrieval a contract, not a prompt](#slide-13)  

[14. Why these controls, rather than more AI review?](#slide-14)  

[15. Propose a narrow PoC before expanding scope](#slide-15)  


---

<a id="slide-01"></a>

## 01. Conformance in the agentic authoring loop

![Conformance in the agentic authoring loop](previews/leadership/slide-01.png)

<details>
<summary>Slide text and speaker notes</summary>


INTENT = EXECUTION  /  ARCHITECTURE PROPOSAL


Conformance in the
agentic authoring loop


From approved business intent to executable behavior, independent gate decisions and runtime evidence.


Leadership discussion  •  concise decision deck


V7 proposal  |  Runtime, evidence and gate measurement


**Speaker notes**


This is a proposed architecture. Runtime APIs, hooks and numerical thresholds require repository discovery and validation. The deck expands V4 without replacing its three independent gates.


</details>


---

<a id="slide-02"></a>

## 02. Static correspondence is not enough

![Static correspondence is not enough](previews/leadership/slide-02.png)

<details>
<summary>Slide text and speaker notes</summary>


WHY CHANGE


Static correspondence is not enough


We can generate an implementation with all the correct node tags while still executing the wrong branch, violating a business invariant or exceeding an agreed runtime deadline.


2


Current assurance


Intent, design, structural and semantic verification at three blocking gates.


Proposed addition


Execute actual generated code, capture independent evidence and feed actionable findings into the agentic authoring loop.


Keep the gates. Strengthen the evidence that supports their decisions.


**Speaker notes**


We can generate an implementation with all the correct node tags while still executing the wrong branch, violating a business invariant or exceeding an agreed runtime deadline.


</details>


---

<a id="slide-03"></a>

## 03. Why conformance if OpenSpec already verifies?

![Why conformance if OpenSpec already verifies?](previews/leadership/slide-03.png)

<details>
<summary>Slide text and speaker notes</summary>


OPENSPEC CAPABILITY ASSESSMENT


Why conformance if OpenSpec already verifies?


OpenSpec already validates artifacts and verifies implementation completeness, correctness and coherence. We should reuse those capabilities rather than recreate them.


3


What we reuse


Native Validate and Verify findings.
Existing tests and task/requirement mappings.
Current authoring commands and harness.


What we add where justified


Original intent provenance and BPMN ↔ Java graph comparison.
Independent execution/invariant evidence and runtime limits.
Gate certification, calibrated risk and blocking authorization.


Prove the incremental benefit against our actual OpenSpec baseline.


**Speaker notes**


The comparison is against upstream capabilities and must be verified against the installed customized version. Native verification may detect examples; do not claim it cannot. We propose a paired benchmark and enforcement tests to establish incremental benefit.


</details>


---

<a id="slide-04"></a>

## 04. The gates follow artifact maturity, not command boundaries

![The gates follow artifact maturity, not command boundaries](previews/leadership/slide-04.png)

<details>
<summary>Slide text and speaker notes</summary>


LIFECYCLE


The gates follow artifact maturity, not command boundaries


Gate 1 is inside propose-design. A human-approved spec is necessary, but conformance authorization is still required.


4


PRD


Persist baseline


Propose intent


Draft spec / BPMN


PROPOSE DESIGN  |  same command, two phases


Finalize intent


Clarify, approve, reconcile


Gate 1


Intent verdict


Generate design


Proposal / design / tasks


Gate 2


Design verdict


Apply / Verify


Build, execute, test


Gate 3


Code verdict


Delivery / runtime


Authorize release; protect actual effects


Every gate issues PASS, FAIL or HUMAN REVIEW. Only a current PASS permits the protected next phase.


**Speaker notes**


Describe the command boundaries carefully. The original PRD is immutable; authorized clarifications supplement it. Gate 2 protects Apply and Gate 3 protects delivery. Runtime controls are separate from these authoring gates.


</details>


---

<a id="slide-05"></a>

## 05. Conformance becomes a tool-backed feedback loop

![Conformance becomes a tool-backed feedback loop](previews/leadership/slide-05.png)

<details>
<summary>Slide text and speaker notes</summary>


AGENT INTEGRATION


Conformance becomes a tool-backed feedback loop


The authoring agent can repair an artifact, but it cannot declare its own work conformant or authorize progression.


5


Agent authoring


Read, plan, write, test


Freeze candidate


Hash artifact + evidence


Conformance tool


Run due obligations


Policy engine


Persist result; decide


PASS


Verify authorization


FAIL


Bounded repair plan


HUMAN REVIEW


Suspend; obtain evidence


No automatic override; budget exhaustion blocks.


**Speaker notes**


A validator can be deterministic or invoke independent judges. The external orchestrator owns state, budget, permissions and gate approval. Hooks can notify or intercept, but prompt prose alone cannot enforce a trust boundary.


</details>


---

<a id="slide-06"></a>

## 06. Compare the approved model and observed execution

![Compare the approved model and observed execution](previews/leadership/slide-06.png)

<details>
<summary>Slide text and speaker notes</summary>


GATE 3


Compare the approved model and observed execution


Derive the expected and actual workflow independently. A matching graph is necessary for exact correspondence, but does not prove node behavior or timing.


6


Approved BPMN


Parse expected graph


Built Java / Graphite


Extract actual graph


Graph comparison


Normalized expected vs actual IR. Compare nodes, edges, branch and join semantics.


Structural findings


Missing / extra nodes, edges, unsupported constructs


Behavioral findings


Execute code; compare traces, effects, timing to oracle


Combine the independent findings with semantic and invariant evidence → Gate 3 verdict.


**Speaker notes**


Read the approved BPMN only for expected evidence. Extract actual edges from the initialized executable Java workflow; do not reconstruct from annotations or expected XML. Execute the built candidate against independent scenarios. The conformance policy combines all due findings.


</details>


---

<a id="slide-07"></a>

## 07. Protect the transaction when its actual data arrives

![Protect the transaction when its actual data arrives](previews/leadership/slide-07.png)

<details>
<summary>Slide text and speaker notes</summary>


RUNTIME


Protect the transaction when its actual data arrives


Gate 3 proves enforcement readiness to the required evidence standard; live guards check actual inputs and decisions.


7


Actual transaction


File, data and schema


Code + inference


Validate due obligations


Effect guard


Deterministic decision


Protected action


Allow or block / review


Timing


Workflow and node elapsed time, inference latency, retries, deadline and workload context.


Safety


Unknown or stale evidence blocks the protected action. Test with approved representative replay data.


Runtime transaction enforcement is separate from the three authoring gates.


**Speaker notes**


Gate 3 proves enforcement readiness to the required evidence standard; live guards check actual inputs and decisions.


</details>


---

<a id="slide-08"></a>

## 08. Benchmark and report each gate independently

![Benchmark and report each gate independently](previews/leadership/slide-08.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT


Benchmark and report each gate independently


Run isolated gate tests and real end-to-end authoring. Do not let passing averages hide mandatory violations.


8


Gate


What is tested


Report


Gate 1


Approved intent, spec/BPMN, scenarios and invariants


Own scores and verdict


Gate 2


Design, tasks, runtime guards and timing design


Own scores and verdict


Gate 3


Actual graph, behavior, runtime evidence and readiness


Own scores and verdict


Benchmark


Known defects, real PRDs, generated code, actual authorization


G1 / G2 / G3 reports


Benchmark measures false acceptance, critical escapes, review, latency and cost; blocked downstream = NOT_EXECUTED.


**Speaker notes**


Run isolated gate tests and real end-to-end authoring. Do not let passing averages hide mandatory violations.


</details>


---

<a id="slide-09"></a>

## 09. Where the measurements come from

![Where the measurements come from](previews/leadership/slide-09.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE COLLECTION


Where the measurements come from


The authoring agent is not the source of truth. Independent collectors obtain approved inputs, executable behavior and the observations needed for each gate.


9


Intent and artifacts


PRD, approvals, BPMN, design, Java snapshot


Actual execution


Independent tests, node traces, timing and side effects


Runtime context


Inference, actual files, resolved schema and guard outcomes


Independent gate report


Evidence references, dimension scores, unresolved findings, verdict and enforcement


Collect once, evaluate independently, and bind each decision to the artifact revision.


**Speaker notes**


Use artifact hashes, approved clarification provenance, initialized graph export, independent test execution, traces and monotonic elapsed times. Runtime data/schema may not exist during authoring, so Gate 3 checks enforcement readiness. Actual accuracy or defect recall requires labeled ground truth. Report timing only against an approved constraint.


</details>


---

<a id="slide-10"></a>

## 10. What is a score and what makes a gate pass?

![What is a score and what makes a gate pass?](previews/leadership/slide-10.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT


What is a score and what makes a gate pass?


The PRD and approved clarifications define atomic obligations. Evidence and explicit criteria determine whether each is satisfied, violated or unresolved.


10


48 / 50


Satisfied → 96% conformance


49 / 50


Conclusive → 98% coverage


1


Mandatory violation → FAIL


Collect the original intent, artifact snapshots, graph mappings and actual execution evidence. A deterministic policy engine aggregates findings. Confidence comes from separately benchmarked evaluator reliability.


Illustrative scorecard; one mandatory violation blocks regardless of the aggregate.


**Speaker notes**


Illustration uses 50 mandatory obligations. One violation and one unresolved obligation. 48/50 = 96%; conclusive evidence 49/50 = 98%. Mandatory violation blocks despite score. Calibrated confidence is learned from labeled benchmarks, not judge self-confidence. Only current PASS authorizes next phase.


</details>


---

<a id="slide-11"></a>

## 11. How we establish that the gate is trustworthy

![How we establish that the gate is trustworthy](previews/leadership/slide-11.png)

<details>
<summary>Slide text and speaker notes</summary>


BENCHMARK AND CALIBRATION


How we establish that the gate is trustworthy


Test the evaluator independently from the authoring agent. Then test the entire lifecycle on real PRDs and executed code, without bypassing upstream gates.


11


Ground truth


Real PRDs, validated artifacts and injected defects


Run gates


Independent expected vs actual outcomes


Qualify policy


Risk bounds, automation coverage, cost and latency


Report Gate 1, Gate 2 and Gate 3 separately. Compare against native OpenSpec on identical cases; measure unique additional defects and overhead. Use strict sequential execution to establish real authoring effectiveness.


Thresholds and evaluator count are experimental decisions, not predetermined.


**Speaker notes**


Isolated gates use known defects, compliant alternatives and ambiguous cases. Independent SMEs and tests supply labels, kept out of model context. Split workflows across development/calibration/held-out; report independent false acceptance, critical escapes, review rate, timing and cost. No arbitrary 98% threshold or fixed number of LLMs. Example stats are not measured.


</details>


---

<a id="slide-12"></a>

## 12. A defect the existing checks can miss

![A defect the existing checks can miss](previews/leadership/slide-12.png)

<details>
<summary>Slide text and speaker notes</summary>


DEMO


A defect the existing checks can miss


Illustrative approval workflow: a Java node is correctly tagged, but the executable edge routes an ineligible applicant to approval.


12


Before


All declared node IDs are present. The generated code compiles; superficial mapping checks pass.
The incorrect transition remains undetected.


With the proposed design


Reverse extraction identifies the wrong edge; sandbox execution reproduces the forbidden approval.
Gate 3 returns FAIL; agent repairs and re-runs under a new attempt. No delivery until PASS.


Add a retry/duplicate-effect test and an invariant requiring JIT evidence to demonstrate runtime protection.


**Speaker notes**


Illustrative approval workflow: a Java node is correctly tagged, but the executable edge routes an ineligible applicant to approval.


</details>


---

<a id="slide-13"></a>

## 13. Make evidence retrieval a contract, not a prompt

![Make evidence retrieval a contract, not a prompt](previews/leadership/slide-13.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE ARCHITECTURE


Make evidence retrieval a contract, not a prompt


A gate requests only what it needs from an approved snapshot. Retrieval, interpretation, scoring and authorization have separate responsibilities.


Evaluation plan


Approved obligations
Typed selectors


Evidence collector


Scope, access, as-of
Digest and schema


Independent check


Observed vs expected
References and rationale


Gate policy


Counts, rule trace
Persisted verdict


Restricted evidence and report store


Immutable references and audit lineage


13


**Speaker notes**


The collector observes; a judge interprets; the policy engine decides. The evidence store has separate ACLs. A report or model output is not permission. The protected boundary verifies a current signed authorization against the same immutable snapshot. The schema and storage design are proposed, not already integrated.


</details>


---

<a id="slide-14"></a>

## 14. Why these controls, rather than more AI review?

![Why these controls, rather than more AI review?](previews/leadership/slide-14.png)

<details>
<summary>Slide text and speaker notes</summary>


DECISION RATIONALE


Why these controls, rather than more AI review?


We want evidence that is independently inspectable and a blocking decision that can be explained without relying on an LLM-generated percentage.


Design choice | Why


Reuse OpenSpec; add only gaps | Benchmark additional assurance, not duplicate checks.


Atomic counts and calibrated reliability | Distinguish what passed from how trustworthy the finding is.


Typed evidence and audit rationale | Show expected/observed, actual source and applicable policy rule.


Independent runtime and trusted gate | Demonstrate executable behavior and enforce the decision.


14


**Speaker notes**


The detailed ADR table records alternatives and trade-offs; no claim that we have validated the chosen thresholds or judge count. The schema-backed evidence record contains a concise justification, not private chain-of-thought. Ask for alignment to implement the narrow vertical slice and benchmark the incremental value.


</details>


---

<a id="slide-15"></a>

## 15. Propose a narrow PoC before expanding scope

![Propose a narrow PoC before expanding scope](previews/leadership/slide-15.png)

<details>
<summary>Slide text and speaker notes</summary>


NEXT STEPS


Propose a narrow PoC before expanding scope


Use one authorized PRD with conditional routing, a runtime constraint, and an invariant that depends on actual data.


15


Engineering deliverables


Independent gate integration; executable graph extraction; Java sandbox runner; runtime event contract; evidence-backed scorecards and bounded repair.


Leadership alignment


Agree on protected boundary, business owner for expected outcomes, approved execution data, risk/latency budgets and pilot acceptance criteria.


Decision requested: approve the vertical slice and identify owners for validation and enforcement.


**Speaker notes**


Use one authorized PRD with conditional routing, a runtime constraint, and an invariant that depends on actual data.


</details>
