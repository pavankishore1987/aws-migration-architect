# I=E Conformance — Engineering presentation (V7)

**57 slides** · Architecture proposal · All example results are illustrative.

[PowerPoint](IE_Conformance_Runtime_Engineering_V7.pptx) · [PDF](IE_Conformance_Runtime_Engineering_V7.pdf) · [Back to architecture](../README.md) · [Meeting script](../TEAM_MEETING_SCRIPT.md)

This GitHub-friendly edition includes the original monochrome slide images and searchable slide text and speaker notes. GitHub renders the Markdown as a scrolling page; use the PowerPoint or PDF for full-screen presentation.

## Contents

[01. Conformance in the agentic authoring loop](#slide-01)  

[02. Why execution must be part of conformance](#slide-02)  

[03. Reuse native checks; extend where evidence is missing](#slide-03)  

[04. The gates follow artifact maturity, not command boundaries](#slide-04)  

[05. Separate authoring, evaluator and application runtimes](#slide-05)  

[06. Conformance becomes a tool-backed feedback loop](#slide-06)  

[07. Use explicit integration points rather than prompt-only gates](#slide-07)  

[08. Intent conformance is evaluated after approval](#slide-08)  

[09. Design the ability to enforce runtime constraints](#slide-09)  

[10. Compare the approved model and observed execution](#slide-10)  

[11. Run actual built code against an independent oracle](#slide-11)  

[12. What to measure during application execution](#slide-12)  

[13. Instrument at the workflow boundary and each node](#slide-13)  

[14. Specify deadlines at the correct level](#slide-14)  

[15. Keep enforcement readiness separate from instance satisfaction](#slide-15)  

[16. Resolve JIT schemas and files before protected action](#slide-16)  

[17. Bound remediation and invalidate stale evidence](#slide-17)  

[18. Make authorization an external trust decision](#slide-18)  

[19. From source evidence to an independent gate verdict](#slide-19)  

[20. Define the unit of conformance before evaluating](#slide-20)  

[21. Resolve context independently of the authoring agent](#slide-21)  

[22. Make findings reproducible and auditable](#slide-22)  

[23. Reuse the scoring contract at each gate](#slide-23)  

[24. Gate 1 — measure fidelity to approved business intent](#slide-24)  

[25. Gate 2 — measure design adequacy before code](#slide-25)  

[26. Gate 3 — measure executable structure and behavior](#slide-26)  

[27. A mandatory failure cannot be averaged away](#slide-27)  

[28. Why 96% conformance can correctly return FAIL](#slide-28)  

[29. Use structured judgments, not self-reported percentages](#slide-29)  

[30. Emit two distinct reports at each reached gate](#slide-30)  

[31. Run isolated and sequential experiments](#slide-31)  

[32. Build ground truth without leaking expected verdicts](#slide-32)  

[33. Expand defect taxonomy to execution and agent-control failures](#slide-33)  

[34. Measure the system, not just the artifacts](#slide-34)  

[35. Measure both defect detection and unsafe authorization](#slide-35)  

[36. Define denominator, granularity and unknown handling](#slide-36)  

[37. Calibrate semantic decisions; optimize risk and coverage](#slide-37)  

[38. Select judges by measured risk, not by a fixed count](#slide-38)  

[39. Convert historical evidence into decision reliability](#slide-39)  

[40. Establish a risk bound for each blocking gate](#slide-40)  

[41. Worked demo — payment authorization and duplicate protection](#slide-41)  

[42. Start with a narrow executable vertical slice](#slide-42)  

[43. Define the conformance tool interface](#slide-43)  

[44. Report actual execution-time evidence against approved limits](#slide-44)  

[45. Collect counters, histograms and detailed traces](#slide-45)  

[46. Run the same metric pipeline at every gate](#slide-46)  

[47. Measure readiness and actual satisfaction separately](#slide-47)  

[48. A gate report should explain the decision, not hide it](#slide-48)  

[49. Demonstrate what each extension adds beyond OpenSpec](#slide-49)  

[50. Questions the engineering review must resolve](#slide-50)  

[51. Make evidence retrieval a contract, not a prompt](#slide-51)  

[52. Versioned request and response](#slide-52)  

[53. Store the reasoning that supports the decision](#slide-53)  

[54. Store each attempt before authorizing progression](#slide-54)  

[55. Why this approach — alternatives and trade-offs](#slide-55)  

[56. Make the contracts executable](#slide-56)  

[57. Alignment needed before implementation](#slide-57)  


---

<a id="slide-01"></a>

## 01. Conformance in the agentic authoring loop

![Conformance in the agentic authoring loop](previews/engineering/slide-01.png)

<details>
<summary>Slide text and speaker notes</summary>


INTENT = EXECUTION  /  ARCHITECTURE PROPOSAL


Conformance in the
agentic authoring loop


From approved business intent to executable behavior, independent gate decisions and runtime evidence.


Engineering design  •  gate policy, execution evidence, benchmarks and integration


V7 proposal  |  Runtime, evidence and gate measurement


**Speaker notes**


This is a proposed architecture. Runtime APIs, hooks and numerical thresholds require repository discovery and validation. The deck expands V4 without replacing its three independent gates.


</details>


---

<a id="slide-02"></a>

## 02. Why execution must be part of conformance

![Why execution must be part of conformance](previews/engineering/slide-02.png)

<details>
<summary>Slide text and speaker notes</summary>


PROBLEM


Why execution must be part of conformance


The existing checks establish intent, design and structural correspondence. They do not, on their own, establish that executable behavior is correct or that it meets runtime constraints.


2


What we already verify


PRD-to-spec fidelity and BPMN structure.
Design and task traceability.
Java workflow mapping, graph reconstruction and node semantics.


What remains unproven


Whether the actual implementation follows the intended paths, produces the correct state and side effects, enforces invariants under real inputs, and meets agreed execution-time constraints.


Add execution evidence to Gate 3 and runtime safeguards; retain Gate 1 and Gate 2.


**Speaker notes**


The existing checks establish intent, design and structural correspondence. They do not, on their own, establish that executable behavior is correct or that it meets runtime constraints.


</details>


---

<a id="slide-03"></a>

## 03. Reuse native checks; extend where evidence is missing

![Reuse native checks; extend where evidence is missing](previews/engineering/slide-03.png)

<details>
<summary>Slide text and speaker notes</summary>


OPENSPEC CAPABILITY ASSESSMENT


Reuse native checks; extend where evidence is missing


Validate and Verify are useful existing capabilities. We should not build a duplicate semantic reviewer simply because we can.


3


Existing capability


Use in our architecture


Incremental assurance to test


Validate


Run native structural validation where applicable.


PRD preservation, BPMN domain constraints and approved baseline provenance.


Verify


Reuse task completion, spec/code and design/code checks.


Independent executable graph, behavioral and invariant evidence.


Native findings


Normalize severity and evidence; deduplicate.


Calibrated reliability, explicit unknowns and gate-specific authorization.


Test execution


Reuse existing valid tests and reports.


Independent oracles, workload tests and runtime/JIT enforcement.


Establish the actual customized OpenSpec baseline before claiming an assurance gap.


**Speaker notes**


Inspect the installed OpenSpec version and customized commands in Stage 0. Upstream verify assesses completeness, correctness and coherence; do not assume its findings are deterministic or that native verification cannot catch the defects shown. Normalize native findings into our evidence contract. A baseline ablation must justify incremental checks.


</details>


---

<a id="slide-04"></a>

## 04. The gates follow artifact maturity, not command boundaries

![The gates follow artifact maturity, not command boundaries](previews/engineering/slide-04.png)

<details>
<summary>Slide text and speaker notes</summary>


LIFECYCLE


The gates follow artifact maturity, not command boundaries


Gate 1 is inside propose-design. A human-approved spec is necessary, but conformance authorization is still required.


4


PRD


Persist baseline


Propose intent


Draft spec / BPMN


PROPOSE DESIGN  |  same command, two phases


Finalize intent


Clarify, approve, reconcile


Gate 1


Intent verdict


Generate design


Proposal / design / tasks


Gate 2


Design verdict


Apply / Verify


Build, execute, test


Gate 3


Code verdict


Delivery / runtime


Authorize release; protect actual effects


Every gate issues PASS, FAIL or HUMAN REVIEW. Only a current PASS permits the protected next phase.


**Speaker notes**


Describe the command boundaries carefully. The original PRD is immutable; authorized clarifications supplement it. Gate 2 protects Apply and Gate 3 protects delivery. Runtime controls are separate from these authoring gates.


</details>


---

<a id="slide-05"></a>

## 05. Separate authoring, evaluator and application runtimes

![Separate authoring, evaluator and application runtimes](previews/engineering/slide-05.png)

<details>
<summary>Slide text and speaker notes</summary>


ARCHITECTURE


Separate authoring, evaluator and application runtimes


The word runtime has three meanings here. Their responsibilities and timing data must not be conflated.


5


Authoring runtime


Claude Code / OpenSpec


Conformance runtime


Independent evaluators and policy


Application runtime


Java / Graphite executable workflow


Evidence store


Versioned artifacts, traces, reports


Authoring and evaluation


The agent invokes tools; a trusted service or wrapper executes checks and owns authorization.


Application execution


An isolated test harness runs built code; deployed runtime guards evaluate transaction-specific obligations.


Discovery: confirm Graphite APIs, sandbox capabilities and the Claude Code interception boundary.


**Speaker notes**


The word runtime has three meanings here. Their responsibilities and timing data must not be conflated.


</details>


---

<a id="slide-06"></a>

## 06. Conformance becomes a tool-backed feedback loop

![Conformance becomes a tool-backed feedback loop](previews/engineering/slide-06.png)

<details>
<summary>Slide text and speaker notes</summary>


AGENT INTEGRATION


Conformance becomes a tool-backed feedback loop


The authoring agent can repair an artifact, but it cannot declare its own work conformant or authorize progression.


6


Agent authoring


Read, plan, write, test


Freeze candidate


Hash artifact + evidence


Conformance tool


Run due obligations


Policy engine


Persist result; decide


PASS


Verify authorization


FAIL


Bounded repair plan


HUMAN REVIEW


Suspend; obtain evidence


No automatic override; budget exhaustion blocks.


**Speaker notes**


A validator can be deterministic or invoke independent judges. The external orchestrator owns state, budget, permissions and gate approval. Hooks can notify or intercept, but prompt prose alone cannot enforce a trust boundary.


</details>


---

<a id="slide-07"></a>

## 07. Use explicit integration points rather than prompt-only gates

![Use explicit integration points rather than prompt-only gates](previews/engineering/slide-07.png)

<details>
<summary>Slide text and speaker notes</summary>


AGENT INTEGRATION


Use explicit integration points rather than prompt-only gates


Invoke fast feedback checks during editing; invoke the authoritative gate at the protected boundary. Both may use the same evaluator library.


7


Propose intent


Persist source; draft artifacts


Propose design


Finalize; G1; generate; G2


Apply / Verify


Incremental build/test; G3


CI / delivery


Recheck current authorization


Advisory checks


On artifact changes, run syntax, lint, graph and focused tests where economical. Findings guide repair; they do not authorize.


Blocking checks


Freeze the full due obligation set, independently evaluate, persist a verdict and verify authorization at use.


If hooks cannot enforce the protected operation, use a trusted wrapper or CI control.


**Speaker notes**


Invoke fast feedback checks during editing; invoke the authoritative gate at the protected boundary. Both may use the same evaluator library.


</details>


---

<a id="slide-08"></a>

## 08. Intent conformance is evaluated after approval

![Intent conformance is evaluated after approval](previews/engineering/slide-08.png)

<details>
<summary>Slide text and speaker notes</summary>


GATE 1


Intent conformance is evaluated after approval


The PRD is available when propose-intent starts; the final specification is only known after clarification within propose-design.


8


Required evidence


Immutable PRD and authorized clarification history.
Final spec and reconciled BPMN; human approval tied to revisions.
Scenario-to-path and invariant inventory.


What blocks design generation


Missing required business intent, invalid XML, unreachable nodes, omitted paths or unauthorized additions.
Unresolved meaning or unsupported process semantics require human review.


Gate 1 produces its own dimension scores, evidence, verdict and benchmark case result when labeled.


**Speaker notes**


The PRD is available when propose-intent starts; the final specification is only known after clarification within propose-design.


</details>


---

<a id="slide-09"></a>

## 09. Design the ability to enforce runtime constraints

![Design the ability to enforce runtime constraints](previews/engineering/slide-09.png)

<details>
<summary>Slide text and speaker notes</summary>


GATE 2


Design the ability to enforce runtime constraints


At Gate 2 the implementation does not yet exist. We verify that the design allocates every due requirement to an implementable mechanism and test strategy.


9


Design obligations


Map requirements and invariants to components, tasks, dependencies and negative tests.
Specify runtime guard placement, schema resolution, retry and failure policy.


Execution-time obligations


Record agreed workflow/node deadlines, workload scope and resource envelope.
Design timing instrumentation, bounded retries, cancellation and safe recovery; do not invent SLOs.


Gate 2 blocks Apply if required enforcement or execution-time design is absent.


**Speaker notes**


At Gate 2 the implementation does not yet exist. We verify that the design allocates every due requirement to an implementable mechanism and test strategy.


</details>


---

<a id="slide-10"></a>

## 10. Compare the approved model and observed execution

![Compare the approved model and observed execution](previews/engineering/slide-10.png)

<details>
<summary>Slide text and speaker notes</summary>


GATE 3


Compare the approved model and observed execution


Derive the expected and actual workflow independently. A matching graph is necessary for exact correspondence, but does not prove node behavior or timing.


10


Approved BPMN


Parse expected graph


Built Java / Graphite


Extract actual graph


Graph comparison


Normalized expected vs actual IR. Compare nodes, edges, branch and join semantics.


Structural findings


Missing / extra nodes, edges, unsupported constructs


Behavioral findings


Execute code; compare traces, effects, timing to oracle


Combine the independent findings with semantic and invariant evidence → Gate 3 verdict.


**Speaker notes**


Read the approved BPMN only for expected evidence. Extract actual edges from the initialized executable Java workflow; do not reconstruct from annotations or expected XML. Execute the built candidate against independent scenarios. The conformance policy combines all due findings.


</details>


---

<a id="slide-11"></a>

## 11. Run actual built code against an independent oracle

![Run actual built code against an independent oracle](previews/engineering/slide-11.png)

<details>
<summary>Slide text and speaker notes</summary>


EXECUTION HARNESS


Run actual built code against an independent oracle


Prefer execution of the generated artifact with representative data over relying on agent-authored tests alone.


11


Freeze candidate


Commit/build digest + environment


Provision sandbox


Fixtures, JIT schema, stubbed effects


Execute workflow


Real code; approved inference


Compare evidence


Independent expected outcome


Reproducibility


Pin build, dependencies, flags, locale, clock policy, workload, schema/model versions and test seed where relevant.


Containment


No real financial side effects. Use approved data, isolated identities, controlled endpoints and bounded resources.


Distinguish real code / real approved inference / representative replay / mocks in the report.


**Speaker notes**


Prefer execution of the generated artifact with representative data over relying on agent-authored tests alone.


</details>


---

<a id="slide-12"></a>

## 12. What to measure during application execution

![What to measure during application execution](previews/engineering/slide-12.png)

<details>
<summary>Slide text and speaker notes</summary>


EXECUTION MODEL


What to measure during application execution


Measure end-to-end behavior and timing at both workflow and node boundaries.


12


Dimension


Observation


Failure / uncertainty example


Control flow


Actual node and edge sequence; joins


Wrong destination or missing branch


Business behavior


Inputs, state delta, output, effects


Incorrect decision despite passing tests


Execution time


Elapsed workflow/node latency; deadline


Mandatory deadline violated


Resources / retries


CPU, memory, retry count, queue time


Retry storm or exhausted budget


Concurrency / recovery


Interleavings, cancellation, compensation


Duplicate effect after retry


Inference / data


Model output, grounding, schema/file version


Stale schema or unsupported conclusion


Capture distributions and sample counts; one passing run does not demonstrate a runtime SLO.


**Speaker notes**


Measure end-to-end behavior and timing at both workflow and node boundaries.


</details>


---

<a id="slide-13"></a>

## 13. Instrument at the workflow boundary and each node

![Instrument at the workflow boundary and each node](previews/engineering/slide-13.png)

<details>
<summary>Slide text and speaker notes</summary>


EXECUTION TELEMETRY


Instrument at the workflow boundary and each node


Use a common correlation model to join execution events with conformance obligations and approved artifacts.


13


Transaction start


Trace/run ID; build and input digest


Node events


Enter, exit, branch, exception, retry


Effect boundary


Guard result + intended effect


Transaction end


Outcome, duration, state and evidence


Runtime measurements


Use monotonic elapsed time; distinguish queue wait, compute, I/O, inference and retry/backoff. Record cold/warm and workload context.


Evidence integrity


Capture redacted structured events with node/edge and obligation IDs; validate trace completeness. Never log raw sensitive inputs by default.


Missing spans or unresolved correlation are evidence gaps, not evidence of correctness.


**Speaker notes**


Use a common correlation model to join execution events with conformance obligations and approved artifacts.


</details>


---

<a id="slide-14"></a>

## 14. Specify deadlines at the correct level

![Specify deadlines at the correct level](previews/engineering/slide-14.png)

<details>
<summary>Slide text and speaker notes</summary>


EXECUTION BUDGETS


Specify deadlines at the correct level


Treat latency, deadlines and resource limits as explicit obligations when the business or platform requires them.


14


Budget


Measure / enforce


Decision


Workflow SLO


p50/p95/p99; max / deadline under workload


FAIL if a validated mandatory rule is breached


Node / dependency


Elapsed time, calls, timeout and retries


Cancel / compensate as designed


Inference


Model latency, tokens, cost, abstention


Bounded retry or review / block


Conformance gate


Evaluation wall time, per-check deadlines


Unresolved due checks → REVIEW


Authoring loop


Attempts, tool calls, wall time, token cost


Exhaustion → stop and escalate


No universal timeout or SLO is assumed; establish values with owners and measurement.


**Speaker notes**


Treat latency, deadlines and resource limits as explicit obligations when the business or platform requires them.


</details>


---

<a id="slide-15"></a>

## 15. Keep enforcement readiness separate from instance satisfaction

![Keep enforcement readiness separate from instance satisfaction](previews/engineering/slide-15.png)

<details>
<summary>Slide text and speaker notes</summary>


RUNTIME INVARIANTS


Keep enforcement readiness separate from instance satisfaction


A Gate 3 PASS cannot prove that a future transaction with unavailable data will meet its invariant.


15


Code predicate


Deterministic checks / tests


LLM inference


Grounded output and calibrated policy


JIT file / schema


Resolve approved input at execution


Runtime effect guard


Allow only verified action


At Gate 3


Verify guard integration, input adapters, inference rubric, failure paths, tests and required performance evidence.


At transaction runtime


Evaluate due properties using actual facts; deny or escalate unknown, stale, malformed or conflicting evidence.


Runtime guard is not a fourth authoring gate; it protects actual transaction effects.


**Speaker notes**


A Gate 3 PASS cannot prove that a future transaction with unavailable data will meet its invariant.


</details>


---

<a id="slide-16"></a>

## 16. Resolve JIT schemas and files before protected action

![Resolve JIT schemas and files before protected action](previews/engineering/slide-16.png)

<details>
<summary>Slide text and speaker notes</summary>


RUNTIME DATA


Resolve JIT schemas and files before protected action


An invariant may be code-enforced, inference-dependent and data-dependent at the same time.


16


Locate input


Authorized file / snapshot


Resolve schema


Trusted version and compatibility


Validate / infer


Check fields; ground judgment


Decide / act


Atomic guard and effect


Runtime failure modes


Missing file, drifted schema, partial data, stale snapshot, unavailable model, timeout or low evidence reliability.


Audit and safety


Record versions, policy, data digest, outcome and reason. Bind the guard to the effect transaction to avoid a stale read.


Do not silently default missing evidence to satisfied; block or seek adjudication.


**Speaker notes**


An invariant may be code-enforced, inference-dependent and data-dependent at the same time.


</details>


---

<a id="slide-17"></a>

## 17. Bound remediation and invalidate stale evidence

![Bound remediation and invalidate stale evidence](previews/engineering/slide-17.png)

<details>
<summary>Slide text and speaker notes</summary>


AGENT INTEGRATION


Bound remediation and invalidate stale evidence


The same agent can consume evaluator findings and propose a repair; independent evaluation is repeated against the new immutable candidate.


17


Repair contract


Return obligation IDs, defect type, evidence references, expected condition and affected scope.
Give the agent targeted feedback, not private benchmark labels.


Control loop


On FAIL, create a new attempt under a configured cap. On HUMAN REVIEW, suspend until evidence or authorized clarification is available.
Invalidate affected upstream/downstream approvals on edits.


Never reuse an old PASS after inputs, code, policy or relevant configuration changes.


**Speaker notes**


The same agent can consume evaluator findings and propose a repair; independent evaluation is repeated against the new immutable candidate.


</details>


---

<a id="slide-18"></a>

## 18. Make authorization an external trust decision

![Make authorization an external trust decision](previews/engineering/slide-18.png)

<details>
<summary>Slide text and speaker notes</summary>


ENFORCEMENT


Make authorization an external trust decision


Gate reports are evidence, not permission. A mutable JSON file must never be sufficient to proceed.


18


Frozen snapshot


Current artifact and build digests


Independent checks


Due obligations + evidence


Policy decision


Persist verdict atomically


Protected operation


Validate scoped authorization


Gate authorization


Bind the PASS to change, gate, snapshot, upstream approvals, policy/evaluator versions and scope. Revalidate at use.


Trust boundary


A controller, wrapper, restricted tool or CI identity must own protected actions. Agent access must not permit bypass within that boundary.


Missing report, timeout, stale approval, malformed result or invalid authorization must fail closed.


**Speaker notes**


Gate reports are evidence, not permission. A mutable JSON file must never be sufficient to proceed.


</details>


---

<a id="slide-19"></a>

## 19. From source evidence to an independent gate verdict

![From source evidence to an independent gate verdict](previews/engineering/slide-19.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT ARCHITECTURE


From source evidence to an independent gate verdict


A gate is an evaluation pipeline over a frozen candidate. Scoring and calibration consume validated findings; neither is an LLM-generated percentage.


19


Approved intent


PRD, amendments, invariants


Candidate artifacts


Spec, BPMN, design, Java


Execution evidence


Tests, traces, data, timings


Evidence collection + obligation plan


Deterministic / semantic / execution / invariant checks


Score and coverage


Deduplicate obligation findings


Calibration


Empirical reliability by gate/configuration


Policy engine → report + PASS / FAIL / HUMAN REVIEW


**Speaker notes**


Inputs are captured by trusted, versioned collectors. Applicability and evidence plan are frozen before evaluation. Resolve conflicting evidence via independent adjudication, not vote alone. A benchmark joins labels only after the verdict; the policy engine never sees hidden labels.


</details>


---

<a id="slide-20"></a>

## 20. Define the unit of conformance before evaluating

![Define the unit of conformance before evaluating](previews/engineering/slide-20.png)

<details>
<summary>Slide text and speaker notes</summary>


OBLIGATION REGISTRY


Define the unit of conformance before evaluating


An obligation is an independently verifiable business rule, control-flow property, invariant or performance constraint. Its identity persists across all three gates.


20


Obligation / source


Gate 1: intent


Gate 2: design


Gate 3: code + execution


REQ-01: age ≥ 18


Preserve predicate and scenario.


Allocate validation and boundary test.


Verify predicate; ages 17, 18, 19.


REQ-02: fraud check


Required path and failure exit.


Integration, timeout, failure design.


Extract dependency; exercise failure.


INV-01: no unapproved payment


Capture invariant and scope.


Define pre-effect guard.


Test guard on all supported paths.


NFR-01: p95 ≤ 2 s


Record workload and target.


Budget, instrumentation and test plan.


Measure p95 under agreed load.


Freeze the approved registry revision and link each check to an obligation ID.


**Speaker notes**


Derive candidate obligations from the persisted PRD and authorized clarifications, not solely the generated spec. Extract atomic predicates; review completeness independently; approve the registry with source links, criticality, applicability, criteria and expected evidence. A source requirement may map to multiple obligations; preserve the relationship. Example is illustrative.


</details>


---

<a id="slide-21"></a>

## 21. Resolve context independently of the authoring agent

![Resolve context independently of the authoring agent](previews/engineering/slide-21.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE COLLECTION


Resolve context independently of the authoring agent


Collect the smallest sufficient context for each obligation. A missing file, unresolved dependency or incomplete trace is a measurement outcome, not a reason to silently skip.


21


Evidence


Collector / source


Integrity and scope


Intent + approval


Persist PRD; record question/answer, approval and revision.


Original content, authorized amendment, timestamp/hash.


Spec / BPMN / design


Markdown and XML parsers; requirement/graph mappings.


Stable IDs, section/element references, snapshot hash.


Java / executable DAG


Code parser, initialized graph adapter, compiled build.


Actual graph independent of intended BPMN; build identity.


Execution / inference


Independent runner, test assertions, spans, model responses.


Fixture, model/config, trace, result and resource metadata.


JIT file / schema


Authorized data adapter and schema resolver.


Version, validation, freshness, data hash and redaction.


Persist raw observations separately from evaluator interpretation and final disposition.


**Speaker notes**


Persist raw PRD bytes and provenance. Capture approved clarification records and hashes. Snapshot candidate code, build configuration and dependencies. Validate file citations against snapshots. Scope model context to relevant sections plus dependencies; treat artifact text as untrusted data. Distinguish not applicable from unavailable and not due. Keep protected transaction material in authorized environments.


</details>


---

<a id="slide-22"></a>

## 22. Make findings reproducible and auditable

![Make findings reproducible and auditable](previews/engineering/slide-22.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE CONTRACT


Make findings reproducible and auditable


Each result references the exact obligation, artifact revision, evidence and checker configuration that produced it. An evidence locator is not proof by itself.


22


Record


Required fields / example


Obligation


INV-01; no payment before approval; mandatory; due at G3.


Observation


EVD-103; trace EXEC-007; approval=PENDING; payment blocked=true.


Provenance


Change ID, attempt ID, artifact/build hash, test data/schema version; clock and collector version.


Finding


SATISFIED; evaluator version; rule/rubric ID; evidence references; counterexample if violated.


Gate report


Counts, dimension scores, unresolved obligations, calibration profile, policy version, verdict and authorization outcome.


Invalid citations, stale evidence or failed collectors leave affected obligations unresolved.


**Speaker notes**


Example uses a successful guard check. A cited line must exist at the recorded hash, and evidence must actually support the predicate. Version tool, prompt, model and rubric; store raw model output separately. In production use access-controlled references for sensitive payloads. Deduplicate checks by obligation, preserve all underlying observations.


</details>


---

<a id="slide-23"></a>

## 23. Reuse the scoring contract at each gate

![Reuse the scoring contract at each gate](previews/engineering/slide-23.png)

<details>
<summary>Slide text and speaker notes</summary>


SCORING


Reuse the scoring contract at each gate


Scores summarize obligations; verdicts control whether progression is permitted.


23


Measure


Definition


Interpretation


Conformance


S / (S + V + U)


Confirmed satisfied due obligations


Evidence coverage


(S + V) / (S + V + U)


Conclusive due obligation assessment


Graph precision / recall


Matched edges / actual or expected edges


Detect extra and missing routing


Runtime scenario coverage


Exercised required scenarios / due scenarios


Separate test success from coverage


Calibrated confidence


Reliability on independent held-out examples


Do not equate agreement with probability


S = satisfied; V = violated; U = unresolved. Not-due and not-applicable are separate counts.


**Speaker notes**


Scores summarize obligations; verdicts control whether progression is permitted.


</details>


---

<a id="slide-24"></a>

## 24. Gate 1 — measure fidelity to approved business intent

![Gate 1 — measure fidelity to approved business intent](previews/engineering/slide-24.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT DIMENSIONS


Gate 1 — measure fidelity to approved business intent


Evaluate after clarification, human approval and BPMN reconciliation inside propose-design. The original PRD and authorized amendments remain the reference.


24


Dimension


Numerator / denominator


Evidence or mechanism


Requirement recall


Preserved source requirements / due source requirements


Independent PRD-to-spec comparison.


Requirement precision


Authorized generated requirements / generated requirements


Check additions against PRD + amendments.


Semantic fidelity


Satisfied semantic obligations / due semantic obligations


Categorical findings and source/target references.


BPMN integrity


Valid elements / applicable elements; valid edges / edges


XML parser; supported gateway and reachability rules.


Scenario + invariant coverage


Correctly represented required scenarios / required scenarios; preserved invariants / due invariants


Independent scenario set and trace extraction.


Any confirmed mandatory loss or unauthorized behavior blocks technical design.


**Speaker notes**


Requirement completeness is source-side recall; precision is target-side authorization. A generated item may map to multiple source obligations, so normalize semantic units before counting. The scenario oracle comes from approved intent, not traces enumerated from the candidate alone. A missing approved baseline is not a valid denominator.


</details>


---

<a id="slide-25"></a>

## 25. Gate 2 — measure design adequacy before code

![Gate 2 — measure design adequacy before code](previews/engineering/slide-25.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT DIMENSIONS


Gate 2 — measure design adequacy before code


Conformance means more than linking a requirement to a task. Design and tasks must collectively specify adequate implementation and enforcement mechanisms.


25


Dimension


Numerator / denominator


Evidence or mechanism


Design coverage


Adequately addressed obligations / due design obligations


Spec/BPMN vs proposal/design.


Task coverage


Obligations with sufficient tasks / due obligations


Task mappings and dependency checks.


Consistency


Satisfied cross-artifact rules / due consistency rules


Contradictions, unsupported assumptions and scope.


Invariant readiness


Adequately designed guards / due invariant design obligations


Guard, error handling, schema/inference failure policy.


Performance readiness


Constraints with credible design + test plan / due constraints


Workload, timing, budget and instrumentation.


Gate 2 authorizes Apply only for the certified design revision.


**Speaker notes**


Treat a traceability link as necessary but not sufficient. Check adequacy of design mechanism, failure mode, testability, dependencies and authorized scope. Avoid imposing a particular architectural pattern unless mandated. Distinguish feasibility evidence from proof of implementation.


</details>


---

<a id="slide-26"></a>

## 26. Gate 3 — measure executable structure and behavior

![Gate 3 — measure executable structure and behavior](previews/engineering/slide-26.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT DIMENSIONS


Gate 3 — measure executable structure and behavior


Compare approved BPMN to the independently extracted Java workflow. Execute independent scenarios; do not infer behavior merely from node annotations or task completion.


26


Dimension


Numerator / denominator


Evidence or mechanism


Graph recall / precision


Matched nodes or edges / expected or actual nodes or edges


Normalized executable graph, not tags alone.


Semantic fidelity


Satisfied implementation obligations / due obligations


Code predicates and independent evaluator.


Scenario correctness / coverage


Passed executed cases / executed cases; exercised required cases / required cases


Independent test oracle and execution traces.


Invariant readiness


Satisfied enforcement checks / due enforcement checks


Code, inference, JIT data; adverse cases.


Performance


Satisfied performance obligations / due constraints


Actual latency, load, resource and timeout evidence.


Report unauthorized side effects separately; 100% topology is not proof of behavior.


**Speaker notes**


Node/edge matches depend on the supported process IR and approved normalization. Graph identity alone cannot prove predicate equivalence. Include unexpected edges and unreachable elements. Execute required cases including negative tests, concurrency, side effects and actual workload. Missing runtime data leaves transaction satisfaction not due until runtime; Gate 3 still checks readiness.


</details>


---

<a id="slide-27"></a>

## 27. A mandatory failure cannot be averaged away

![A mandatory failure cannot be averaged away](previews/engineering/slide-27.png)

<details>
<summary>Slide text and speaker notes</summary>


VERDICT POLICY


A mandatory failure cannot be averaged away


The gate must produce an independent verdict even when many obligations have been satisfied. A deterministic decision engine owns the outcome.


27


FAIL / HUMAN REVIEW


FAIL: confirmed mandatory violation, including a required performance or behavioral rule.
HUMAN REVIEW: unresolved mandatory evidence, unsupported construct, evaluator timeout or insufficient calibration.


PASS / not executed


PASS: all due mandatory obligations satisfied and evidence/reliability policy met.
NOT_EXECUTED: downstream gate was blocked; execution status, not a gate verdict.
NOT_READY: missing prerequisite.


Only current PASS permits progression. Runtime deadlines apply only where approved and due.


**Speaker notes**


The gate must produce an independent verdict even when many obligations have been satisfied. A deterministic decision engine owns the outcome.


</details>


---

<a id="slide-28"></a>

## 28. Why 96% conformance can correctly return FAIL

![Why 96% conformance can correctly return FAIL](previews/engineering/slide-28.png)

<details>
<summary>Slide text and speaker notes</summary>


WORKED SCORING EXAMPLE


Why 96% conformance can correctly return FAIL


Illustrative: 50 unique due mandatory obligations, evaluated against a frozen implementation. A confirmed bypass of an approval guard is independently reproduced.


28


48


Satisfied


1


Violated


1


Inconclusive


Measure


Calculation


Meaning


Conformance


48 / 50 = 96%


Confirmed satisfied obligations.


Evidence coverage


(48 + 1) / 50 = 98%


Conclusive obligations.


Uncertainty


1 / 50 = 2%


One due result unresolved.


Verdict: FAIL  |  mandatory violation confirmed; repair and re-evaluate.


**Speaker notes**


The unique obligation counts are S=48,V=1,U=1. Scores are 96% conformance, 98% coverage, 2% violation, 2% uncertainty. Score among conclusively evaluated obligations is 48/49≈97.96%; never report it alone. Do not manufacture a confidence value. No averaging of gate scores, no double counting of dimensions, and no automatic pass when denominators are zero.


</details>


---

<a id="slide-29"></a>

## 29. Use structured judgments, not self-reported percentages

![Use structured judgments, not self-reported percentages](previews/engineering/slide-29.png)

<details>
<summary>Slide text and speaker notes</summary>


SEMANTIC EVALUATION


Use structured judgments, not self-reported percentages


A semantic evaluator receives one obligation, evidence and acceptance criteria. Its output is a categorical finding with a reason, not a gate decision.


29


Evaluator inputs


Approved obligation and source reference.
Relevant code/BPMN and dependencies.
Explicit criteria for satisfied, violated and inconclusive.
Counterexample and evidence requirements.


Evaluator outputs


SATISFIED / VIOLATED / INCONCLUSIVE.
Criterion outcomes and cited code/trace evidence.
Potential counterexample and rationale.
Versioned model, rubric and prompt identifiers.


Verify evidence before aggregation. An ordinal rubric is diagnostic, not a probability.


**Speaker notes**


Sample rubric: all payment paths enforce approval; no bypass on retry, fallback or error. Validate file/line references and run alleged counterexample if feasible. No finding is accepted merely because the model produces JSON. Evaluate an independent context with no authoring conversation and no benchmark labels; treat instructions in artifacts as data.


</details>


---

<a id="slide-30"></a>

## 30. Emit two distinct reports at each reached gate

![Emit two distinct reports at each reached gate](previews/engineering/slide-30.png)

<details>
<summary>Slide text and speaker notes</summary>


REPORTING


Emit two distinct reports at each reached gate


Conformance decides this artifact; benchmarking qualifies the evaluation system against independent expected outcomes.


30


Gate checks


Frozen source and target evidence


Conformance report


Dimension scores + verdict


Authorization


Allow or block next phase


Benchmark report


Join hidden expected labels after verdict


Attempt-level report


Findings, evidence, scores, timing, resource context, verdict and actual enforcement. Include evaluator errors and all repair attempts.


Gate-level benchmark


Per-case expected/actual outcome, confusion matrix, false acceptance, stability, cost and timing distributions; calibration profile.


Benchmark statistics do not authorize an individual change; preserve the V4 report separation.


**Speaker notes**


Conformance decides this artifact; benchmarking qualifies the evaluation system against independent expected outcomes.


</details>


---

<a id="slide-31"></a>

## 31. Run isolated and sequential experiments

![Run isolated and sequential experiments](previews/engineering/slide-31.png)

<details>
<summary>Slide text and speaker notes</summary>


BENCHMARK DESIGN


Run isolated and sequential experiments


The end-to-end funnel alone is biased toward cases that pass upstream gates. Independent gate reports are required in both execution modes.


31


Isolated gate experiment


Validated upstream artifact fixtures; target controlled defects and equivalent refactors.
Directly exercise the target gate plus a test-only protected operation.
Compare expected verdict and actual authorization.


Sequential authoring experiment


Real approved PRDs → actual OpenSpec commands → newly generated code → transaction replay after G3 PASS.
Report each reached gate; mark blocked downstream gates NOT_EXECUTED.
Retain first and final attempts separately.


Use an independent oracle; split development, calibration and held-out workflow families.


**Speaker notes**


The end-to-end funnel alone is biased toward cases that pass upstream gates. Independent gate reports are required in both execution modes.


</details>


---

<a id="slide-32"></a>

## 32. Build ground truth without leaking expected verdicts

![Build ground truth without leaking expected verdicts](previews/engineering/slide-32.png)

<details>
<summary>Slide text and speaker notes</summary>


BENCHMARK EXECUTION


Build ground truth without leaking expected verdicts


Use three complementary tracks: fixed-artifact evaluator tests, real PRD-to-code authoring, and transaction replay with authorized representative data.


32


Development


Build rubrics, checks, fixtures


Calibration


Select thresholds and policy


Held-out


Assess locked configuration


Experiment


Input


Report


Isolated G1/G2/G3


Known-good artifacts, mutants, equivalent alternatives, ambiguous cases.


Independent per-gate metrics.


End-to-end authoring


Real PRD; actual commands; generated code; no bypass.


Each reached gate; downstream NOT_EXECUTED.


Transaction replay


Generated executable; actual/representative data, schemas and inference.


Behavior, guard outcomes, latency and side effects.


Ground truth is joined after evaluation, never supplied to the authoring or judging loop.


**Speaker notes**


Divide by workflow families before any mutations. Example split 40/30/30 is a starting point, not a power calculation. Human SMEs approve expected behavior, defect labels and gate verdicts; independent test oracle where possible. Replay with approved model calls or explicitly labeled mocks. Report actual vs simulated and not-executed states. No financial side effects.


</details>


---

<a id="slide-33"></a>

## 33. Expand defect taxonomy to execution and agent-control failures

![Expand defect taxonomy to execution and agent-control failures](previews/engineering/slide-33.png)

<details>
<summary>Slide text and speaker notes</summary>


BENCHMARK DESIGN


Expand defect taxonomy to execution and agent-control failures


Use controlled mutations as well as naturally occurring authoring defects.


33


Target


Example mutation / experiment


Expected outcome


Gate 1


Missing required deadline / rule; stale BPMN


FAIL or REVIEW by evidence


Gate 2


No timeout / fallback design; missing guard task


FAIL if mandatory


Gate 3


Wrong edge, retry duplicate, deadline breach


FAIL if violation confirmed


Runtime


Missing JIT data, inference abstains, stale schema


Block / review protected action


Agent loop


Direct invoke, edit after PASS, forged report


Deny unauthorized progression


Evaluator


Hung checker; malformed output; missing trace


REVIEW; deny progression


Also test valid refactors, approved equivalent behavior and healthy performance to measure false rejection.


**Speaker notes**


Use controlled mutations as well as naturally occurring authoring defects.


</details>


---

<a id="slide-34"></a>

## 34. Measure the system, not just the artifacts

![Measure the system, not just the artifacts](previews/engineering/slide-34.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT


Measure the system, not just the artifacts


Keep four evaluation targets separate and report by gate, workflow family, complexity and configuration.


34


Target


Core metrics


Unit / cohort


Artifact conformance


S/V/U, structural precision/recall, coverage


Due obligations per attempt


Evaluator effectiveness


False acceptance, rejection, defect recall, stability


Labeled gate cases / findings


Authoring effectiveness


First-pass rate, repair cycles, tool latency, cost


Change / attempt / run


Application execution


Outcome, invariant escapes, p50/p95/p99, resource use


Transaction / node / load tier


Runtime inference / data


Accuracy, grounding, abstention, stale/drift rate


Labeled inference / schema cases


State all denominators, sample count, provenance, timing method and unmeasured values.


**Speaker notes**


Keep four evaluation targets separate and report by gate, workflow family, complexity and configuration.


</details>


---

<a id="slide-35"></a>

## 35. Measure both defect detection and unsafe authorization

![Measure both defect detection and unsafe authorization](previews/engineering/slide-35.png)

<details>
<summary>Slide text and speaker notes</summary>


METRIC DEFINITIONS


Measure both defect detection and unsafe authorization


The same gate can detect a defect poorly yet still block it by escalating. Benchmark exact verdict, defect findings and actual authorization separately.


35


Expected / actual


PASS


FAIL


REVIEW


PASS (40)


36


1


3


FAIL (50)


1


43


6


REVIEW (10)


0


1


9


88%


Exact verdict accuracy


2%


False acceptance (1/50)


98%


Defective cases blocked


18%


Review rate


Illustrative data. A review may block progression without confirming a violation.


**Speaker notes**


Illustrative confusion matrix: expected pass [36,1,3], fail [1,43,6], review [0,1,9]. Exact verdict accuracy 88%, false acceptance 1/50=2%, false rejection 1/40=2.5%, safe blocking for known defective 49/50=98%, unsafe PASS among actual PASS 1/37≈2.7%, review 18/100, automation 82/100. A known defective case sent to review is blocked, not necessarily confirmed detected.


</details>


---

<a id="slide-36"></a>

## 36. Define denominator, granularity and unknown handling

![Define denominator, granularity and unknown handling](previews/engineering/slide-36.png)

<details>
<summary>Slide text and speaker notes</summary>


METRIC DEFINITIONS


Define denominator, granularity and unknown handling


Every metric is a versioned contract with raw counts, cohort, configuration and measurement status. A zero denominator is undefined, never a default 100%.


36


Metric


Definition


Scope


Precision / recall / F1


TP/(TP+FP); TP/(TP+FN); 2PR/(P+R)


Confirmed defect findings; labeled obligations.


False acceptance / rejection


Defective PASS / defective; conformant FAIL / conformant


Labeled gate cases, per gate.


Unsafe PASS / progression


Wrong PASS / all PASS; unauthorized actual transitions / attempted protected transitions


Separate evaluator decision from enforcement.


Review / automation


REVIEW / executed; automatic PASS or FAIL / executed


Do not count NOT_EXECUTED as evaluated.


Stability / cost / latency


Repeat-reference agreement; attributable cost; elapsed time distribution


Version, repeats and workload cohort.


Report critical invariant escapes separately from general false acceptance.


**Speaker notes**


For obligation-level defect precision/recall, use independently labeled findings and stable defect identities; prevent duplicate true-positive claims. Report unlocalized or unresolved defects separately. Unsafe progression measures actual protected operation, not merely PASS. Record first-attempt and final outcomes separately. Raw metrics remain distinct from policy decisions.


</details>


---

<a id="slide-37"></a>

## 37. Calibrate semantic decisions; optimize risk and coverage

![Calibrate semantic decisions; optimize risk and coverage](previews/engineering/slide-37.png)

<details>
<summary>Slide text and speaker notes</summary>


CALIBRATION


Calibrate semantic decisions; optimize risk and coverage


The number of judges is an experimental choice. Deterministic checks do not need an LLM confidence score when their evidence is sufficient.


37


Independent experiments


Compare deterministic-only, one judge, council, and adaptive escalation on the same held-out cases.
Measure false acceptance, review rate, latency and cost.


Risk-bound qualification


Fit empirical calibration on labeled calibration cases; assess on untouched workflow families.
Zero observed escapes is not zero risk; Rule of Three ≈ 3/n for independent trials at 95% confidence.


Acceptance thresholds and budget limits require approval and actual experimental evidence.


**Speaker notes**


The number of judges is an experimental choice. Deterministic checks do not need an LLM confidence score when their evidence is sufficient.


</details>


---

<a id="slide-38"></a>

## 38. Select judges by measured risk, not by a fixed count

![Select judges by measured risk, not by a fixed count](previews/engineering/slide-38.png)

<details>
<summary>Slide text and speaker notes</summary>


CALIBRATION


Select judges by measured risk, not by a fixed count


Run deterministic checks first. Independent semantic judges should be compared on identical frozen cases; valid counterexamples outrank consensus.


38


Deterministic checks


Evidence and rule outcomes


Primary semantic judge


Independent obligation assessment


Evidence assessment


Resolve or escalate by policy


If needed


Independent judge(s)


When uncertainty or risk warrants


Adjudication


Validate contradictions and counterexamples


Normalized finding


Resolved or inconclusive


Compare configurations


Precision / recall • false acceptance • review rate • stability • incremental cost and latency


Only a validated configuration may support an automatic probabilistic PASS.


**Speaker notes**


One, two, three judges and adaptive escalation are experiments. Ensure no previous authoring transcript or peer responses in first-pass evaluations. Shared model blind spots still exist. Cohen kappa may describe two-judge agreement, not correctness. Inconclusive critical conditions should block; adjudicate contradictory evidence.


</details>


---

<a id="slide-39"></a>

## 39. Convert historical evidence into decision reliability

![Convert historical evidence into decision reliability](previews/engineering/slide-39.png)

<details>
<summary>Slide text and speaker notes</summary>


CALIBRATION MECHANICS


Convert historical evidence into decision reliability


Fit calibration on a separate labeled cohort. A confidence claim must specify the predicted event, sample, configuration and supported domain.


39


Pattern in calibration cohort


Correct / total


Observed reliability


Unanimous satisfied


196 / 200


98%


Two satisfied, one inconclusive


85 / 100


85%


Two satisfied, one violated


76 / 100


76%


Select a rule on the calibration set, lock it, then measure risk and automation coverage on untouched workflow families. Unsupported or stale calibration must not authorize PASS.


Hypothetical observations; agreement is a feature, not an accuracy guarantee.


**Speaker notes**


Illustrative empirical calibration: among cases proposed as satisfied, unanimous judges were correct 196/200; 2 agree plus inconclusive 85/100; disputed 76/100. Use binomial intervals, stratify by gate, defect family and evidence completeness, and reject unsupported strata. Evaluate gate-level safe PASS separately. Use reliability curves, Brier score and ECE for probabilities; do not average obligation probabilities. No figures are measured.


</details>


---

<a id="slide-40"></a>

## 40. Establish a risk bound for each blocking gate

![Establish a risk bound for each blocking gate](previews/engineering/slide-40.png)

<details>
<summary>Slide text and speaker notes</summary>


STATISTICAL QUALIFICATION


Establish a risk bound for each blocking gate


A low observed error rate in a small benchmark is not sufficient to certify a gate. Specify acceptable false acceptance risk with business and engineering owners.


40


Known defective cases


Observed false accepts


Approx. upper 95% error bound


50


0


6%


100


0


3%


300


0


1%


600


0


0.5%


The denominator is independent representative defective cases, not all tests or repeated judge calls.


Thresholds are proposed by risk owners and must be qualified on held-out cases.


**Speaker notes**


For zero failures in n independent representative binary trials, upper one-sided 95% error bound is 1−0.05^(1/n), approximated by 3/n. When errors occur use exact binomial intervals or suitable clustered analysis. Correlated mutations or repeated runs from a single workflow are not independent evidence. Estimate unsafe PASS risk and known-defect false acceptance separately; qualify each gate and relevant critical strata.


</details>


---

<a id="slide-41"></a>

## 41. Worked demo — payment authorization and duplicate protection

![Worked demo — payment authorization and duplicate protection](previews/engineering/slide-41.png)

<details>
<summary>Slide text and speaker notes</summary>


WALKTHROUGH


Worked demo — payment authorization and duplicate protection


Illustrative workflow and outcomes, not a claim about an existing business PRD.


41


Step


Injected defect / evidence


Gate / runtime result


G1


PRD requires approval and no duplicate effect; spec omits latter


FAIL; design not generated


G1 repair


Authorized spec + BPMN restored; rerun checks


PASS; design may proceed


G2


Design omits idempotency and retry test


FAIL; Apply blocked


G2 repair


Guard and tests added, validated


PASS; Apply permitted


G3


Correct tags; wrong executable edge or retry duplicates effect


FAIL; delivery blocked


Runtime


After repaired G3 PASS, missing schema or inference evidence


Block effect / escalate


Demo each gate in isolation as well, so G3 evidence is available even when G1 blocks the sequential run.


**Speaker notes**


Illustrative workflow and outcomes, not a claim about an existing business PRD.


</details>


---

<a id="slide-42"></a>

## 42. Start with a narrow executable vertical slice

![Start with a narrow executable vertical slice](previews/engineering/slide-42.png)

<details>
<summary>Slide text and speaker notes</summary>


IMPLEMENTATION


Start with a narrow executable vertical slice


A small, representative business workflow should demonstrate the complete authoring-to-runtime path before we generalize the framework.


42


Build the core


1. Discover command phases, graph export, trust boundaries.
2. Implement obligation/evidence contracts, score and policy.
3. Wire G1, G2 and G3 to the protected boundaries.


Extend with execution


4. Introduce isolated Java runner, event schema and effect guard.
5. Add independent gate benchmarks and real authoring replay.
6. Calibrate semantic checks, tune budgets, verify enforcement.


Deliver working tests, reports, trace evidence and a repeatable demo; do not claim production readiness.


**Speaker notes**


A small, representative business workflow should demonstrate the complete authoring-to-runtime path before we generalize the framework.


</details>


---

<a id="slide-43"></a>

## 43. Define the conformance tool interface

![Define the conformance tool interface](previews/engineering/slide-43.png)

<details>
<summary>Slide text and speaker notes</summary>


INTEGRATION CONTRACT


Define the conformance tool interface


The agent invokes a read-only evaluation operation over a frozen candidate. The controller verifies the outcome and exposes only the actionable findings to the authoring agent.


43


Field group


Example fields


Purpose


Request


changeId, gateId, runId, attemptId, snapshotDigest


Identify exact candidate and gate


Execution context


policyVersion, evaluatorConfig, deadline, sandboxRef


Control scope and budget


Findings


obligationId, status, evidenceRef, counterexample


Guide remediation and audit


Result


S/V/U, dimension scores, elapsedMs, verdict, reason


Report independent outcome


Authorization


Trusted scoped authorization reference; PASS only


Revalidate at protected operation


Do not accept a model-written verdict or arbitrary tool output as authorization.


**Speaker notes**


The agent invokes a read-only evaluation operation over a frozen candidate. The controller verifies the outcome and exposes only the actionable findings to the authoring agent.


</details>


---

<a id="slide-44"></a>

## 44. Report actual execution-time evidence against approved limits

![Report actual execution-time evidence against approved limits](previews/engineering/slide-44.png)

<details>
<summary>Slide text and speaker notes</summary>


MEASUREMENT EXAMPLE


Report actual execution-time evidence against approved limits


Illustrative values only: assume the example PRD requires a 2 s p95 workflow target under a specified workload and a 500 ms hard node deadline.


44


Observation


Evidence / comparison


Finding


Workflow latency


p95 = 2.4 s; target ≤ 2.0 s; 200 runs


VIOLATED if valid mandatory SLO test


Node deadline


Observed 620 ms; hard limit 500 ms


VIOLATED; check cancellation


LLM latency


p95 310 ms; no approved threshold


Report measurement only


Missing spans


2/200 traces incomplete


Unresolved affected obligations


Gate result


Confirmed mandatory timing violation


FAIL; repair and re-run


Illustrative arithmetic only; establish workload, sample support and statistical acceptance before enforcement.


**Speaker notes**


Illustrative values only: assume the example PRD requires a 2 s p95 workflow target under a specified workload and a 500 ms hard node deadline.


</details>


---

<a id="slide-45"></a>

## 45. Collect counters, histograms and detailed traces

![Collect counters, histograms and detailed traces](previews/engineering/slide-45.png)

<details>
<summary>Slide text and speaker notes</summary>


TELEMETRY AND RUNTIME MEASUREMENT


Collect counters, histograms and detailed traces


Instrumentation must separate agent overhead, gate evaluation time and application runtime. Capture wall-clock elapsed time rather than summing concurrent node durations.


45


Runtime


Example measurements


Collection


Authoring


Wall duration, agent/model calls, tokens, repair attempts, cost


Command wrapper / hooks and provider usage.


Conformance


Gate duration, evaluator span, retries, timeouts, evidence errors


Runner instrumentation; histogram + event record.


Application


Workflow and node spans, branch transitions, memory, p50/p95/p99


Graphite instrumentation; isolated workload runner.


Inference / JIT data


Model duration, schema resolution, compatibility, abstention, guards


Adapter spans, actual outcomes and data provenance.


Latency becomes a violation only under an approved, applicable performance constraint.


**Speaker notes**


Use monotonic clocks for elapsed spans, wall timestamps for correlation. Emit low-cardinality metric dimensions; unique change ID, hashes, execution and transaction IDs belong in traces/reports, not metric labels. Measure tokens from provider usage rather than estimate when available; mark cost unavailable if billing unknown. Test p50/p95/p99 using fixed workload, concurrency, warm-up, dependency behavior, errors and sample count.


</details>


---

<a id="slide-46"></a>

## 46. Run the same metric pipeline at every gate

![Run the same metric pipeline at every gate](previews/engineering/slide-46.png)

<details>
<summary>Slide text and speaker notes</summary>


EXECUTION AND METRICS CONTRACT


Run the same metric pipeline at every gate


The evaluator emits structured findings and raw observations. The benchmark runner joins hidden labels after the verdict and aggregates each gate independently.


46


Instrument / operation


Example output and type


Aggregation


Gate runner


ie.gate.duration (histogram, s); ie.gate.executions (counter)


By gate, verdict, policy configuration; per attempt.


Evaluator adapter


ie.evaluator.duration (histogram); errors/timeouts (counters)


By checker family, model version and outcome.


Authoring wrapper


Input/output tokens, repair attempts, tool calls (counters)


By change and attempt in reports; bounded metric labels.


Workflow runner


ie.workflow.duration; ie.workflow.node.duration (histograms)


By workload tier; p50/p95/p99, count and errors.


Benchmark job


Expected/actual verdict, defect IDs, authorization outcome


Per gate confusion matrix, rates, confidence intervals.


Run isolated gate benchmarks separately; retain first-attempt and final lifecycle measurements.


**Speaker notes**


Illustrative interface only: ie-conformance evaluate --gate 1 --change-id CHG-001; ie-conformance benchmark --gate 1 --dataset heldout-v1; repeat independently for 2 and 3. For sequential authoring run benchmark --mode end-to-end with actual commands and report not-executed downstream gates. Store timestamps, actual model usage, workload and versions. Metric names are proposals; use local JSON first and OTel-compatible export later. Do not make dashboards an authorization boundary.


</details>


---

<a id="slide-47"></a>

## 47. Measure readiness and actual satisfaction separately

![Measure readiness and actual satisfaction separately](previews/engineering/slide-47.png)

<details>
<summary>Slide text and speaker notes</summary>


RUNTIME INVARIANTS


Measure readiness and actual satisfaction separately


A Gate 3 PASS certifies the required enforcement mechanism and test evidence. A future transaction still needs its own evidence before a protected effect.


47


Invariant type


Gate 3: readiness


Runtime: actual satisfaction


Code-enforced


Static checks + property, concurrency and boundary tests.


Evaluate guard; capture denied action or actual side effects.


LLM-inference-dependent


Labeled inference benchmark; grounding; abstention and guard tests.


Resolve actual response/evidence; apply approved confidence policy.


JIT file / schema-dependent


Test resolver, invalid/missing/stale schemas and fixtures.


Resolve current schema; validate actual file; fail closed if mandated.


Measure unsafe accepted inferences and violating transactions blocked on labeled cases.


**Speaker notes**


An invariant can span all three classifications. Examples: deterministic guard; inference about source document; JIT schema parse. Measure schema resolution success and freshness, inference accuracy and grounding only with independent labels, guard false acceptance and side effects with actual outcomes. Missing data or model failure must produce a blocking or approved safe fallback. Do not claim live inference accuracy from unlabelled logs.


</details>


---

<a id="slide-48"></a>

## 48. A gate report should explain the decision, not hide it

![A gate report should explain the decision, not hide it](previews/engineering/slide-48.png)

<details>
<summary>Slide text and speaker notes</summary>


REPORTING EXAMPLE


A gate report should explain the decision, not hide it


Illustrative Gate 3 report, attempt 2. Preserve raw scores, confidence status, execution observations and supporting evidence in one versioned record.


48


Report field


Illustrative observation


Artifact / attempt


CHG-001; attempt 2; approved hash + executable build hash


Dimension results


Nodes 25/25; edges 29/30; scenarios 19/20; evidence 49/50.


Distinct obligations


48 satisfied / 50 due = 96%; 1 violated, 1 unresolved.


Timing / reliability


Gate 46 s; workload p95 1.8 s; calibrated gate confidence unavailable.


Blocking finding


INV-01: reproduced fallback approval-guard bypass; trace reference.


FAIL — downstream delivery denied; repair with a new revision and re-run affected checks.


**Speaker notes**


Use counts that reconcile: 48 satisfied, 1 violated, 1 inconclusive; N=50. Dimension values may overlap and must not be summed. Report P95=1.8 s only for its defined workload; no calibrated confidence available. Mandatory reproduced bypass forces fail regardless of unknown calibration. Gate tool returns structured findings to the agent; authority is external.


</details>


---

<a id="slide-49"></a>

## 49. Demonstrate what each extension adds beyond OpenSpec

![Demonstrate what each extension adds beyond OpenSpec](previews/engineering/slide-49.png)

<details>
<summary>Slide text and speaker notes</summary>


INCREMENTAL VALUE EXPERIMENT


Demonstrate what each extension adds beyond OpenSpec


Run a paired ablation on the same frozen cases, then a separate end-to-end authoring experiment. Avoid comparing different defect populations.


49


100 known defective cases (illustrative)


Native baseline


65


+ Intent


75


+ Graph


86


+ Semantic


90


+ Runtime / invariants


97


Marginal benefit = extra unique defects detected, with false positives, time, cost and review effort.


Illustration only. Retain a custom check only when the incremental assurance justifies it.


**Speaker notes**


Baseline B0 is actual installed customized OpenSpec Validate/Verify where applicable, including its existing tests. Incrementally add original intent, graph, independent semantic, execution/invariant checks. Measure additional unique confirmed defects and additional false positives, cost and latency. Enforcement tests measure actual bypass prevention. Repeat authoring runs separately because feedback changes artifacts. Hypothetical values are not a performance claim.


</details>


---

<a id="slide-50"></a>

## 50. Questions the engineering review must resolve

![Questions the engineering review must resolve](previews/engineering/slide-50.png)

<details>
<summary>Slide text and speaker notes</summary>


ARCHITECTURE REVIEW


Questions the engineering review must resolve


The scoring architecture is designed to be challenged. These are the proposed answers and the corresponding evidence required before rollout.


50


Likely question


Architectural answer


Who determines the score?


Deterministic aggregation of normalized obligation findings; no LLM-generated overall percentage.


Why multiple judges?


Experimentally show marginal improvement; independent context; valid counterexamples outweigh voting.


Who determines ground truth?


Business/engineering reviewers and independent test oracles; blind benchmark labels.


How are thresholds justified?


Calibration cohort + held-out risk bounds + approved risk tolerance, per gate.


Can a 99% score fail?


Yes. Mandatory violations, unresolved evidence or stale authorization block.


Why not native Verify?


Reuse it; prove incremental defect detection and authorization benefit against installed baseline.


Proposed design; exact Graphite APIs, model configuration and production thresholds remain open.


**Speaker notes**


Additional questions: how are benchmark labels isolated? What happens for unsupported graph constructs? How is drift handled? What is trusted authorization boundary? Use gate-specific requalification when evaluator/model/rubric or workload changes. Human adjudication recorded; no mutation of approved intent without reapproval. Open decisions are included on the final V5 decision slide.


</details>


---

<a id="slide-51"></a>

## 51. Make evidence retrieval a contract, not a prompt

![Make evidence retrieval a contract, not a prompt](previews/engineering/slide-51.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE ARCHITECTURE


Make evidence retrieval a contract, not a prompt


A gate requests only what it needs from an approved snapshot. Retrieval, interpretation, scoring and authorization have separate responsibilities.


Evaluation plan


Approved obligations
Typed selectors


Evidence collector


Scope, access, as-of
Digest and schema


Independent check


Observed vs expected
References and rationale


Gate policy


Counts, rule trace
Persisted verdict


Restricted evidence and report store


Immutable references and audit lineage


51


**Speaker notes**


The collector observes; a judge interprets; the policy engine decides. The evidence store has separate ACLs. A report or model output is not permission. The protected boundary verifies a current signed authorization against the same immutable snapshot. The schema and storage design are proposed, not already integrated.


</details>


---

<a id="slide-52"></a>

## 52. Versioned request and response

![Versioned request and response](previews/engineering/slide-52.png)

<details>
<summary>Slide text and speaker notes</summary>


WIRE CONTRACT


Versioned request and response


Use typed selectors, not arbitrary file paths or commands. The collector can return missing, denied, stale, unsupported or truncated evidence explicitly.


Request envelope | Response envelope


Change/run/attempt/gate; snapshot digest | Same scope and request ID; collection status


Obligation IDs, caller identity, as-of time | Evidence IDs, source kind and selector


Source IDs, typed selectors, expected digest | Immutable artifact locator, digest, schema ref


Data classification, size cap and deadline | Collector version, timestamp, redaction, limitations


Allowlist and least privilege checked by collector | Missing/denied/stale never represented as success


52


**Speaker notes**


The authoritative JSON schemas are in the handoff. JSON Schema validates shape only. Authorization, digests, request-response pairing, scope, expiry and actual data access must be verified in application code. Dynamic business schema is evidence, not the schema of the envelope.


</details>


---

<a id="slide-53"></a>

## 53. Store the reasoning that supports the decision

![Store the reasoning that supports the decision](previews/engineering/slide-53.png)

<details>
<summary>Slide text and speaker notes</summary>


AUDITABILITY


Store the reasoning that supports the decision


Persist evidence-grounded summaries and criterion-level comparisons rather than a free-text score or private model scratchpad.


Record | Example in an approval-before-payment scenario


Observation | Trace E-01: mock payment recorded while approval is PENDING.


Criterion result | Expected: no payment until approval. Observed: effect before approval. VIOLATED.


Evaluator rationale | Source and target references, verified counterexample, assumptions and limitations.


Resolution + policy trace | Independent effect oracle corroborates violation; mandatory rule triggers FAIL.


Authorization | No PASS token issued; protected operation independently denied.


53


**Speaker notes**


This is auditable decision support, not hidden chain-of-thought. A citation must exist and be relevant, and counterexamples must be verified. For a probabilistic finding, record rubric/model version, evidence context digest and calibrated profile, not a claim that model internal reasoning is reproducible.


</details>


---

<a id="slide-54"></a>

## 54. Store each attempt before authorizing progression

![Store each attempt before authorizing progression](previews/engineering/slide-54.png)

<details>
<summary>Slide text and speaker notes</summary>


EVIDENCE STORAGE


Store each attempt before authorizing progression


Freeze the artifact manifest and store observations, findings, resolution rationale, report and rule trace under an immutable run/attempt identity.


Evidence store and report


Content-addressed objects or approved restricted locators.

Request/response and evaluator findings.

Human adjudication, scorecard, policy trace and report digest.


Trust boundary


Persist report atomically before issuance.

Verify issuer, policy, expiry and current inputs at protected operation.

If evidence write or verification fails, deny progression.


54


**Speaker notes**


Use a trusted separate issuer; hash alone is not access control. Avoid TOCTOU with immutable snapshots or revision locking. Maintain old attempts and privacy-preserving retention. Raw evidence and PII must not be stored in public GitHub.


</details>


---

<a id="slide-55"></a>

## 55. Why this approach — alternatives and trade-offs

![Why this approach — alternatives and trade-offs](previews/engineering/slide-55.png)

<details>
<summary>Slide text and speaker notes</summary>


ARCHITECTURE DECISIONS


Why this approach — alternatives and trade-offs


The decision register is a proposal to test and refine, not a claim that every design option is already proven.


Decision | Alternative | Rationale / verification


Native checks + extension | Replace OpenSpec | Reuse existing value; paired benchmark additional detection.


Atomic obligation scoring | LLM 0–100 rating | Traceable denominator; critical failures are not averaged away.


Independent IR comparison | Tagging or XML equality | Verify actual transitions; normalize legitimate refactors.


Adaptive judges + calibration | Fixed three judges | Select by risk, cost and latency on held-out cases.


Typed evidence + policy trace | Free-text findings | Reconstruct decision; prove access and provenance controls.


55


**Speaker notes**


The decision register contains 23 decisions, alternatives, rationale and revisit triggers. Discover actual native capabilities and avoid duplicate validation. No predetermined judge count or confidence threshold. Business owners must establish risk tolerances.


</details>


---

<a id="slide-56"></a>

## 56. Make the contracts executable

![Make the contracts executable](previews/engineering/slide-56.png)

<details>
<summary>Slide text and speaker notes</summary>


IMPLEMENTATION HANDOFF


Make the contracts executable


The implementation pack contains twelve Draft 2020-12 JSON Schemas, synthetic fixtures, staged prompts and the full architecture decision register.


Foundation first


Repository discovery and native baseline.

Registry, scores, verdict and policy.

Typed retrieval, evidence provenance and audit contracts before gates.


Then integrate and measure


Wire gates and actual Java execution.

Bound remediation and instrument three runtimes.

Run isolated, sequential and runtime experiments; report each gate independently.


56


**Speaker notes**


Follow IMPLEMENTATION_SEQUENCE.md. Stage 08 is run after Stage 01; Stage 09 after Stage 04. Fixtures test contract shape and arithmetic only. Actual Graphite APIs, CLI enforcement, business data and acceptance thresholds need discovery and approval.


</details>


---

<a id="slide-57"></a>

## 57. Alignment needed before implementation

![Alignment needed before implementation](previews/engineering/slide-57.png)

<details>
<summary>Slide text and speaker notes</summary>


DECISIONS


Alignment needed before implementation


The design is implementable in stages, but the exact integration mechanisms and accepted performance/risk budgets depend on the actual platform.


57


Technical discovery


Can Graphite expose the initialized graph and node events?
Which runtime can intercept commands and prevent direct invocation?
Which code execution, test and inference environments are authorized?


Risk and ownership


Who approves business invariants, workload/SLOs and guard failure actions?
Who owns calibration, exception handling and release authorization?
What data and schemas are approved for benchmark replay?


Proposed architecture extends V4; repository-specific APIs and measured thresholds remain open.


**Speaker notes**


The design is implementable in stages, but the exact integration mechanisms and accepted performance/risk budgets depend on the actual platform.


</details>
