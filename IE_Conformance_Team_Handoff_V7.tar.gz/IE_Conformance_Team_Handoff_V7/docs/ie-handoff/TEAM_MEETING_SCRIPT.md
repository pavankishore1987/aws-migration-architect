# Team architecture discussion — 30 minutes

**Purpose:** Explain the I=E conformance proposal, agree on the direction and identify what we need to validate before implementation. This is a design discussion, not a request for production approval.

**Present:** [Leadership deck](decks/Leadership.md) (15 slides; use the indicated slides, keep the others for questions). The [PowerPoint](decks/IE_Conformance_Runtime_Leadership_V7.pptx) and [PDF](decks/IE_Conformance_Runtime_Leadership_V7.pdf) are also available. Keep the [engineering deck](decks/Engineering.md) and [decision register](ARCHITECTURE_DECISIONS.md) open for the discussion.

## First 15 minutes — talk track

The words below are intended to be spoken in straightforward English. Times include short pauses to point at diagrams; avoid reading every slide. The approval workflow is an illustrative example, not a measured result from our platform.

### 0:00–1:30 — Set the context (slides 1–2)

Thanks everyone. I wanted to use today's discussion to walk through the conformance approach we are proposing for our spec-driven development process. I will spend around fifteen minutes explaining the approach and then I would like to use the rest of the time to discuss it and get alignment from the team.

Today we have an agentic authoring process using OpenSpec and Claude Code. We take business intent, generate specifications, create the design and tasks, and then generate the code. We also have unit tests, component tests and verification.

What I want us to look at is whether we have enough evidence that the intent we started with is the same intent that eventually gets implemented. If a requirement is missed in the first step, the agent may generate a perfectly consistent design and working code for the wrong requirement. Passing tests doesn't necessarily catch that if those tests were generated from the same incomplete specification.

That is the problem we are trying to address with I=E, or Intent equals Execution.

### 1:30–2:45 — Why extend OpenSpec? (slide 3)

One question we should address upfront is why we need this when OpenSpec already has Validate and Verify. I don't want to duplicate those capabilities. Validate already provides artifact checks, and Verify assesses completeness, correctness and coherence of the implementation. We should reuse what is available in our customized setup.

What we are proposing is additional assurance specific to our business workflow platform. For example, checking the original PRD against the approved specification, comparing BPMN with the executable Java workflow, and actually running code to verify business invariants and performance. We also need a clear decision about whether to proceed at each stage.

We should prove that these additional checks find something useful. If the existing OpenSpec checks already cover a requirement with sufficient evidence, we should reuse them instead of writing a second checker.

### 2:45–5:15 — Walk through the three gates (slide 4)

[Point to the lifecycle diagram.]

In our customized flow, propose-intent takes the PRD and generates a draft spec and BPMN. At this point the specification is not final. The original PRD may only be available during this command, so we need to persist it as a change-specific artifact. We should not depend on the agent remembering it in a later session.

When propose-design starts, its initial steps are still concerned with finalizing the intent. Questions are captured in the spec, the user provides answers, and the spec is updated and approved. We need to retain which clarifications were authorized and make sure BPMN reflects the final specification.

Gate 1 runs here, inside propose-design, after approval and BPMN reconciliation, but before technical design generation. It checks whether we have preserved the original intent and the approved clarifications. It also checks BPMN structure, business paths and invariants. If Gate 1 passes, we can produce the proposal, design and tasks.

Gate 2 checks whether those artifacts adequately represent the approved requirements. Are there any missing tasks? Does the design explain how the business rules and invariants will be enforced? Is the design changing business behavior without approval? Only after Gate 2 passes should we run Apply.

Apply generates the implementation, runs tests and remediates issues. We reuse Verify where appropriate. Gate 3 checks the actual implementation against the approved intent, process model and design. It includes structural, semantic and execution-based verification.

Each gate gives its own decision: Pass, Fail or Human Review. Only a current Pass permits us to move forward. Fail means we have a confirmed blocking problem; Human Review means we don't have enough reliable evidence or have an unresolved decision. Both block the protected next phase. A human approving the spec is not the same as Gate 1 passing it.

### 5:15–7:15 — What we actually verify in Java (slides 6 and 12)

[Show the expected and actual workflow diagram; use slide 12 as the example.]

One of the approaches we discussed was tagging the Java code with BPMN node IDs and using ArchUnit-style checks. I think tagging is still useful, but it only tells us that a node is associated with a piece of code. It doesn't tell us that the node runs in the correct order or that it is connected to the right place.

For example, imagine that an ineligible applicant should go to Reject, but the Java workflow routes that applicant to Approve. The Reject node can still be present and correctly tagged. A node-presence check might pass even though the workflow is wrong.

What I am proposing is that we independently extract the actual executable workflow from Java or Graphite, depending on the APIs available. We normalize that into a graph and compare it with the graph from the approved BPMN. We can also render the extracted graph back into BPMN for review.

Then we run actual code in an isolated environment using independently defined scenarios and expected results. We can observe which nodes ran, what decisions were made and what side effects occurred. A matching graph alone does not prove that the logic inside each node is correct. That is why we need both the structural comparison and the execution checks.

### 7:15–8:15 — Runtime and business invariants (slide 7)

We also have invariants that are not all verifiable in the same way. Some are normal code conditions. Some require evaluating an LLM inference. Others need a real file and a schema that is only available during execution.

At Gate 3 we need to check that the mechanism for enforcing the invariant has been implemented and tested. When the real transaction arrives, we evaluate the actual condition before allowing the protected action. We cannot claim today that a future transaction will satisfy an invariant when we don't have the data yet.

We should measure application execution time as well, including workflow and node latency. We only make performance a blocking requirement where an approved limit and a defined workload exist. Otherwise it is an observation.

### 8:15–10:00 — Where the evidence comes from (slides 9 and 13)

[Point to the evidence request and response diagram.]

For these evaluations, we should not give the entire repository to an LLM and ask whether it looks correct. We need to be clear about what we are checking, what data it needs and where that data comes from.

We start with a list of small, identifiable requirements or obligations from the original PRD and approved clarifications. Each obligation has an ID, expected condition, criticality and verification method. The list needs independent review, otherwise we may miss something before we even start evaluating.

The evaluation plan requests the applicable evidence through a defined schema. Collectors fetch things like the approved spec, BPMN, relevant Java source, executable graph, test results, traces, inference responses or an actual file and its schema. They record the source and revision so we can check that the evidence is current.

The evaluator returns whether the condition is satisfied, violated or inconclusive. It also returns a short explanation: what was expected, what was observed, which evidence supports it and any counterexample or limitation. We store that explanation with the evidence and the policy rules that led to the decision. We don't need the model's private chain-of-thought.

### 10:00–12:00 — Explain the scoring (slide 10)

The way I look at scoring, there are two different questions. First, how much of the required work is conformant? Second, how much can we trust the evaluation itself?

Let's take a simple example. We have fifty applicable mandatory obligations. We have evidence that forty-eight are satisfied, one is violated and one is inconclusive. Our conformance score is forty-eight divided by fifty, or ninety-six percent. Our evidence coverage is forty-nine divided by fifty, or ninety-eight percent. We have one confirmed violation and one unresolved obligation.

Even though the score looks good, this gate should fail because a mandatory requirement is violated. We should not average that away. If there were no confirmed violations but an obligation was unresolved, the gate would go to Human Review, not Pass.

For deterministic checks, we can use actual results from validators and tests. For semantic checks, we may use an independent LLM with a specific rubric. The model provides a finding with evidence, not a subjective score out of a hundred.

If we use multiple judges, agreement is a signal but not a measure of correctness. We need to compare their decisions with independently validated examples to estimate reliability. I don't want to prescribe three judges or a ninety-eight percent confidence threshold before we run those experiments. The choice should be driven by measured risk, cost and latency.

### 12:00–13:30 — How we benchmark it (slides 8 and 11)

We need to evaluate the conformance framework itself, not only the generated code.

First, we take reviewed artifacts and introduce known defects, like a missing requirement, a wrong gateway, or a bypassed invariant. We also include conformant implementations and cases that really require human review. Each gate gets an independent benchmark report. This lets us calculate false acceptance, false rejection, the defects detected, review rate and execution overhead.

Second, we run real, authorized PRDs through the actual authoring flow and execute the generated code with representative data. If Gate 1 fails, we do not bypass it to get a Gate 3 result. We record later gates as not executed. We can still benchmark Gate 3 separately using validated upstream inputs.

We should compare against our existing OpenSpec Validate and Verify on the same frozen cases. Are we catching more defects, or catching them earlier? Are we introducing unnecessary latency or false positives? Those are the measurements that will help us decide which capabilities are worth keeping.

### 13:30–15:00 — Agentic integration and the ask (slides 5, 14 and 15)

The last point is how we make this part of the agentic loop. The agent can call conformance checks as tools. It gets structured findings and can make a correction. After a correction, we take a new snapshot and evaluate it again. We need limits on retries, execution time and cost.

But the agent cannot decide to skip a failed check or authorize its own work. That needs to be enforced at the actual transition boundary. A Markdown instruction, or a report containing the word Pass, would not by itself give us a reliable control. We need to investigate what the Claude Code runtime and our existing delivery mechanisms actually allow us to enforce.

For the first iteration, I am suggesting that we pick one real PRD with conditional routing and at least one runtime-dependent invariant. We implement a small vertical slice, test the three gate decisions, measure the existing baseline and evaluate the additional checks. We then review the results before extending the scope.

What I would like to get from this meeting is alignment on the problem, the proposed direction, and what we should prove first. I am not expecting us to agree on every scoring threshold or integration detail today.

## Last 15 minutes — seek alignment

| Time | Question to ask | Outcome to capture |
|---|---|---|
| 15–18 | Does everyone agree that fidelity to original intent and executable behavior is the gap we need to address? What does our existing Verify already cover? | Agreed problem; existing capability owner |
| 18–21 | Are these the right three protected boundaries, especially Gate 1 inside propose-design? Which checks must block versus advise? | Gate placement; mandatory/advisory scope |
| 21–24 | Can we get the actual Graphite executable graph, sandbox execution traces and JIT schema evidence? What is the least invasive integration? | Discovery tasks; SDK/runtime owners |
| 24–27 | Do we agree on obligation-level scoring and evaluating reliability separately? What risks should set our benchmark acceptance criteria? | Metric definitions; SME labels; risk owner |
| 27–30 | Which PRD do we use, who can support discovery and independent validation, and when do we review the PoC evidence? | Pilot scope, owners, next review commitment |

If the conversation goes deep into one implementation detail, say: “That's a good question. Can we record that as a discovery item and agree on how we can test it? I want to make sure we have time to settle the overall direction.”

### Likely questions and short responses

| Question | Suggested answer |
|---|---|
| Aren't we duplicating OpenSpec? | We should reuse its checks. The paired benchmark will show whether additional intent, graph, execution and invariant checks add measurable value. |
| Who defines the score? | A deterministic engine calculates counts from resolved obligation findings; it does not ask an LLM for a percentage. |
| Who decides the list of obligations? | Extract from the original PRD and approved clarifications, independently review it, and baseline it before evaluation. |
| Why not use one overall score? | A mandatory failure cannot be offset by other successful checks. Scores help us understand the result; policy determines progression. |
| Why three judges? | We haven't chosen three. We will compare one, two, three and adaptive escalation against held-out labels. |
| How do you establish confidence? | Measure correctness against independent ground truth for comparable evaluator configurations. Report uncertainty and sample size, not model self-confidence. |
| Can we guarantee the code equals intent? | Only to the extent of the approved obligations, supported model constructs and collected evidence. We cannot prove all possible executions merely by testing. |
| Does this slow developers down? | It adds overhead. We will measure gate latency, authoring time, cost and remediation, and use fast feedback plus authoritative boundary checks. |
| Can the agent bypass a gate? | Our goal is no bypass within the trusted boundary. We need to discover enforceable hooks and protected delivery controls and prove denial with negative tests. |
| What if the runtime data isn't available? | Gate 3 checks enforcement readiness. Actual transaction satisfaction is checked when the authorized data is available. |
| Is this already implemented? | The architecture and contract fixtures are prepared. Real integration and benchmark results still need to be produced. |

### Close the meeting

“Let me quickly summarize what we agreed on. We will start with [use case], validate [integration capability], and establish [baseline and metrics]. [Owner] will help with [dependency]. I will record the decisions and the remaining open questions so we can review actual evidence before expanding. Is there anything important I missed?”

Capture the outcome in [TEAM_ALIGNMENT.md](TEAM_ALIGNMENT.md). Do not treat silence as approval.
