# Proposed PR: I=E conformance architecture and implementation handoff

## Purpose

Align on the conformance architecture for the customized OpenSpec authoring lifecycle before implementing a narrow vertical slice. This introduces a design proposal and implementation specifications, not a deployed control or measured claim of evaluator effectiveness.

## In scope

- Architecture, decision register, three gate boundaries, scoring and calibration.
- Typed evidence retrieval and storage contracts, auditable rationale, execution and runtime invariants.
- Independent per-gate reporting, benchmark methodology, native OpenSpec baseline and agentic integration.
- Claude Code staged prompts, JSON Schemas, illustrative fixtures and fixture validator.
- Detailed engineering and leadership presentations, in GitHub-readable Markdown as well as PowerPoint and PDF.
- Team meeting script and alignment worksheet.

## Out of scope

Production enforcement, actual Graphite/Claude Code integration, approved risk thresholds, live transaction access or any claim that benchmark reliability has been established. These depend on discovery and controlled experiments.

## Review requested

Please review the architecture decisions, confirm the three proposed gate boundaries, identify already-supported native capabilities, and agree on the evidence sources and pilot PRD. Capture changes or deferrals in TEAM_ALIGNMENT.md before implementation.

## Validation

The supplied schema fixtures and selected negative tests pass the local contract validator. This is not proof of a deployed or secure authorization system. See tools/VALIDATION_RESULTS.txt.
