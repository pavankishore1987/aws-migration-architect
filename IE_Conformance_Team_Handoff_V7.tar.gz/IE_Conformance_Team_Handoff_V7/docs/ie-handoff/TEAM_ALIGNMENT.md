# Architecture alignment — working notes

Meeting date: TBD · Participants: TBD · Facilitator: TBD

## Proposed decisions for discussion (not approved)

| Decision | Proposed direction | Alignment (agree / revise / defer) | Owner / next step |
|---|---|---|---|
| Problem scope | Extend native OpenSpec only for proven assurance gaps | TBD | TBD |
| Gate boundaries | G1 inside propose-design after approval; G2 before apply; G3 before delivery | TBD | TBD |
| Decision policy | Mandatory failure blocks; unresolved mandatory evidence blocks; only current authorized PASS progresses | TBD | TBD |
| Evidence and reasoning | Typed retrieval, provenance, criterion-level explanations and policy traces | TBD | TBD |
| Graph comparison | Independent executable graph extraction and normalized BPMN comparison | TBD | TBD |
| Runtime checks | Sandbox execution; distinguish readiness from live invariant satisfaction | TBD | TBD |
| Scoring and calibration | Atomic obligations, separate coverage and empirical reliability; no arbitrary thresholds | TBD | TBD |
| Benchmark | Isolated gates plus actual sequential authoring and transaction replay; paired native baseline | TBD | TBD |
| PoC scope | One approved PRD with branches and a runtime-dependent invariant | TBD | TBD |

## Discussion outcomes

- Existing capability inventory: TBD
- Open questions and risks: TBD
- Pilot PRD / approved data / independent reviewers: TBD
- Required enforcement boundary and trust assumptions: TBD
- Risk tolerance, workload and performance limits: TBD
- Next review date and evidence expected: TBD

For detailed alternatives and trade-offs, see [ARCHITECTURE_DECISIONS.md](ARCHITECTURE_DECISIONS.md).
