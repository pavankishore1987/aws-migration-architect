# Import the I=E V7 team handoff into GitHub

This archive contains a real, standalone Git branch named `docs/ie-conformance-v7`, packaged as a Git bundle, and the identical branch contents as normal files under `docs/ie-handoff/`. No remote repository has been accessed, modified or pushed to. The root commit is intentionally independent of your repository history; cherry-pick it rather than merging unrelated histories.

## Option A — Import the branch into your existing repository

1. Extract the archive outside the repository and note the absolute path of `ie-conformance-v7.bundle`.
2. Go to your existing repository. Check that the working tree is clean and switch to the base branch you want to use. Check that `docs/ie-handoff/` does not already contain a handoff you want to preserve. If it exists, review and migrate the existing files on a separate branch rather than overwriting them.

```bash
git status --short
# If clean, switch to the intended base branch first (example):
git switch main
# Create a review branch from your own repository's history:
git switch -c docs/ie-conformance-v7
# Replace the absolute path with your extracted bundle's path:
git fetch /absolute/path/to/ie-conformance-v7.bundle \
  refs/heads/docs/ie-conformance-v7:refs/heads/import/ie-conformance-v7
# Review the handoff commit:
git show --stat import/ie-conformance-v7
# Apply its contents to your review branch:
git cherry-pick import/ie-conformance-v7
# Inspect before sharing:
git status
git show --stat HEAD
```

If the intended branch name already exists, use a new review branch name. If there is a conflict, review it or use `git cherry-pick --abort`; do not discard existing work. No application files outside `docs/ie-handoff/` are changed by the handoff commit. Only after your own review, if permitted by your organization's policies, push the review branch and open a PR:

```bash
git push -u origin docs/ie-conformance-v7
```

Use `docs/ie-handoff/PR_DESCRIPTION.md` for the PR description. The push is optional and must be run in your environment with the correct remote and permissions.

## Option B — Copy only the ordinary files

Create a new branch in your existing repository and copy `docs/ie-handoff/` from the extracted archive into the repository. Do not overwrite an existing handoff without reviewing it. Inspect `git diff` / `git status`, stage only `docs/ie-handoff/`, and commit once you are satisfied. This gives the same documentation without importing Git history.

## Option C — Inspect the standalone branch without an existing repository

```bash
git clone -b docs/ie-conformance-v7 /absolute/path/to/ie-conformance-v7.bundle ie-conformance-review
cd ie-conformance-review
```

## What GitHub can render

GitHub renders Markdown (`.md`), supported Mermaid diagrams and embedded PNG/SVG files in the repository. Open `docs/ie-handoff/README.md` first. For the presentations, open `docs/ie-handoff/decks/Leadership.md` or `Engineering.md`. These are normal GitHub-readable pages with all slide images and collapsible text and speaker notes. They are not an interactive slideshow; use the original PowerPoint or PDF in the same directory for presenting. No GitHub Pages setup is required.

## Meeting and implementation

- First read `docs/ie-handoff/TEAM_MEETING_SCRIPT.md` (15 minutes presentation + 15 minutes discussion).
- Record proposed decisions and owners in `docs/ie-handoff/TEAM_ALIGNMENT.md`.
- For implementation, start with `docs/ie-handoff/START_HERE.md` and the master Claude Code prompt. The handoff includes the V7 architecture, decisions, contracts, schemas, examples, validators, and all ten staged prompts.

The handoff remains a proposal; contract fixture validation is not actual benchmark or production integration validation.
