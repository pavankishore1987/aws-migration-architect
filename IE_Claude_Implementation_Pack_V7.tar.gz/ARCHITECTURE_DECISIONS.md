# Architecture decision register — V7

These are proposed decisions based on platform requirements described in the design discussions, not approvals or validated experimental results. For each decision record alternatives, reasoning, trade-offs, and evidence needed to confirm or revisit it. Claude Code must inspect actual repository capabilities and update the ADR ledger with source references before binding implementation details. Avoid adding redundant functionality where native OpenSpec or existing enterprise infrastructure already satisfies the requirement.

| ADR | Decision and alternatives | Why choose this direction | Trade-off / validation required | State |
|---|---|---|---|---|
| 01 | Extend native OpenSpec Validate/Verify instead of replacing or relying solely on them | Reuse format checks and agent-driven completeness/correctness/coherence; add PRD fidelity, BPMN, executable graph, invariants, measured assurance and enforcement | Inventory customized native behavior; paired benchmark against actual baseline | Proposed |
| 02 | Persist original PRD + authorized clarification ledger, not conversational memory or spec alone | Preserves ground truth across sessions; catches omitted requirements | Protect data, version amendment precedence, validate hashes and authority | Required design |
| 03 | G1 inside propose-design after human-approved final spec and synchronized BPMN, not after propose-intent | Only evaluate mature artifacts; protect technical design boundary | Check actual CLI hooks; prove early design writes cannot bypass | Required design |
| 04 | Three independently blocking gates vs. advisory or single end gate | Detect defects at transformation boundary and prevent propagation | Additional latency; measure early detection and remediation | Required design |
| 05 | Common engine with per-gate policies and dimensions vs. separate engines or global score | Reuse contracts without conflating risks | Registry lifecycle and policy versioning; independent tests | Proposed |
| 06 | Atomic obligation registry derived from effective intent vs. whole-artifact LLM rating | Stable denominator, traceability, defensible metrics; detects omission | SME review and independent extraction completeness tests | Proposed |
| 07 | Deterministic-first, hybrid when semantics require it vs. all LLM or all rules | Use exact checks where possible; handle genuinely semantic predicates | Adapters and rubrics; benchmark incremental detection | Proposed |
| 08 | Independent semantic context vs. authoring self-verify only | Reduce anchoring and self-confirmation; preserve evidence lineage | Separate context still shares model biases; benchmark diverse vs. same model | Proposed |
| 09 | Adaptive evaluator escalation vs. fixed three judges | Bound cost and latency; choose based on calibrated residual risk | Compare one/two/three/adaptive on same held-out cases; no preset winner | Experiment |
| 10 | Independent executable DAG extraction + normalized IR vs. tagging-only or raw XML equality | Compare true edges, control-flow constructs and extras, preserve legitimate refactors | Discover Graphite extraction APIs and supported semantics; otherwise review | Proposed |
| 11 | Execution harness with independent oracles vs. static graph comparison only | Prove observed behavior, side effects and performance under defined workloads | Sandbox, replay and dependency fidelity; tests don't prove all inputs | Proposed |
| 12 | Separate code/inference/data-dependent invariant categories (overlap allowed) vs. universal LLM/rule check | Route to right evidence, distinguish readiness from runtime truth | Schema drift, approved data, inference calibration and guard tests | Required design |
| 13 | Explicit evidence fetch/response schema vs. dumping whole repo in context | Least privilege, bounded context, provenance and repeatable selection | Implement typed adapters and completeness checks; no arbitrary URL/shell fetch | Proposed |
| 14 | Immutable evidence manifests + structured rationale vs. raw chain-of-thought or bare score | Auditable expected/observed criteria, counterexamples and policy trace; privacy and reviewability | Data governance, retention, integrity and rationale validation | Proposed |
| 15 | Atomic obligation counts + coverage + uncertainty vs. weighted threshold for PASS | Mandatory defects cannot be averaged away | Report advisory metrics separately; test duplicate/empty/missing cases | Required design |
| 16 | Empirical calibration by gate/config and independent holdout vs. model self-confidence | Reliability from ground truth, not agreement or subjective ratings | Sample sufficiency, family split, drift/versioning; risk policy approval | Proposed |
| 17 | Deterministic policy issuer and authorization at protected boundary vs. agent interpreting report | Enforce PASS only and fail closed, including stale artifacts | Local hook limitations; trusted CI/service; negative bypass tests | Required design |
| 18 | Bounded remediation with fresh snapshot vs. self-directed unlimited loop | Feedback benefits without uncontrolled cost and bypass | Budgets explicit; repeated failure/timeout escalates | Proposed |
| 19 | Isolated + sequential authoring + transaction replay vs. single end-to-end benchmark | Separate evaluator accuracy from upstream attrition and actual runtime behavior | Require independent labels and authorized real artifacts; no bypass | Required design |
| 20 | Separate conformance and benchmark report per gate vs. consolidated summary only | Current authorization vs. historical reliability; exposes gate-specific risk | Keep labels out of evaluators; NOT_EXECUTED separate from verdict | Required design |
| 21 | Instrument authoring/evaluation/application separately vs. one wall clock | Meaningful latency and cost attribution; parallel spans not additive | Approved workload/SLO; monotonic timers and trace correlation | Proposed |
| 22 | Local CLI/library + restricted evidence store first vs. premature central platform | Incremental PoC, transport-neutral contracts, fit existing SDD environment | Evaluate tenant isolation, trusted issuer and CI needs before production scale | Proposed |
| 23 | Calibrated PASS policy and measurable incremental value vs. immediate organization-wide mandatory rollout | Validate risk/coverage and overhead; disable redundant checks | No threshold assumed; independent qualification and stakeholder approval | Experiment |

## Decision process for a new check

| Question | If yes | If no |
|---|---|---|
| Is the predicate formal and evidence complete? | Deterministic checker | Determine whether semantics or execution required |
| Is behavior only observable through executing code? | Sandbox execution / trace oracle | Static analysis or semantic check |
| Is the expected outcome explicit but requires interpretation? | Isolated LLM rubric; corroborate evidence | Clarify with SME; do not invent oracle |
| Is actual data/schema needed only at transaction time? | Gate readiness + runtime guard; do not claim satisfaction early | Evaluate at current gate |
| Can native validate/verify or existing checker already provide equivalent evidence? | Normalize/reuse it | Build targeted extension |
| Can a bounded call evaluate it using known evidence? | Prefer bounded evaluator | Use capped evidence-investigation loop only when retrieval/iteration measurably helps |
| Is mandatory evidence missing or calibration insufficient? | HUMAN_REVIEW / block | Apply deterministic policy |

For production risk, obtain approval of tolerable false acceptance/critical escapes, runtime SLOs, human review process, data retention and model permission. Mark all unspecified thresholds provisional. The decision register should evolve through measured ablation, not architectural preference alone.
