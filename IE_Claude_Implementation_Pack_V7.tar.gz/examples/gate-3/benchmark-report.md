# G3 illustrative benchmark report

**NOT EXECUTED.** This is a deliberately fabricated arithmetic test fixture. No calibration, certification or authorization is implied. Mode: ISOLATED_GATE. Cases: 4.

| Expected / actual | PASS | FAIL | HUMAN_REVIEW |
|---|---:|---:|---:|
| PASS | 1 | 0 | 0 |
| FAIL | 1 | 1 | 0 |
| HUMAN_REVIEW | 0 | 0 | 1 |

| Metric | Count | Rate |
|---|---:|---:|
| verdictAccuracy | 3/4 | 75.0% |
| falseAcceptance | 1/2 | 50.0% |
| unsafeProgression | 1/3 | 33.3% |
| criticalEscape | 1/2 | 50.0% |
| falseRejection | 0/1 | 0.0% |
| humanReviewRate | 1/4 | 25.0% |
| automationCoverage | 3/4 | 75.0% |

Defect precision/recall/F1, latency, stability, token cost and calibration are UNMEASURED in this toy fixture. No production acceptance conclusion can be drawn.
