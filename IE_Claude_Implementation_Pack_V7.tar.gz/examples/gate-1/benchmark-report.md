# G1 illustrative benchmark report

**NOT EXECUTED.** This is a deliberately fabricated arithmetic test fixture. No calibration, certification or authorization is implied. Mode: ISOLATED_GATE. Cases: 3.

| Expected / actual | PASS | FAIL | HUMAN_REVIEW |
|---|---:|---:|---:|
| PASS | 1 | 0 | 0 |
| FAIL | 0 | 1 | 0 |
| HUMAN_REVIEW | 0 | 0 | 1 |

| Metric | Count | Rate |
|---|---:|---:|
| verdictAccuracy | 3/3 | 100.0% |
| falseAcceptance | 0/1 | 0.0% |
| unsafeProgression | 0/2 | 0.0% |
| criticalEscape | 0/1 | 0.0% |
| falseRejection | 0/1 | 0.0% |
| humanReviewRate | 1/3 | 33.3% |
| automationCoverage | 2/3 | 66.7% |

Defect precision/recall/F1, latency, stability, token cost and calibration are UNMEASURED in this toy fixture. No production acceptance conclusion can be drawn.
