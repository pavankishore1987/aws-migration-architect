# Start implementing — I=E V7

Extract this package into `docs/ie-handoff/` within your existing repository. Do not overwrite the repository's own README. V7 consolidates the architecture, V6 measurement design, evidence and reasoning contracts, ADR register and implementation instructions. The complete archive also includes the two updated monochrome presentations. The implementation-only archive omits decks.

## Paste into Claude Code from repository root

```text
Act as a senior Java platform architect and AI evaluation engineer. Read docs/ie-handoff/START_HERE.md, README.md, CLAUDE_CONTEXT_PACK.md, GATE_REPORTING_AND_BENCHMARK_CONTRACT.md, EVIDENCE_AND_REASONING_CONTRACT.md, MEASUREMENT_AND_EXECUTION_ARCHITECTURE.md, ARCHITECTURE_DECISIONS.md, CLAUDE_CODE_PROMPT.md and IMPLEMENTATION_SEQUENCE.md (relative to the handoff directory). Read all JSON Schemas and examples/contracts and all numbered implementation prompts. Follow the sequence in IMPLEMENTATION_SEQUENCE.md, starting with read-only discovery. Implement real repository components and independent tests. Preserve Gate 1 inside propose-design after finalized spec approval/BPMN reconciliation; Gate 2 before apply; Gate 3 before protected delivery. Reuse native validate/verify; use independently extracted Java workflow, actual sandbox execution, code/inference/JIT invariants, evidence retrieval and auditable criterion-level rationale, scoring/calibration, per-gate reports and deterministic authorization. Implement the typed retrieval/finding/decision contracts and actual independent benchmark reports, including strict sequential and isolated modes. Record exact test commands, results, ADRs and blockers in a persistent ledger. Do not invent APIs, business requirements, benchmark data or confidence. Do not store private model chain-of-thought. Use only authorized data/models; no commit, push, deploy or irreversible effects. If integration is blocked, implement the testable portion and fail closed for unresolved mandatory checks.
```

## Read order

1. README and architecture decisions: full architecture and alternatives.
2. Gate reporting contract: verdict, scoring, isolated and end-to-end reports.
3. Evidence and reasoning contract: fetch/store, provenance, audit rationale, wire schemas.
4. Measurement and execution architecture: agentic loop, telemetry, native baseline and calibration.
5. Context pack, master prompt and implementation sequence: actual staged implementation.
6. `schemas/`, `examples/contracts/`, `tools/`: contracts, illustrative fixtures and local contract sanity check.

The schemata and fixtures are implementation specifications, not deployed services or measured enterprise benchmarks. Run `python tools/validate_contracts.py` with Python and jsonschema installed (see requirements). This validates fixture shape and selected cross-record rules only. It is not a trusted production authorization validator. Exact SDK/hooks/configuration and acceptance thresholds remain open pending local repository discovery.
