# Gate reporting, benchmarking and authorization contract — V7

This is the authoritative refinement to the prior I=E design. Apply it to Gate 1, Gate 2 and Gate 3 independently. A gate is an executable control, not a quality dashboard. The current artifact can progress only on a current, valid PASS issued by the gate policy and verified at the protected boundary. Benchmark results qualify the evaluator/configuration for use; they do not authorize an individual change. A benchmark case's expected label is never an input to the live evaluator or verdict engine.

## 1. Execution boundaries and report timing

| Gate | Trigger and inputs | Protected next phase |
|---|---|---|
| G1 | Inside propose-design, after human approval of finalized spec and reconciliation of BPMN. Original persisted PRD plus authorized clarifications/amendments, final spec/BPMN, approval provenance | Technical proposal/design/tasks generation within the same command |
| G2 | After technical design artifacts are generated; current G1 authorization and exact approved spec/BPMN, proposal/design/tasks | Apply / code generation |
| G3 | After actual Java implementation/build/test/verify; current upstream authorizations, approved artifacts, executable workflow and independent test evidence | Protected downstream delivery (e.g. CI release authorization, exact boundary to discover) |

At each reached gate, freeze input revisions, evaluate due obligations, aggregate evidence, calculate scores, resolve confidence and apply policy. Persist immutable attempt-specific findings, dimension scorecard and verdict atomically before issuing a PASS authorization. Record actual enforcement at the boundary, including rejected attempts. For benchmark runs, join the private expected label to the observed gate result only after the decision and record a case-level benchmark result immediately; update the gate-specific aggregate report for that run. Finalize it when that gate's benchmark batch completes. Do not delay normal gate authorization to compute aggregate benchmark statistics; a previously validated policy/profile or explicit pilot policy controls authorization. If reporting or authorization persistence fails, deny continuation. No cross-gate score or global verdict can override a blocked gate.

Execution status and verdict are separate. `NOT_EXECUTED` means an upstream block prevented entry; `NOT_READY` means the prerequisite/approval was absent at the attempted entry; neither is a conformance verdict. A started evaluator with missing evidence or technical failure yields HUMAN_REVIEW unless a confirmed mandatory violation establishes FAIL. Record the reason and deny progression. Human adjudication supplies evidence or approved requirement change and reruns; it is not an arbitrary override. Benchmark mode labels are `PASS`, `FAIL`, `HUMAN_REVIEW` on ready cases, with additional readiness/enforcement cases tracked separately. Persist downstream NOT_EXECUTED placeholders in the lifecycle ledger, not fake conformance scores or verdicts. Across remediation attempts preserve the first outcome and all subsequent results under distinct attempt IDs; do not overwrite failures.

## 2. Independent gate and end-to-end modes

**ISOLATED_GATE:** select a gate, freeze independently validated predecessor artifacts and approvals, inject or select known defects at the target gate. Run its actual evaluator + deterministic decision policy and exercise a test-only protected operation. The test harness may provision approved predecessor fixtures in an isolated worktree; it cannot disable or mint real production authorization. Compare with independently labeled obligations, expected verdict, required block/allow and forbidden effects. Generate a separate report for each gate even if another gate fails a different test. Positive cases must include equivalent representations/refactors. Negative cases include a single defect, combined defects and natural real authoring errors. Include unresolved/ambiguous cases, schema failures and technical errors.

**END_TO_END:** ingest a real authorized PRD; execute actual propose-intent, propose-design clarification/approval and G1, design and G2, apply/verify and G3 in sequence. No bypass. Record an independent case result at each reached gate; independently adjudicate whether each frozen output matches effective original intent (not merely its predecessor), including authoring errors propagated across gates. On block record downstream NOT_EXECUTED and reason. A remediation experiment uses a new attempt and rechecks affected approvals/revisions. After G3 PASS, execute newly generated code in a safe sandbox with authorized representative transaction/file snapshots, actual approved inference, as-of trusted JIT schema resolution and no irreversible effects. Capture runtime invariant instance results separately, not as a fourth authoring gate. If real data/model/SDK is unavailable, report BLOCKED and keep synthetic/mocked experiments distinct.

End-to-end results at G2/G3 are conditional on reaching that gate. Do not pool with isolated results for certification. Report both a progression funnel (eligible, reached, completed, pass, fail, review, not-ready, not-executed) and gate-local metrics. First-attempt and final-after-remediation are separate cohorts. Report counts of unique workflow families and repeated runs. Synthetic mutation clusters and repeated model calls are not independent population samples.

## 3. Mandatory output layout

Use equivalent paths in the actual repo; retain the following logical separations. Reports are run- and attempt-scoped; never overwrite. JSON is authoritative; Markdown is an accessible rendering. Access-controlled stores hold private data and evidence; Git stores only allowed redacted references.

```text
conformance/<change-id>/<run-id>/
  gate-1/<attempt-id>/{findings.json,evidence.json,dimension-scores.json,verdict.json,conformance-report.md}
  gate-2/<attempt-id>/{...same contract...}
  gate-3/<attempt-id>/{...same contract...}
  lifecycle-summary.json
benchmarks/<experiment-id>/<mode>/<evaluator-config-id>/
  gate-1/{case-results.jsonl,confusion-matrix.json,metrics.json,benchmark-report.md}
  gate-2/{...same contract...}
  gate-3/{...same contract...}
  progression-funnel.json  # end-to-end only
  runtime/{case-results.jsonl,metrics.json,report.md}  # if reached and authorized
  summary.md               # cross-gate visibility, not authorization
calibration/<gate>/<config-id>/<profile-version>/
  profile.json             # immutable validated profile, support counts, split IDs
  certification-report.md  # risk limits, uncertainty, coverage, held-out assessment
```

Authorization remains in the trusted policy/enforcement store, bound to gate, change/run/snapshot IDs, upstream verdict digests, approved inputs, policy/evaluator/config versions, scope and freshness; verify current hashes at use. Prevent TOCTOU using immutable snapshots/transactional checks. A mutable report file is not itself permission to proceed. Gate and benchmark service identities should be distinct; label store is unavailable to author/evaluator. Benchmark reports may link to the verdict digest; never write or mutate that verdict.

## 4. Metric contract per gate

For every metric return `{metricId, value, numerator, denominator, unit, status, reason, cohort, gate, dimension, configId}`. Use null/NOT_APPLICABLE for undefined zero-denominator metrics and null/UNMEASURED for unavailable data. Never substitute 0 or 100. For latency/quantile/calibration metrics include sample count and method instead of a misleading ratio. Each scorecard includes obligation counts S/V/U and not-due/not-applicable counts; deduplicate checks to one obligation. Define N=S+V+U for applicable due mandatory obligations; conformance=S/N, coverage=(S+V)/N. Report dimensions G1.1–G3.8 from the context and directional precision/recall for traceability, graph and coverage. Report invariant mechanism, evidence type and due phase separately. A missing required obligation must not vanish from N. The policy may use calibrated evidence reliability for probabilistic checks, but a confirmed mandatory violation always FAILs regardless of aggregate score or majority vote.

For each gate and each isolated or end-to-end cohort publish all of the following, including absolute counts:

| Metric | Numerator / denominator or definition |
|---|---|
| Three-way verdict matrix | Expected PASS/FAIL/HUMAN_REVIEW by actual PASS/FAIL/HUMAN_REVIEW on labeled ready completed cases; publish missing/error/not-ready counts outside matrix |
| False acceptance | Known FAIL cases receiving PASS / all known FAIL cases attempted (report technical/noncompleted counts and completed-only rate too) |
| Unsafe progression | Expected FAIL or HUMAN_REVIEW cases actually allowed / all expected FAIL or HUMAN_REVIEW cases attempted; separate wrong PASS from bypass |
| Critical escape | Known critical-defective cases actually allowed / known critical-defective cases attempted |
| False rejection | Expected PASS cases returning FAIL / expected PASS cases attempted |
| Unnecessary review | Expected PASS returning HUMAN_REVIEW / expected PASS attempted |
| Defect precision / recall / F1 | Match adjudicated findings to labeled defect IDs; TP/(TP+FP), TP/(TP+FN), harmonic mean; REVIEW is not defect detection by itself |
| Accuracy | Exact three-way matches / labeled ready completed cases; also report completion coverage |
| Automation / review | PASS or FAIL / ready attempted; HUMAN_REVIEW / ready attempted; report uncompleted separately |
| Stability | Same-case repeated verdict agreement (state definition), separate inter-judge agreement |
| Calibration | Gate-level automatic PASS correctness and risk bounds; reliability bins, support counts, Brier score and ECE for a defined probabilistic outcome; no probability when uncalibrated |
| Operational measures | p50/p95 latency, tokens, cost, human effort, evaluator errors, remediation; store observation count and provenance |

Break down by gate, dimension, defect type, severity, workflow family/complexity, invariant mechanism, schema/config version and real/synthetic/replay/mock provenance. Report per-gate and per-configuration certification separately from per-artifact verdict. Compare isolated configurations on same held-out cases, with independent development/calibration/holdout families. Set decision thresholds based on calibrated risk-coverage trade-off and approved false-acceptance/critical escape bounds. Report uncertainty and sample support; no invented thresholds or fake measured values. At runtime measure actual inference classification, grounding, abstention, contract/data quality and transaction-level invariant escapes separately from G3 readiness.

## 5. Worked illustrative case (not measured)

| Gate | Expected | Actual | Allowed? | Interpretation |
|---|---|---|---|---|
| G1, run A | PASS | PASS | Yes | approved spec and reconciled BPMN satisfy due checks |
| G2, run A | FAIL | FAIL | No | design omits mandatory idempotency guard, even if other 19/20 obligations satisfied |
| G3, run A | not reached | NOT_EXECUTED | No | do not count as correct verdict, or as a failed implementation |
| G3, isolated run B | FAIL | PASS | Yes (test stub) | all annotations intact, wrong executable edge escaped; unsafe progression and false acceptance increment |
| G3, isolated run C | PASS | PASS | Yes (test stub) | correct graph and all readiness obligations satisfied; future data-dependent properties still due at runtime |

No benchmark labels should be visible to the gate when it produces these outcomes. A G3 FAIL fixture in isolation uses a valid frozen G1/G2 predecessor. No actual delivery occurs in the test sandbox.

## 6. Required implementation acceptance tests

1. Each ready gate emits a complete conformance report and independent verdict with scores and validated evidence. Fixture expected PASS/FAIL/REVIEW for every gate. Gate 1 runs at the intra-command boundary, after spec approval; no premature design writes.
2. Benchmark runner emits case result per reached gate and separate aggregate G1/G2/G3 reports with the same metric definitions. Verify expected labels are excluded from evaluator context and reports cannot authorize delivery.
3. G1 FAIL and REVIEW block design; G2 blocks apply; G3 blocks delivery; timeouts, malformed output, report write failure, missing evidence and stale snapshot block. Test actual protected invocation including direct invocation within trust boundary. Record attempted vs allowed operations.
4. In end-to-end run, G1 FAIL -> G2/G3 NOT_EXECUTED; G2 FAIL -> G3 NOT_EXECUTED. No downstream phantom scores or labels in confusion matrix. Test pass-all run and blocker remediation under new attempt IDs. Validate all cohort denominators manually on a small known fixture.
5. Isolated G3 cases run independently using validated upstream fixtures regardless of failures in separate G1/G2 cases. Mutate actual executable graph while annotation tags remain correct; distinguish node semantics and runtime invariant checks.
6. Distinguish actual real code generation, representative transaction replay, approved real model inference and synthetic fakes. Missing JIT file/schema or ungrounded inference blocks the runtime action; future not-due properties do not count as satisfied at G3.
7. Calibration records are versioned per gate/config and benchmark cohort. A changed rubric/model/checker invalidates applicability until reviewed/revalidated. Uncalibrated semantic decisions requiring calibration cannot auto-pass production. Verify 99% conformance with a mandatory violation fails, unresolved obligations review, zero denominators nonnumeric, and audit trail reproducible.

## 7. Decisions still required from the repository and risk owners

Discover the actual Graphite executable DAG introspection API, supported BPMN subset, intra-command protection, CI trust boundary, approved models, real PRDs, transaction access, schema resolver, and independent SME oracle. Proposed layout and field names can adapt to existing conventions; semantic requirements and blocking boundaries cannot. Neither these design documents nor illustrative fixtures are empirical certification. Do not claim production readiness or implement live financial side effects.


## V7 normative additions — evidence, reasoning, metrics and integration

Read [Evidence and reasoning contract](EVIDENCE_AND_REASONING_CONTRACT.md), [Measurement and execution architecture](MEASUREMENT_AND_EXECUTION_ARCHITECTURE.md) and [Architecture decisions](ARCHITECTURE_DECISIONS.md) (paths relative to handoff root). These supplement, and where wire formats differ supersede, earlier conceptual JSON examples in this file. Use Draft 2020-12 schemas in `schemas/` and coherent examples in `examples/contracts/`; original examples are legacy arithmetic fixtures only. Validate shape and cross-record semantics. Persist structured evidence-grounded rationale (criteria, expected/observed, evidence IDs, assumptions, limitations, verified counterexamples), aggregation rationale and deterministic policy rule trace; do not store hidden chain-of-thought. Use typed evidence fetch requests and responses, versioned manifests, access-controlled storage, actual execution instrumentation, and durable artifact-bound authorization. Reuse native OpenSpec Validate/Verify and benchmark its incremental value; do not assume capabilities of our customized version. Measure authoring, evaluator and application execution time separately. The new prompts `08-evidence-contract-and-audit.md` and `09-native-baseline-and-agentic-loop.md` are required, but run prompt 08 immediately after Stage 1 (before gates) and prompt 09 after Stage 4 (before benchmarks), as described in updated sequence. Implementation must include negative tests for data retrieval, provenance, rationale/reference integrity, policy trace and actual protected progression.
