#!/usr/bin/env python3
"""Local synthetic contract sanity check. NOT a production authorization verifier."""
import copy
import json
import math
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = {p.name.removesuffix('.schema.json'): json.loads(p.read_text()) for p in (ROOT / 'schemas').glob('*.schema.json')}
EXAMPLES = {p.stem: json.loads(p.read_text()) for p in (ROOT / 'examples/contracts').glob('*.json')}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def shape(name, value):
    Draft202012Validator(SCHEMAS[name], format_checker=FormatChecker()).validate(value)

def indexed(rows, key):
    result = {r[key]: r for r in rows}
    require(len(result) == len(rows), f'duplicate {key}')
    return result

def score(rows, reported):
    s, v, u, na = [sum(r['status'] == status for r in rows) for status in ('SATISFIED', 'VIOLATED', 'INCONCLUSIVE', 'NOT_APPLICABLE')]
    n = s + v + u
    for k, val in zip(('satisfied','violated','inconclusive','not_applicable','applicable'),(s,v,u,na,n)):
        require(reported[k] == val, f'bad count: {k}')
    for k, num in [('conformance',s),('coverage',s+v),('violation_rate',v),('uncertainty_rate',u)]:
        val = reported[k]
        require((val is None) if not n else (val is not None and math.isclose(val,num/n,abs_tol=1e-9)), f'bad ratio: {k}')

def validate_report(r, registry, response, request):
    shape('gate-report',r)
    require(r['scope'] == response['scope'] == request['scope'], 'mixed snapshot or run scope')
    require(response['request_id'] == request['request_id'] and request['request_id'] in r['request_ids'], 'unmatched evidence request')
    require(r['registry_ref']['artifact_id'] == registry['registry_id'],'registry identity mismatch')
    evidence = indexed(r['evidence'],'evidence_id'); returned = indexed(response['items'],'evidence_id')
    require(evidence == returned, 'fixture evidence response and report do not agree')
    for e in evidence.values():
        require(e['status'] != 'AVAILABLE' or e['artifact'] is not None,'available evidence needs artifact reference')
        require(any(q['source_id']==e['source_id'] and q['kind']==e['source_kind'] and q['selector']==e['selector'] for q in request['selectors']), 'unrequested selector')
    findings = indexed(r['findings'],'finding_id'); resolved = indexed(r['obligation_results'],'obligation_id')
    expected = {o['obligation_id']:o for o in registry['obligations'] if o['gate']==r['scope']['gate'] and o['due_phase']==('TRANSACTION' if r['scope']['gate']=='RUNTIME' else 'AUTHORING')}
    require(set(resolved)==set(expected), 'missing or extra due obligations')
    for f in findings.values():
        oid=f['obligation_id']; require(oid in expected,'unknown obligation in finding')
        refs=set(f['evidence_ids']);require(refs <= evidence.keys(),'dangling finding reference')
        for e in refs:require(oid in evidence[e]['obligation_ids'],'evidence linked to wrong obligation')
        require({c['criterion_id'] for c in f['rationale']['criteria']} <= set(expected[oid]['criteria_ids']),'unknown rubric criterion')
        for c in f['rationale']['criteria']+f['rationale']['counterexamples']:
            require(set(c['evidence_ids']) <= refs,'dangling criterion/counterexample reference')
    mandatory=[]
    for oid, rr in resolved.items():
        o=expected[oid];require(rr['criticality']==o['criticality'] and set(rr['dimensions'])==set(o['dimensions']),'registry mismatch')
        require(set(rr['finding_ids'])<=findings.keys() and set(rr['evidence_ids'])<=evidence.keys(),'dangling result reference')
        require(all(findings[f]['obligation_id']==oid for f in rr['finding_ids']),'inconsistent finding obligation')
        if rr['status'] in ['SATISFIED','VIOLATED']:
            require(bool(rr['finding_ids']) and bool(rr['evidence_ids']) and all(evidence[e]['status']=='AVAILABLE' for e in rr['evidence_ids']),'conclusive result needs available evidence')
        if rr['criticality']!='ADVISORY':mandatory.append(rr)
    score(mandatory,r['overall_score'])
    for dim in r['dimension_scores']:score([rr for rr in mandatory if dim['population'] in rr['dimensions']],dim)
    d=r['decision']; bad={rr['obligation_id'] for rr in mandatory if rr['status']=='VIOLATED'}; unknown={rr['obligation_id'] for rr in mandatory if rr['status']=='INCONCLUSIVE'}
    require(not bad or d['verdict']=='FAIL','confirmed mandatory violation must fail')
    require(not unknown or d['verdict']!='PASS','unresolved mandatory obligation cannot pass')
    require(bool(mandatory) or d['verdict']!='PASS','empty mandatory evaluation cannot pass')
    require(bad <= set(d['blocking_obligation_ids']),'blocking violation omitted')
    for t in d['rule_trace']:
        require(set(t['obligation_ids'])<=resolved.keys() and set(t['finding_ids'])<=findings.keys() and set(t['evidence_ids'])<=evidence.keys(),'dangling policy trace reference')
    # This checks selected cross-record rules only; actual artifact bytes, trust, policy,
    # criterion meaning, signatures, calibration and runtime authorization need the real implementation.

def main():
    for name,schema in SCHEMAS.items():Draft202012Validator.check_schema(schema)
    for name,ex in EXAMPLES.items():shape(name,ex)
    args=[EXAMPLES[k] for k in ['gate-report','obligation-registry','evidence-response','evidence-request']]
    validate_report(*args)
    b=EXAMPLES['gate-benchmark-report'];require(sum(sum(row.values()) for row in b['confusion_matrix'].values())==b['reached_cases'],'confusion matrix total mismatch')
    case=EXAMPLES['benchmark-case-result'];require(case['actual_verdict']==args[0]['decision']['verdict'] and case['observed_progression']==EXAMPLES['boundary-event']['observed_decision'],'case/report mismatch')
    for row in EXAMPLES['lifecycle-summary']['entries']:
        require((row['verdict'] is None and row['report_ref'] is None) if row['execution_status']!='EXECUTED' else (row['verdict'] is not None and row['report_ref'] is not None),'fake verdict on unreached gate')
    def wrong_score(r):r['overall_score']['coverage']=0.5
    def fake_pass(r):r['decision']['verdict']='PASS'
    def dangling(r):r['findings'][0]['evidence_ids']=['BAD-ID']
    def repeated(r):r['obligation_results'].append(copy.deepcopy(r['obligation_results'][0]))
    def mixed(r):r['scope']['attempt_id']='WRONG-ATTEMPT'
    def omitted(r):r['obligation_results']=[]
    def bad_trace(r):r['decision']['rule_trace'][0]['evidence_ids']=['BAD-ID']
    def absent_ref(r):r['evidence'][0]['artifact']=None
    cases=[wrong_score,fake_pass,dangling,repeated,mixed,omitted,bad_trace,absent_ref]
    for change in cases:
        rr=copy.deepcopy(args[0]);change(rr)
        try:validate_report(rr,*args[1:])
        except Exception:continue
        raise AssertionError(f'negative test unexpectedly accepted: {change.__name__}')
    print(f'PASS: {len(SCHEMAS)} JSON Schemas checked, {len(EXAMPLES)} synthetic examples validated, cross-record arithmetic and references checked, {len(cases)} negative fixture tests rejected.')
    print('LIMITATION: This is a fixture validator, not an implemented conformance service or production authorization check.')
if __name__=='__main__':main()
