# Implementation sequence — V7

Read all root architecture documents and schemas before changes. Execute in this order (the new prompts are intentionally inserted before dependent stages). At every stage record actual files, implementation status, exact test commands/output, evidence references, blockers and ADR changes. Do not mark scaffolding as implemented. Keep existing repository work intact.

| Order | Prompt | Deliverable / stage exit |
|---|---|---|
| 1 | `00-discovery.md` | Map real commands, approval states, native validate/verify, SDK, build, runtime instrumentation, sources and trust boundary |
| 2 | `01-scoring-and-policy.md` | Registry, deterministic counts, applicability, policy, per-gate report and negative tests |
| 3 | `08-evidence-contract-and-audit.md` | Typed retrieval, secure provenance, evidence storage, rationale, report validation and authorization interface |
| 4 | `02-intent-gate.md` | Persist source intent; actual Gate 1 intra-command checkpoint |
| 5 | `03-design-implementation-gates.md` | Gate 2 and Gate 3; independently extracted executable IR and native findings |
| 6 | `04-runtime-invariants.md` | Code, inference, data/schema guards, actual sandbox execution |
| 7 | `09-native-baseline-and-agentic-loop.md` | Integrate native checks, instrument three runtimes, enforce bounded remediation and execute protected boundary tests |
| 8 | `05-end-to-end-conformance-benchmark.md` | Isolated gates, strict real authoring and transaction replay; distinct labeled reports |
| 9 | `06-metrics-and-calibration.md` | Per-gate metrics, threshold calibration, paired baseline ablations, held-out qualification |
| 10 | `07-integration-and-demo.md` | End-to-end acceptance tests and demo with evidence-grounded reports/ADR ledger |

Stages can continue in independent safe portions if integration blocked. Stop for authorized business/data decisions, not routine local development. No automatic real approval. Never weaken mandatory checks to obtain a demo. Maintain a durable ledger with status IMPLEMENTED/PARTIAL/BLOCKED, exact commands and observed results, evidence and next steps. Do not delete unrelated changes or commit/push/deploy. Production certification requires actual independent benchmark results and approved risk criteria. `tools/validate_contracts.py` checks supplied synthetic fixture arithmetic and schema shape; extend with repository-specific semantic and enforcement tests.
