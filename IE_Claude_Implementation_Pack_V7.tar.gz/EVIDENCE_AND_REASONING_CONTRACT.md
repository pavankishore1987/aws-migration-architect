# Evidence retrieval, reasoning and audit contract — V7

## Architectural intent

The evaluator must not infer what the repository contains from conversation history. It requests evidence through a controlled adapter, receives a versioned manifest and evaluates only the authorized snapshot. The collector is responsible for the observation and its provenance; the evaluator is responsible for the interpretation. The scorer resolves findings against a versioned obligation registry, and the policy engine issues a decision with an explicit rule trace. Persist all four separately so a reviewer can distinguish a fact, an interpretation, an arithmetic result and an authorization. The contract stores **auditable reasoning summaries, criteria, source references, counterexamples, assumptions, limitations and policy rule outcomes**, not hidden model chain-of-thought. A model explanation is not proof; a reference must exist and support the claim. Do not request or persist private scratchpad/hidden reasoning or unredacted prompts merely to obtain an audit trail.

![Evidence architecture](diagrams/evidence-contract.svg)

## Wire contracts (JSON Schema Draft 2020-12)

| Contract | Producer → consumer | Purpose |
|---|---|---|
| [obligation-registry](schemas/obligation-registry.schema.json) | Approved-intent service → planning/scoring | Atomic obligations, source references, criteria, applicability dimensions, enforcement phase and criticality |
| [evidence-request](schemas/evidence-request.schema.json) | Evaluation planner → collector | Explicit selectors, snapshot, obligation IDs, allowed classification, as-of time, deadline and size cap |
| [evidence-response](schemas/evidence-response.schema.json) | Collector → evaluation engine | Immutable content references, collection metadata, schema identity and missing/denied/stale/truncated evidence |
| [evaluator-finding](schemas/evaluator-finding.schema.json) | Checker or judge → aggregator | Category result, criterion-by-criterion rationale, counterexample, evidence references, evaluator/rubric/model identity |
| [execution-event](schemas/execution-event.schema.json) | Execution harness → evidence store | Correlated execution/node/inference/schema/guard events and elapsed duration |
| [gate-report](schemas/gate-report.schema.json) | Aggregation + policy → audit store | Evidence manifest, findings, resolved obligations, scores, calibration snapshot, policy trace and verdict |
| [gate-authorization](schemas/gate-authorization.schema.json) | Trusted policy issuer → protected boundary | Signed/verified authorization reference for a current PASS only |
| [gate-benchmark-report](schemas/gate-benchmark-report.schema.json) | Separate benchmark runner → reporting | Per-gate confusion matrix, metrics, cohort, reachability, qualification |

All schemas are standalone with the same proposed wire version 1.0.0. `examples/contracts/` contains coherent synthetic examples, not actual observations, credentials, or attestations. The actual source system must supply artifact bytes, digests and access credentials. Approval and authorization locators are references, not bearer credentials. No successful authorization example is issued by this pack. The V4 examples outside that directory are legacy arithmetic fixtures, not V7 wire-format messages. JSON Schema checks shape; validate identifiers, digests, scope, policy, applicability, authorization and arithmetic in application code. A future incompatible schema change requires a major version and explicit migration; maintain reader compatibility or fail closed. Never allow a data file to change the evaluator's schema or policy. A JIT business schema is *data* under this contract, not the evidence envelope schema.

## Request and retrieval protocol

1. The orchestrator creates `(change_id, run_id, attempt_id, gate, snapshot_digest)` and binds registry/policy/upstream authorizations to the same immutable dependency manifest. Compute the snapshot digest over a canonical sorted artifact manifest including content digests, build/configuration, approved intent and relevant policy; define canonical bytes explicitly. Use SHA-256 over bytes for individual objects; a hash is not proof of origin.
2. Resolve the applicable obligation instances (gate + obligation ID, with criteria and due phase) from the approved registry. Build typed requests for each relevant source. Requester identity and data classification are declarations that the trusted collector must independently authorize. A selector is an opaque, adapter-specific allowlisted selector, not arbitrary SQL, shell code or a remote URL. Use read-only adapters for repo files, BPMN, native OpenSpec results, build/test outputs, Graphite graph export, runtime traces, model responses, approved data sources and schema providers.
3. The collector validates scope, caller, deadlines, allowed paths/source IDs, least-privilege permissions and expected hashes. Prevent path traversal, symlink escape, SSRF, arbitrary execution and unapproved network egress. Treat retrieved content as untrusted data, including instructions embedded in files. For actual run-specific data, bind as-of time, transaction ID via scope metadata, source revision and schema snapshot. For large evidence return a manifest plus bounded chunks/cursors via adapter-specific extension; never claim complete evidence if truncated or not collected. Retry idempotently by request ID and snapshot; conflicting reuse is an error. If unavailable, return a typed status rather than an empty success. No real transaction side effects in benchmark/authoring execution.
4. Store immutable bytes or an approved restricted-store reference; return digest, object locator, media type, observed time, collector identity/version, redaction status, and linked obligation IDs. If available, artifact ref is mandatory. Record schema artifact ref for schema-interpreted evidence. If the contract cannot supply mandatory JIT data at design time, distinguish the readiness obligation from the per-transaction satisfaction obligation. An unresolved readiness requirement is inconclusive; a future transaction check is not due at G3 and must appear in the runtime enforcement plan.
5. Context assembly retrieves only required evidence, keeps the authoritative source separate from target artifacts, resolves source references to exact excerpts, records the canonical context digest and rubric version; no answer-key labels or author conversation in the independent judge context. For restricted data redact/minimize before any approved model inference; raw data, PII, secrets, and model payloads are not committed to Git.
6. Evaluators return one or more findings per obligation. Verify the exact source/target spans, evidence scope/digests, criterion coverage and counterexample claims. Check deterministically where possible. A citation existing does not prove it supports the conclusion. Material conflict without resolution is inconclusive; a verified mandatory counterexample takes precedence over positive votes. Treat unsubstantiated conclusions as inconclusive. Never mark missing checks as NOT_APPLICABLE; applicability must come from approved policy and registry.
7. Resolve to exactly one result per applicable obligation instance, retaining all individual findings. Recompute dimension scores and overall scores (deduplicate across dimensions). Store counts, numerator/denominator, explicit missing/unmeasured statuses and confidence profile/version; do not infer confidence from scores. Evaluate gate-specific ordered rules and persist relevant rule outcomes and reason codes. A report contains evidence summaries/references, not unrestricted copies of all raw data.
8. Persist immutable attempt-specific records and manifest atomically, including report digest (outside the hashed report to avoid self-reference). Only then can the trusted issuer produce an authorization for an allowed operation. At operation consumption verify issuer/signature, current artifact manifest, expiration, policy and upstream approvals. Prevent time-of-check/time-of-use substitution by executing against the same immutable snapshot or enforcing revision lock. Local hooks alone may be bypassable; protect delivery using an independently controlled CI/service boundary. Any storage/verification failure denies progression. Record boundary allow/deny events separately. Human adjudication adds signed evidence or authorized amendments, not fabricated PASS; rerun.
9. Benchmark runner reads the immutable report and privately held expected label after evaluation. Write independent reports for G1/G2/G3; keep real generation, isolated fixture and transaction replay cohorts separate. Unreached gates are NOT_EXECUTED, no fake verdict. Aggregate benchmark statistics never alter the historical authorization.

## Reasoning and evidence storage

| Record | What is persisted | Why |
|---|---|---|
| Observation | Content digest, locator, source timestamp, schema/collector version, redaction | Reconstruct what was inspected |
| Evaluator rationale | Summary, criterion expected/observed result, evidence IDs, counterexamples/verification, assumptions and limitations | Explain the finding without storing private chain-of-thought |
| Resolution rationale | Which findings were retained, conflicts and how resolved | Explain aggregation, prevent vote-only acceptance |
| Policy trace | Ordered evaluated rules, outcome, reason codes, blocking IDs | Reproduce progression decision deterministically |
| Benchmark result | Private expected label, actual result, observed allow/deny, config, reference to report | Evaluate checker and actual enforcement |
| Human adjudication | Authorized actor, time, old/new evidence or amendment, decision rationale | Preserve accountability and invalidate superseded approvals |

Store raw evidence in an approved object/artifact store when sensitive or large; use an access-controlled local content-addressed store for PoC. Keep the metadata index and append-only run manifests separately. Do not publish internal evidence in public GitHub. Use approved retention and deletion schedules, encryption, audit logs, RBAC and tenant segregation; raw data access must be narrower than report access. Reports refer to immutable evidence but retention may remove raw data, in which case audit replay is explicitly unavailable, never reconstructed from imagination. Audit log access and policy updates; version models, prompts/rubrics, adapters and decision rules. Store model output and prompt-template identifier/digest when authorized; no secrets or internal model scratchpad. For probabilistic findings, record evidence-grounded justification and reproducible evaluation inputs, not a promise of deterministic model output.

## Logical APIs (proposed, not existing endpoints)

| Operation | Request / response | Contract behavior |
|---|---|---|
| `collect(request)` | evidence-request → evidence-response | Scope bound, bounded, read-only, explicit failure statuses |
| `evaluate(obligation, evidence)` | registry item + manifest → evaluator-finding | Isolated context with rubric, no benchmark labels |
| `report(snapshot, findings)` | resolved findings → gate-report | Validate provenance and arithmetic before store |
| `authorize(reportRef, protectedOperation)` | report reference → gate-authorization or denial | Only current durable PASS may authorize |
| `consume(authorization, currentSnapshot)` | authorization → actual allow/deny audit event | Independently enforce at the operation boundary |
| `benchmark(gate, dataset, configuration)` | private labeled results → gate-benchmark-report | Separate from live authorization |

Use local CLI/library adapters first unless the repository needs a network API. Keep these interfaces transport-independent; JSON Schema validates payloads, not caller authorization. Do not create a generic arbitrary file fetch endpoint.

## Required semantic checks beyond JSON Schema

- Unique evidence, finding, obligation, request IDs in scope; no dangling references, duplicate obligation resolutions or mixed snapshots. Match requested sources, selectors, required kinds, approved revisions, schema compatibility, as-of and time budget; no access escalation by the requester. Verify bytes/digests with trusted store and authentic source.
- `AVAILABLE` requires a verified artifact reference; `SATISFIED`/`VIOLATED` require sufficient validated evidence. Actual policy/rubric defines sufficiency. Unverified claims do not count as confirmed violations. `NOT_APPLICABLE` must be explicitly policy-approved and justified. Per-transaction checks not due at authoring are represented by separate due-phase entries, not hidden missing evidence.
- Resolve every due obligation exactly once; compare against registry (cannot drop missing entries). Score counts equal resolved statuses; nullable ratios if no applicable population. Dimension membership must match registry. Numerator/denominator and units explicit; zero denominators yield NOT_APPLICABLE/null, not 100%. Do not double-count dimensions.
- A confirmed critical/mandatory violation forces FAIL; unresolved mandatory obligations force HUMAN_REVIEW unless FAIL already applies. Missing calibration for required probabilistic decision forces review. Validate freshness, identity, approval/integrity, policy acceptance thresholds and issuer authorization outside shape validation. Empty required evaluations never PASS. Not-ready and not-executed entries belong to lifecycle ledger (no gate verdict).
- Benchmark matrix rows expected and columns actual; sum equals reached labeled cases. Confirmed defect detection and blocking rates are distinct; include denominator, unknown cases and confidence interval. No report or fixture grants production authorization; the examples intentionally include a failed gate.

## Minimal local storage layout

```text
run-store/<change>/<run>/<attempt>/<gate>/
    snapshot-manifest.json
    registry-ref.json
    requests/<request-id>.json
    responses/<request-id>.json
    findings/<finding-id>.json
    report.json
    report-manifest.json
    authorization.json        # only when actually issued
    boundary-events.jsonl
    execution-events.jsonl
    adjudications.jsonl
objects/<sha256>             # restricted evidence, or external secure locator
benchmarks/<benchmark-run>/<gate>/<config>/
    case-results.jsonl
    benchmark-report.json
```

Layout is conceptual; discover repo conventions. Store each gate and attempt independently. Use a transaction or atomic writes with verified manifest and fail-closed recovery. Cache only by snapshot, collector/evaluator/rubric/model configuration, schema/as-of and policy, and do not reuse stale authorization. A mutable latest pointer is informational only. A failed attempt is retained; removal of sensitive evidence follows approved retention policy.

## Supplemental audit records and score population

Four additional JSON Schemas are supplied: `boundary-event` (actual observed allow/deny), `benchmark-case-result` (private label joined after evaluation), `lifecycle-summary` (not-ready/unreached statuses without fake verdict), `adjudication-record` (human-authorized evidence or amendment; fresh evaluation required). There are 12 schemas in total. Fixture locators and digests are synthetic placeholders, not verified objects in an actual artifact store; a production implementation must verify actual bytes and authenticated provenance. `gate-authorization` and `adjudication-record` have intentionally no positive authorization/approval example.

For blocking scorecards use due mandatory and critical obligation instances as the default population `ALL_MANDATORY`; advisory-only populations are separately identified and never gate progression. Dimension scorecards may overlap and explicitly label their population. Store the full resolved registry including advisory and explicit N/A entries; partition by criticality and due phase before computing a score. Supplemental metrics include dimension, cohort, config_id, status/reason, sample_count and method (units explicit). The example has a single mandatory obligation. For a zero denominator report null with NOT_APPLICABLE; for an unavailable metric report null with UNMEASURED. Performance percentiles have no ratio numerator/denominator; use sample counts and method.
