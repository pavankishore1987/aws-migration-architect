# Stage 3 — Gate 2 and Gate 3

Implement actual Gate 2 before apply: requirement-to-proposal/design/task mapping, scope and design fidelity, task completeness/dependencies, cross-artifact consistency, invariant enforcement design, inference and JIT schema readiness. Use context G2 dimensions; validate approved upstream snapshots and authorization. Check absence of implementation tasks or enforceability plans as violations when required. Test supported equivalents, omissions, contradictions, missing data/inference guard design and direct apply invocation.

Implement Gate 3 after actual apply/verify and tests, before protected downstream delivery: expected BPMN -> normalized workflow IR; actual executable Java/Graphite workflow -> independent IR via initialized graph introspection if supported, or validated restricted static/bytecode extraction. Actual extractor cannot read expected BPMN as its source and cannot simply copy tags. Preserve ArchUnit checks as traceability only. Compare normalized node and edge identities, branch semantics, reachability, joins, terminal/exception behavior; note supported subset and transformations. Export reconstructed BPMN or graph for human review if practical. Use independent tests and evidence for predicates, behavior and invariants; do not confuse equal topology with semantics. Use runtime traces as observed evidence, not proof of all possible paths. Incomplete extraction -> review, not PASS.

Test same tags/wrong actual edge, unreachable node, missing exception, reversed predicate with unchanged topology, allowed refactor, unsupported dynamic routing, task checked but absent code, generated tests passing while independent test fails. Provide exact graph diff, precision/recall, independent scenario metrics, invariant readiness and protected-action result. If real SDK extraction unavailable, implement interface/test fixture, label it synthetic and leave production check unresolved. Bind current upstream and code/build digests to G3 verdict.


## Retained gate acceptance requirement

G2 and G3 must each emit their own conformance report and blocking verdict; capture boundary enforcement. Test isolated downstream cases with approved upstream fixtures and sequential NOT_EXECUTED cases. Produce matching gate-specific benchmark case outputs.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
