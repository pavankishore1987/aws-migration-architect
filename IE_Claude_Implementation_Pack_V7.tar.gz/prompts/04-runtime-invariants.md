# Stage 4 — Code, inference and just-in-time data invariant enforcement

Use actual PRD invariants, not invented business rules. Implement registry fields for trigger/scope/predicate, multiple execution mechanism categories (CODE, LLM_INFERENCE, DATA_DEPENDENT), evaluation methods, criticality, evidence source, due phase, protected action and failure behavior. An invariant can span all three categories. Create linked G3 readiness and runtime satisfaction obligations when deferral is explicitly permitted. Missing current G3 evidence is not deferred automatically. G3 PASS cannot authorize a future transaction without its runtime checks.

CODE: implement or verify actual guard/transaction boundary and independent boundary, retry, idempotency, race and exception tests as applicable. LLM_INFERENCE: use approved actual model adapter with pinned available versions, structured outputs, grounding citations/validation, independent labeled examples, abstention, invalid output/timeout and adversarial tests. Never treat JSON or model certainty as proof. Independent judge is not the same as the production inference model; measure both. Apply deterministic action policy. DATA_DEPENDENT: implement approved schema resolver interface, as-of event time, schema version/digest/effective interval, source authorization, file digest/snapshot, unit and field semantics, freshness/compatibility check, deterministic validation and evidence binding. If schema is inferred, require authoritative validation before use. No silent coercion/defaults. Prevent TOCTOU through immutable snapshot or appropriate revalidation/atomicity.

Record transaction/invariant instance ID, method, evidence, schema/file IDs, model versions and satisfaction status; redact sensitive fields. Only runtime PASS authorizes protected side effects, FAIL/REVIEW routes to authorized safe outcome. Tests for missing/incompatible/stale schema, malformed/missing/valid-but-wrong data, old effective date, schema version change, unauthorized source, semantic field/unit mismatch, unavailable resolver, inference disagreement/timeout/unsupported evidence, code guard violated, retry/concurrency, and snapshot changed before side effect. Use approved replay fixtures and mocked irreversible actions; assert no action called if blocked. Report actual vs replay vs stub, and missing runtime integration as unresolved.


## Retained gate acceptance requirement

Separate readiness scorecards at G3 from runtime transaction-instance reports and calibration. In end-to-end trials runtime executes only after G3 PASS in sandbox. Record runtime NOT_EXECUTED if earlier block; no runtime truth inferred from authoring approval.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
