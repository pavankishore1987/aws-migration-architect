# Stage 1 — Shared conformance and scoring engine

Implement typed registry for obligations, dimensions, checks, normalized findings, evidence refs/digests, criticality, applicability, due phase, supported methods, evaluator version and policy version. Extract expected obligations independently of generated targets; allow SME-authored reference registry for the PoC. Consolidate multiple evaluator findings per obligation. Verified counterexamples override votes. Missing/stale/unsupported findings remain unresolved. Distinguish NOT_APPLICABLE and NOT_DUE with explicit authorization/reason. Enforce unique obligation IDs and prevent duplicate weighting. Implement a deterministic policy engine, separate from any LLM.

Implement per-dimension and gate counts S,V,U,N where N=S+V+U for due applicable mandatory obligations. C=S/N, coverage=(S+V)/N, uncertainty=U/N, violation=V/N; N=0 is N/A and requires validated scope. Provide bidirectional requirement/graph precision and recall, scenario coverage and outcome success separately, invariant readiness and runtime instance metrics. Use numeric values plus numerator/denominator and defined handling for zero denominators. Do not invent weights. Optional advisory scores are nonblocking unless policy says otherwise. Include raw agreement and separate calibrated risk profile; no average across gates. Generate JSON and readable scorecards including obligations, missing evidence and reason codes. Version evidence snapshots and authorization. Use explicit NOT_READY before approval, confirmed mandatory violation -> FAIL, otherwise unresolved/insufficient assurance -> HUMAN_REVIEW, otherwise PASS subject to all policy requirements. Only actual authorized PASS unlocks the next phase.

Tests: all satisfied, 99/100 with one critical violation, only unresolved, fail plus unresolved, missing mandatory check, duplicate judges, unauthorized N/A, N=0, stale evidence, no calibrated profile where required, evidence counterexample despite majority PASS, malformed output, approval absent. Verify deterministic repeatability and report exact values and decisions. Implement interfaces for per-gate and runtime adapters. Do not substitute a report file for real enforcement.


## Retained gate acceptance requirement

Implement report contracts and metric null semantics from GATE_REPORTING_AND_BENCHMARK_CONTRACT.md. Test S/V/U counts, stable gate/attempt identity, atomic report write failure, verdict digest and separate authorization. Benchmark labels never enter evaluator context.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
