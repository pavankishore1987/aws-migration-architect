# Stage 2 — Intent persistence and Gate 1

Persist the exact original PRD/prose during actual propose-intent ingestion, with source digest and change ID, before generating draft spec and BPMN. Keep immutable baseline, separate approved clarification/amendment events with provenance; no circular reconstruction from final spec. Reuse questions inside spec.md and existing human spec finalization/approval, bind approval to exact revision, reconcile BPMN against final spec. Inside propose-design, after approval and reconciliation, freeze evidence, run Gate 1 before any proposal/design/tasks generation. Build wrapper/checkpoint and explicit resume path if necessary; never place Gate 1 at end of propose-intent. Gate 1 must be enforceable independently of the LLM. If no such local boundary exists, document limitations and implement a deterministic protected-phase PoC.

Implement all G1 dimensions from context: baseline/approval, completeness, semantic correctness and invented scope, testability, BPMN XML/graph validity, scenario/path correspondence, invariants. Independent evaluator sees source/target/rubric only; structured citations and counterexamples. Use deterministic checks where possible; unavailable semantic evaluator does not pass. Support bounded exploration and explicitly classify unsupported BPMN constructs. Emit dimension and gate metrics as Stage 1 specifies.

Tests: draft can exist without verdict; unapproved spec cannot start design; legit clarified requirement maps to BPMN and passes configured checks; unauthorized contradiction, dropped/invented requirement, stale BPMN, disconnected node, invalid edge, missing exception branch, unresolved required question, missing PRD, stale approval, human review, timeouts, direct bypass attempt. Demonstrate no design output from protected generation on blocked verdict, then remediation + fresh approval/recheck succeeds. Preserve earlier artifact history.


## Retained gate acceptance requirement

Gate 1 writes its report and verdict inside propose-design before technical design. Benchmark mode emits its case result after decision, with private label joined externally. Test downstream NOT_EXECUTED on block and fresh attempt on remediation.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
