# Stage 0 — Repository discovery and design decisions

Read the context, architecture and master prompt. Inspect actual custom OpenSpec instructions, approval state and user clarification flow, command invocation, Claude permissions/hooks, Java workflow registration/execution, build modules, BPMN subset, test framework, business PRDs/transactions, authorized model endpoints and JIT schema/file resolver. Do not infer APIs or business rules. Identify concrete code locations and protected operations, including whether direct calls bypass the wrapper and whether CI has an authoritative release boundary. Trace how a change ID survives sessions. Record actual paths, current tests, and source commit. Identify data access and inference restrictions; no secrets in outputs. Run a safe baseline test if possible.

Deliver a file-level ADR and phased plan. Identify desired vs supported features and owners of the remaining decisions. Make the testable security boundary explicit. Use existing tooling rather than inventing an unnecessary platform. Acceptance: current-state diagram, input availability checklist, build/test baseline, and no modifications outside scope. Continue independent stages if real input or SDK access is blocked.


## Retained gate acceptance requirement

Identify independent label/oracle storage, report storage, stage attempt IDs, gate enforcement and benchmark execution mode boundaries. Check real PRD and transaction availability, not a presumed domain.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
