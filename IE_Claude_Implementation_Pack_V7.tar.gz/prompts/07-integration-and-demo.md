# Stage 7 — Integration, enforcement and leadership demo

Run existing and added unit/component/integration tests. Test actual gate boundaries for PASS, FAIL, REVIEW, NOT_READY, timeout, malformed response, absent report, invalid signature/digest if implemented, artifact modified after authorization, policy/evaluator version change, stale upstream approval, direct protected command, and attempted agent bypass. Runtime must protect side effects separately. Capture observed effects and trust boundaries; local wrapper is not authoritative CI unless independently protected. Add audit/resume flow; never auto-approve real business intent. Verify reports against oracle and exact versions. Validate any claims using actual commands and outputs.

Produce a concise demo runbook: (1) real approved business PRD when accessible, otherwise labeled synthetic; (2) draft -> human clarification -> approved snapshot; (3) Gate 1 detects stale BPMN then rerun on corrected snapshot; (4) Gate 2 stops absent invariant design; (5) Gate 3 reverse extraction detects wrong edge despite correct tags; (6) approved workflow executes valid transaction and blocks missing JIT schema or ungrounded inference; (7) show per-gate dimensions, numerical scores and actual blocking outcomes; (8) benchmark comparison and confidence support. Distinguish independent checks, test fakes, real inference, replay and actual observed results. Include fallback demo for blocked data access. Provide exact reproducible commands and black/white diagrams as needed; no production deployments or pushes.

Final report: current implementation vs target, changed files, test observations, per-gate scorecards and decisions, runtime results, dataset provenance/splits, baseline vs candidate comparisons, calibration profile or insufficiency, risk/coverage tradeoff, unresolved blockers, proposed pilot and explicit risk-owner approvals. Do not claim certification while required evidence is missing. Do not replace implementation with documentation alone.


## Retained gate acceptance requirement

Demonstrate independent report pairs and real enforcement for each gate: G1 PASS then G2 FAIL then G3 NOT_EXECUTED; isolated G3 wrong-edge FAIL; all-pass end-to-end and runtime review on missing schema. Show benchmark expected-vs-actual rows, separate gate matrices and first/final cohort; show no production authorization from benchmark reports. Run all seven contract acceptance test groups.


### V7 integration requirement
Use the versioned evidence/reasoning contracts and measurement architecture in the handoff root. Follow the revised implementation sequence (Stage 08 after Stage 01; Stage 09 after Stage 04). Preserve structured criterion-level rationale, evidence references and policy trace, not hidden reasoning. Record changes and actual test observations in the implementation ledger; compare choices with the ADR register. Legacy conceptual examples are not the authoritative new wire format.
