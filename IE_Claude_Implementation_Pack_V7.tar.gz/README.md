# Intent = Execution (I=E): Conformance in Spec-Driven Development

**V7 implementation handoff:** Start with [START_HERE.md](START_HERE.md). The full design is supplemented by the [architecture decision register](ARCHITECTURE_DECISIONS.md), [evidence and reasoning contract](EVIDENCE_AND_REASONING_CONTRACT.md), [measurement and execution architecture](MEASUREMENT_AND_EXECUTION_ARCHITECTURE.md), and [implementation sequence](IMPLEMENTATION_SEQUENCE.md).

**V7 reporting requirement:** Each gate emits an independent conformance report, dimension scorecard and blocking verdict. During benchmarking each reached gate also emits an independent benchmark case result and gate-level aggregate report. See [Gate reporting and benchmark contract](GATE_REPORTING_AND_BENCHMARK_CONTRACT.md) for the authoritative execution, reporting, metrics and authorization rules.

> Architecture proposal · Revision 7 · Working design for engineering review

## 1. Background

OpenSpec provides a structured way to author software changes using an agentic coding harness. In our workflow, Claude Code interprets the input intent, reads the repository context and OpenSpec instructions, generates the change artifacts, implements the change, and runs verification. This helps us move from business requirements to executable code without requiring every intermediate artifact to be written manually.

The remaining problem is assurance. Successful execution of an authoring command, completion of a task checklist, or a passing unit test suite does not by itself establish that the resulting implementation preserves the original business intent. An incorrect assumption introduced in the specification can propagate through the design and into otherwise well-tested code.

We propose introducing independent conformance checks at three transformation boundaries. Each boundary has its own verdict and controls whether the next phase is authorized. The objective is to detect deviations at the point they are introduced rather than relying exclusively on end-of-cycle verification.

This document describes the proposed architecture, evaluation criteria, decision policy, and benchmark methodology. It does not claim that these controls have already been implemented or statistically validated.

## 2. Authoring lifecycle and intent finalization

We split the OpenSpec proposal phase into `propose-intent` and `propose-design`. The important correction is that the former produces a **draft** specification and BPMN, not the final contract. The initial steps of `propose-design` continue intent authoring: questions are recorded in `spec.md`, the user supplies answers, the specification is updated, and the authorized user moves it to the approved state. The BPMN must be synchronized with the final specification before evaluation. Technical design generation must not begin until Gate 1 returns PASS.

| Command / phase | Responsibility | Output or control |
| --- | --- | --- |
| `propose-intent` | Capture original PRD/prose and invariants; draft Gherkin-style requirements and BPMN. | Persisted source intent, draft spec, draft BPMN |
| `propose-design` — finalization | Resolve clarification questions in spec.md, record authorized requirement changes, synchronize BPMN and obtain user approval of the final spec. | Approved intent snapshot |
| `propose-design` — Gate 1 | Evaluate effective intent against finalized spec and BPMN. | PASS permits technical design; FAIL or HUMAN REVIEW blocks it |
| `propose-design` — design | Produce proposal, design and task breakdown from the Gate 1-certified snapshot. | `proposal.md`, `design.md`, `tasks.md` |
| Gate 2 | Evaluate design and tasks against certified intent. | PASS permits apply |
| `apply` / `verify` | Implement, run unit/component tests and remediate; verify implementation completeness. | Java code and test evidence |
| Gate 3 | Evaluate model-to-code conformance and invariants. | PASS authorizes protected downstream delivery |

Exact command aliases, file paths, approval fields and integration mechanisms must be confirmed in the target repository.

```mermaid
%%{init: {'theme':'base','themeVariables':{'primaryColor':'#ffffff','primaryTextColor':'#000000','primaryBorderColor':'#000000','lineColor':'#000000','clusterBkg':'#ffffff','clusterBorder':'#000000'}}}%%
flowchart TD
    P[Original PRD and invariants] --> I[OPSX propose-intent]
    I --> M[Persist original intent]
    I --> S[Draft spec and BPMN]
    subgraph PD[OPSX propose-design]
      direction TB
      Q[Clarification questions in spec.md] --> U[User answers and spec updates]
      U --> F{Spec finalized and approved?}
      F -->|No| Q
      F -->|Yes| Y[Reconcile BPMN and freeze approved inputs]
      Y --> G1{Gate 1: Intent conformance}
      G1 -->|PASS| D[Generate proposal, design and tasks]
    end
    S --> Q
    M --> G1
    D --> G2{Gate 2: Design conformance}
    G2 -->|PASS| C[OPSX apply and verify]
    C --> G3{Gate 3: Implementation conformance}
    G3 -->|PASS| R[Authorize protected delivery]
    G1 -->|FAIL or HUMAN REVIEW| B[Block affected phase; remediate or adjudicate]
    G2 -->|FAIL or HUMAN REVIEW| B
    G3 -->|FAIL or HUMAN REVIEW| B
    classDef mono fill:#ffffff,stroke:#000000,color:#000000;
    class P,I,M,S,Q,U,F,Y,G1,D,G2,C,G3,R,B mono;
```

Gate 1 is an intra-command execution boundary inside `propose-design`; Gate 2 and Gate 3 retain their earlier placement. Gates are aligned to artifact maturity rather than command names. A draft is not a failed conformance result: it simply is not eligible for Gate 1. While waiting for user approval, the protected design phase remains blocked.

### 2.1 Intent persistence and baselining

The PRD is only supplied to `propose-intent`. Capture the original input verbatim into a durable, change-scoped artifact before generating anything. Do not rely on Claude Code conversation history, context compaction, or a generated specification to reconstruct the original PRD. If the input points to a file, snapshot its actual content and retain provenance. Preserve business invariants with source references. Store the baseline with a digest and protect it against silent modification; a digest alone does not enforce immutability.

The clarification questions and user responses remain in `spec.md` according to the current workflow. A separate decision ledger or a normalized snapshot of those sections may be used to preserve the question, answer, source requirement, actor, time and disposition. Do not require a second user-facing clarification file if the existing metadata can capture this information reliably. Distinguish a clarification from an actual change of scope: a contradiction to the original PRD requires explicit authorized supersession, not silent rewriting. Unresolved conflicts prevent approval or cause human review.

The **effective intent** is the original PRD plus approved clarification and amendment decisions, with explicit precedence and provenance. Human approval of the finalized specification is not the conformance verdict. Gate 1 independently examines the approved spec, synchronized BPMN and effective intent. This avoids rejecting legitimate clarification details as hallucinated requirements and avoids allowing unauthorized changes to masquerade as clarification.

Proposed persisted lifecycle states: `DRAFT`, `CLARIFICATION_REQUIRED`, `UNDER_REVIEW`, `APPROVED`, `CONFORMANCE_PENDING`, `CONFORMANCE_PASSED`. FAIL and HUMAN REVIEW are separate blocked outcomes. Map these conceptual states onto existing repository conventions rather than introducing redundant state. If remediation changes the approved spec or any governing intent, invalidate the approval and obtain a fresh one; if only BPMN changes, recheck its consistency, invalidate the gate authorization, and obtain any artifact approval required by policy. Re-run affected gates. Capture a fixed snapshot for each run and check it again at consumption time.

See also the [monochrome lifecycle diagram](diagrams/lifecycle.svg) and [round-trip comparison diagram](diagrams/round-trip.svg).

## 3. Conformance model

We distinguish three dimensions of conformance. Each provides a different kind of evidence, and none can replace the other two.

| Dimension | Question | Typical mechanism |
| --- | --- | --- |
| Structural | Is the artifact well formed, and does it preserve required relationships and control flow? | Schema validation, graph analysis, static checks |
| Semantic | Does the artifact preserve the meaning of the source requirements? | Business-rule comparison, deterministic predicates, evidence-based LLM evaluation |
| Behavioral and invariant | Does the implementation exhibit the required behavior without violating business safety properties? | Scenario tests, runtime traces, property-based tests, model checking where feasible |

A BPMN document can be structurally sound and still have an incorrect business condition. Likewise, a Java implementation can contain every expected node annotation but route execution to the wrong destination. We therefore evaluate the dimensions separately and aggregate their findings only at the decision boundary.

## 4. Gate 1 — Intent conformance

**Trigger:** Inside `propose-design`, after authorized approval of the finalized spec and reconciliation of BPMN; before any technical design generation.

**Input:** Persisted original PRD, approved clarification/amendment ledger, business invariants, approval evidence, finalized `spec.md`, and synchronized BPMN XML. All inputs must be versioned and digest-bound.

**Decision:** Is the structured specification and process model a sufficiently faithful representation of the effective, approved business intent to begin technical design?

The check starts with the effective source requirements, reconstructed from the original PRD and authorized decisions rather than from the target spec itself. Each mandatory requirement should have a traceable representation in the specification. Any material ambiguity or unsupported assumption must be surfaced rather than silently resolved by the authoring agent.

The BPMN model is then inspected as a graph. We validate its structure and compare its business paths and decision conditions against the scenarios defined in the specification. Extracting paths from the BPMN alone is not evidence that the process is complete; the expected scenarios must come from an independently established source.

| Check | Acceptance condition | Mechanism |
| --- | --- | --- |
| Approval readiness | Authorized approval matches the finalized spec; no unresolved mandatory clarification; persisted original PRD is available. | Deterministic / provenance |
| Clarification fidelity | Approved answers are applied correctly; unauthorized supersession is detected. | Hybrid |
| Requirement completeness | No mandatory effective-intent requirement is missing from the spec. | Semantic + traceability |
| Requirement soundness | No unauthorized business rule or contradictory interpretation is introduced. | Semantic |
| Scenario fidelity | Given/When/Then conditions and outcomes preserve the source intent. | Hybrid |
| BPMN validity | XML/schema and supported modeling constraints are satisfied. | Deterministic |
| Graph soundness | Required nodes are reachable; references and transitions are valid. | Deterministic |
| Scenario-to-path coverage | Required business scenarios map to feasible paths and expected outcomes. | Hybrid |
| Gateway semantics | Branch conditions, default flows, and joins preserve intended behavior. | Hybrid |
| Invariant coverage | Every applicable business invariant is represented or explicitly linked. | Hybrid |

For acyclic workflows, we can enumerate paths when feasible. For loops, parallel gateways, or large graphs, we must use explicit bounds, symbolic checks, or other appropriate graph algorithms. Unsupported constructs and incomplete coverage must be reported; we must not claim exhaustive validation where it has not been achieved.

## 5. Gate 2 — Design conformance

**Input:** Approved spec and BPMN from Gate 1, `proposal.md`, `design.md`, `tasks.md`.

**Decision:** Does the proposed design implement the approved intent without introducing unauthorized changes, omissions, or conflicting decisions?

This gate is primarily concerned with traceability and design completeness. A requirement can appear in the design document but still be missing a corresponding implementation task. Similarly, a task can be well defined while implementing behavior that contradicts the specification.

| Check | Acceptance condition | Mechanism |
| --- | --- | --- |
| Requirement-to-design mapping | Every mandatory requirement has a corresponding design realization. | Hybrid |
| Design fidelity | Proposed behavior is consistent with the approved spec and BPMN. | Semantic |
| Change scope | No unapproved change to business intent or mandatory constraints. | Semantic |
| Task coverage | Every required implementation obligation is assigned to one or more tasks. | Hybrid |
| Task dependencies | Explicit dependencies are valid and consistent with the design. | Deterministic / hybrid |
| Failure handling | Required error, retry, and recovery behavior is addressed. | Hybrid |
| Invariant realization | The design identifies how each invariant will be enforced and verified. | Hybrid |
| Testability | Mandatory scenarios have a corresponding verification strategy. | Hybrid |

A design may legitimately introduce technical details that are not stated in the PRD. The evaluator should distinguish ordinary implementation decisions from new business rules or changes to approved behavior.

## 6. Gate 3 — Implementation conformance

**Input:** Approved spec, BPMN, design, tasks, implemented Java workflow, compiled artifacts where applicable, and test evidence.

**Decision:** Does the implemented workflow preserve the approved business process, business rules, and invariants?

The first approach is to associate generated Java code with BPMN node identifiers and use ArchUnit-style checks to confirm that expected classes or methods are present and satisfy architectural constraints. This gives us traceability, but not control-flow equivalence. A tagged node may be disconnected, called in the wrong order, or routed from an incorrect gateway.

We therefore propose extracting the actual workflow definition from the Java implementation and comparing it with the approved business process model. Tagging remains useful for identifying corresponding business nodes, but the executable workflow registration and transition logic must be the source of the reconstructed graph.

### 6.1 Model-to-code-to-model verification

```mermaid
flowchart LR
    B[Approved BPMN XML] --> P[BPMN parser]
    P --> E[Expected workflow IR]
    J[Java / Graphite executable workflow] --> X[Independent workflow extractor]
    X --> A[Actual workflow IR]
    A --> R[Reconstructed BPMN for review]
    E --> C[Deterministic graph comparator]
    A --> C
    C --> F[Structural findings and graph diff]
    classDef stage fill:#ffffff,stroke:#111111,color:#111111;
    class B,P,E,J,X,A,R,C,F stage;
```

The reconstructed BPMN serves as an inspectable process model for engineers and business stakeholders. The machine comparison should operate on normalized workflow graphs rather than raw XML text. XML ordering, diagram coordinates, and insignificant serialization differences should not cause a failure.

The intermediate representation (IR) should capture business node identifiers and types, start/end events, directed transitions, guard conditions, gateway semantics, exception flows, and any supported execution semantics. The following is a simplified example, not a proposed production schema:

```json
{
  "nodes": [
    {"id":"start","type":"START"},
    {"id":"verify","type":"TASK"},
    {"id":"decision","type":"EXCLUSIVE_GATEWAY"},
    {"id":"approve","type":"TASK"},
    {"id":"reject","type":"TASK"},
    {"id":"end","type":"END"}
  ],
  "edges": [
    {"source":"start","target":"verify"},
    {"source":"verify","target":"decision"},
    {"source":"decision","target":"approve","condition":"eligible == true"},
    {"source":"decision","target":"reject","condition":"eligible == false"},
    {"source":"approve","target":"end"},
    {"source":"reject","target":"end"}
  ]
}
```

### 6.2 Extraction strategy

The first technical discovery should establish whether Graphite exposes the initialized workflow graph, including the actual registered nodes and transition metadata. If it does, extracting from the initialized workflow in an isolated component test is preferable to inferring business control flow from arbitrary Java source.

| Approach | Role | Limitation |
| --- | --- | --- |
| Graphite DAG introspection | Primary source of actual workflow registrations and transitions | Requires access to sufficient runtime graph metadata |
| Java AST analysis | Identify workflow declaration, predicates, and calls | Dynamic dispatch and configuration-driven routing can limit completeness |
| Bytecode analysis | Inspect compiled control flow and call relationships | Low-level control flow is not automatically a business process model |
| Runtime instrumentation | Verify observed node transitions and business outcomes | Cannot establish the absence of unobserved paths |
| LLM-assisted interpretation | Investigate unsupported constructs and explain discrepancies | Cannot independently certify complete deterministic extraction |

Extraction must be bound to the actual code and configuration under evaluation. It must not reconstruct its edges from the approved BPMN or trust a generated mapping manifest as proof of execution. Otherwise, the comparison becomes circular.

The direct export capability of the Graphite SDK has not yet been confirmed. If the extraction is partial or a dynamic construct cannot be represented, we should return an unresolved finding rather than assume a match.

### 6.3 Example: a defect that tagging cannot detect

```mermaid
flowchart TD
    subgraph Expected[Approved process]
      direction TB
      V1[Verify eligibility] --> G1{Eligible?}
      G1 -->|Yes| A1[Approve]
      G1 -->|No| R1[Reject]
    end
    subgraph Actual[Extracted Java process]
      direction TB
      V2[Verify eligibility] --> G2{Eligible?}
      G2 -->|Yes| A2[Approve]
      G2 -->|No: incorrect| A2
      R2[Reject - unreachable]
    end
    classDef stage fill:#ffffff,stroke:#111111,color:#111111;
    class V1,G1,A1,R1,V2,G2,A2,R2 stage;
```

All expected node IDs can be present in the Java implementation, so a presence check would pass. The extracted graph reveals a missing rejection transition and an unauthorized approval transition. The structural conformance verdict must therefore be `FAIL`.

### 6.4 Implementation verification criteria

| Check | Expected evidence |
| --- | --- |
| Node correspondence | Each required business node maps to an implemented node. |
| Transition correspondence | All mandatory transitions exist; no unauthorized transitions appear. |
| Gateway and join semantics | Required branching, default routes and synchronization are preserved. |
| Reachability and terminal outcomes | Required nodes and business outcomes remain reachable. |
| Predicate equivalence | Actual branch conditions preserve business decision rules. |
| Node semantic fidelity | Actual node behavior satisfies its associated requirements. |
| Scenario execution | Component tests exercise mandatory paths and check outputs and side effects. |
| Invariant enforcement | Static, model-level or behavioral evidence supports each applicable invariant. |
| Task completion | Task checklist claims are backed by implementation and test evidence. |

Exact graph equality should only be required when the supported modeling profile mandates it. A legitimate refactoring can introduce technical nodes or restructure control flow without changing business behavior. Define normalization rules and approved abstraction boundaries before comparing graphs. When topology alone is insufficient, verify gateway semantics, predicates, and observable behavior separately.

## 7. Business invariants

An invariant is a condition that is required to hold for every applicable reachable state or execution, subject to its defined scope and assumptions. It is not merely a happy-path scenario or a task that must appear in the checklist.

For example, a business user may define the following constraints:

| ID | Invariant | Implementation verification |
| --- | --- | --- |
| INV-001 | Funds must never be disbursed before an approval exists for the same application. | Graph/path constraints, approval-state checks, negative component tests |
| INV-002 | Repeated requests must not cause duplicate disbursements. | Idempotency contract, duplicate-request and concurrent execution tests |

An invariant should carry its source, scope, relevant state, assumptions, enforcement location, and verification method. The same identifier should be carried through the specification, design and code evidence. A missing mapping is a traceability issue; a demonstrated violation is a conformance failure.

Passing a finite set of tests does not prove an invariant for all possible executions. Where stronger assurance is required, use an appropriate formal model, model checking, transactional guarantees, or other verification methods with clearly stated assumptions. An LLM's assertion alone should not certify a critical invariant.

## 8. Common evaluation architecture

Each gate has its own evaluation criteria, but the evaluation machinery should be reusable. The authoring harness produces artifacts; a separate conformance execution context evaluates them against the approved inputs.

```mermaid
flowchart TD
    O[Conformance orchestrator] --> C[Artifact and evidence collector]
    R[Obligation registry and gate policy] --> C
    C --> S[Structural validators]
    C --> M[Semantic evaluators]
    C --> I[Behavioral and invariant validators]
    S --> A[Findings aggregator]
    M --> A
    I --> A
    A --> K[Calibration and evidence assessment]
    K --> V[Deterministic verdict engine]
    V --> Q[Gate report and authorization record]
    Q --> E[Enforcement boundary]
    classDef stage fill:#ffffff,stroke:#111111,color:#111111;
    class O,C,R,S,M,I,A,K,V,Q,E stage;
```

The orchestrator determines applicable checks and controls their execution. Evaluators do not have authority to advance the lifecycle. They produce findings with evidence; the verdict engine applies a versioned policy. The enforcement boundary consumes the resulting authorization record.

### 8.1 Conformance obligations

The atomic unit of evaluation is a conformance obligation: a requirement, constraint, structural property, or invariant that can be assessed independently. An obligation can have different checks at different gates. Its criticality and applicability must be established independently of the evaluator deciding whether it is satisfied.

Each evaluator should implement a common output contract. For example:

```json
{
  "gate": "IMPLEMENTATION",
  "obligationId": "INV-001",
  "checkId": "APPROVAL_BEFORE_DISBURSEMENT",
  "criticality": "CRITICAL",
  "evaluationType": "HYBRID",
  "status": "VIOLATED",
  "evidence": [
    {"artifact": "PaymentService.java", "location": "example: lines 118-134"},
    {"artifact": "ApprovalInvariantTest.java", "location": "example: rejectsPendingApproval"}
  ],
  "counterexample": {
    "approvalStatus": "PENDING",
    "disbursementExecuted": true
  },
  "evaluatorVersion": "invariant-checker-v1",
  "rationale": "The demonstrated execution allows disbursement while approval is pending."
}
```

The normalized statuses are `SATISFIED`, `VIOLATED`, and `INCONCLUSIVE`. A missing evaluator result, incomplete extraction, or unsupported construct must not be treated as satisfied. Advisory checks may be reported separately from mandatory obligations.

## 9. Scoring and gate decision policy

We should not use a weighted quality score as the sole pass criterion. A single unauthorized payment path cannot be compensated for by hundreds of successful structural checks.

Let `N` be the number of applicable, mandatory obligations, with `S` satisfied, `V` confirmed violated, and `U` inconclusive or not evaluated. Then `N = S + V + U`.

| Metric | Calculation | Interpretation |
| --- | --- | --- |
| Confirmed conformance | `S / N` | Proportion of obligations confirmed satisfied |
| Evidence coverage | `(S + V) / N` | Proportion conclusively assessed under the evaluation policy |
| Unresolved rate | `U / N` | Proportion for which evidence is insufficient |
| Node recall | `matched expected nodes / expected nodes` | Missing expected business nodes |
| Node precision | `matched actual nodes / actual nodes` | Unexpected business nodes |
| Edge recall | `matched expected transitions / expected transitions` | Missing expected transitions |
| Edge precision | `matched actual transitions / actual transitions` | Unauthorized transitions |

Node and edge metrics are computed on the normalized and mapped graph, including transition identities or conditions as appropriate to the comparison. A zero denominator should be reported as not applicable rather than assumed to be 100%. An empty mandatory-obligation set cannot automatically authorize a gate unless applicability has been independently validated.

### 9.1 Verdict policy

The proposed policy starts with fail-closed defaults. A confirmed mandatory violation blocks progression irrespective of the numerical conformance score. Human review is also a blocking outcome.

| Condition | Verdict | Progression |
| --- | --- | --- |
| At least one confirmed mandatory violation | `FAIL` | Block |
| No confirmed violation, but mandatory evidence is missing, ambiguous, contradictory or unsupported | `HUMAN_REVIEW` | Block |
| Semantic assessment does not meet the calibrated acceptance policy | `HUMAN_REVIEW` | Block |
| All applicable mandatory obligations are satisfied, required evidence is present and gate policy is met | `PASS` | Authorize next phase |

A verified counterexample takes precedence over judge consensus. An unverified allegation from one judge is not automatically a confirmed defect; it must be checked or escalated. Infrastructure failure also blocks progression, with an explicit technical error reason recorded separately from a business violation.

There is no combined average across the three gates. Each gate issues an independent verdict bound to the artifacts it evaluates.

### 9.2 Illustrative scorecards

| Gate | Obligations | Satisfied | Violated | Unresolved | Conformance | Evidence coverage | Verdict |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Intent | 20 | 20 | 0 | 0 | 100% | 100% | PASS* |
| Design | 15 | 15 | 0 | 0 | 100% | 100% | PASS* |
| Implementation | 40 | 39 | 1 | 0 | 97.5% | 100% | FAIL |

*Illustrative only; PASS assumes all applicable evidence-quality and calibration policies are satisfied. In this example the implementation failure is a confirmed invariant violation, so the 97.5% score does not permit progression.*

## 10. Semantic evaluation and confidence calibration

An LLM is useful where source and target artifacts contain meaning that cannot be sufficiently evaluated by a deterministic parser or rule engine. The evaluator should receive the source requirement, relevant target evidence, a specific obligation, and an evaluation rubric. It should not inherit the authoring conversation or be told what verdict the generator expects.

We should compare one-judge, multiple-judge, and adaptive-escalation configurations. Judges should initially evaluate independently. Their output should include concrete source and target evidence, not just an opinion or self-reported confidence number. Multiple judges can share model biases; unanimous agreement does not establish correctness.

Confidence calibration is separate from conformance scoring. For a given evaluator configuration and evidence pattern, calibration estimates how often comparable conclusions were correct on independently labeled examples. Start with empirical reliability buckets and use more sophisticated calibration only if the data supports it.

For example, if 196 of 200 comparable unanimous-positive cases are correct, the observed correctness rate is 98%. This is a hypothetical calibration result, not a guarantee that a new case is correct. The sample's uncertainty, representativeness, and defect mix matter. Gate-level confidence must be validated separately rather than averaging obligation-level confidences.

For production policy, choose thresholds using a pre-agreed false-acceptance risk tolerance. Evaluate thresholds on calibration data, then verify the selected policy on an untouched test set. If there is insufficient evidence to justify automatic approval, keep the gate in human-review or shadow mode while collecting more benchmark evidence.

## 11. Benchmarking the conformance framework

The benchmark is intended to establish whether a gate can be trusted to make a blocking or authorizing decision. It evaluates the **gate itself**, not just the artifacts generated by the authoring system.

### 11.1 Golden artifact chains

Create a repository of independently reviewed workflows, each with original PRD, invariants, draft spec/BPMN, clarification history, approved final spec/BPMN, approval evidence, design artifacts, code and tests. Business SMEs establish the expected behavior; engineering SMEs validate the technical artifacts and adjudicate defects. The authoring LLM should not be the sole source of labels.

For each workflow, retain clean examples, behavior-preserving alternatives, known defective artifacts and cases with intentionally insufficient or ambiguous evidence. Record the expected verdict, affected obligation IDs, defect class, severity, and supporting justification.

A single canonical implementation must not become the only valid answer. Include alternative conformant designs and implementations to measure whether the evaluator incorrectly rejects legitimate variation.

### 11.2 Defect taxonomy and mutation testing

Introduce controlled defects at the relevant artifact boundary, initially one defect per case to isolate detection capability. Then add multiple-defect cases and real defects from authoring runs. Do not label a syntactic change as defective if it preserves the required behavior.

| Gate | Representative benchmark cases |
| --- | --- |
| G1 | Missing PRD snapshot; stale or absent approval; unauthorized amendment; approved clarification omitted; stale BPMN after spec update; missing or invented requirement; reversed business condition; malformed XML; disconnected node; missing scenario path; wrong gateway type; omitted invariant; ambiguous intent |
| G2 | Missing design realization; contradictory design; task omission; invalid dependency; unsupported business assumption; absent recovery design; missing invariant enforcement |
| G3 | Tagged but disconnected node; missing or unauthorized transition; wrong branch target; changed predicate; incorrect join behavior; missing exception route; task falsely marked complete; invariant violation; concurrency or duplicate side-effect defect |
| All | Conformant alternatives; missing evidence; conflicting evidence; evaluator failure; unsupported constructs; attempts to bypass enforcement |

A useful starting demo is to preserve every Java node annotation while changing the rejection branch to approval. Compare tagging-only verification against the reverse-graph comparator. The desired result is that the latter detects the defect despite the presence of all node IDs.

### 11.3 Dataset construction and experimental design

Start with several independently reviewed workflow families, covering branching, external dependencies, failure and recovery, supported parallelism, and relevant invariants. Record measurable complexity attributes such as node count, gateway count, loop count, number of requirements, and artifact context size.

As an initial engineering target, create approximately 100 cases per gate (30 conformant, 50 nonconformant, 20 unresolved). This is a proposed discovery dataset, not adequate evidence of a particular production risk bound. Expand based on observed errors and defect coverage.

Maintain separate development, calibration and held-out datasets. Split by underlying workflow family, not by random mutations of the same workflow, to avoid leakage. Repeat runs to evaluate stochastic verdict stability, but do not count repeat runs or correlated variants as independent statistical observations.

### 11.4 Evaluator configurations

Run configurations against the same applicable cases, versions and rubric. Compare the existing authoring verification, deterministic checks, deterministic plus one LLM judge, two judges, three judges, and adaptive escalation. At Gate 3, additionally isolate the contribution of tagging-only versus reverse extraction, semantic evaluation, and runtime evidence.

| Metric | Calculation / interpretation |
| --- | --- |
| Critical defect escape rate | Critical defective cases receiving PASS / critical defective cases |
| False acceptance rate | Known nonconformant cases receiving PASS / known nonconformant cases |
| Unsafe progression rate | Expected FAIL or REVIEW cases receiving PASS / expected FAIL or REVIEW cases |
| Residual risk among approvals | Known defective approved cases / all approved cases; depends on the defect prevalence in the evaluated population |
| False rejection rate | Known conformant cases receiving FAIL / known conformant cases |
| Defect detection recall | Correctly detected labeled defects / labeled defects; review alone is not a confirmed detection |
| Automation coverage | Cases with definitive automated PASS or FAIL / all cases |
| Human review rate | Cases requiring review / all cases |
| Verdict stability | Repeated decision consistency under the same inputs and versions |
| Calibration quality | Observed correctness versus predicted probability, with uncertainty reported |
| Operational cost | Evaluation latency, token consumption and compute cost |

Report counts and denominators alongside rates. A benchmark intentionally enriched with defects should not be used to infer real-world approval risk without accounting for deployment prevalence.

### 11.5 Acceptance and statistical evidence

Prioritize critical invariant escapes and false acceptance over overall verdict accuracy. Define an acceptable error bound with risk owners for each gate and defect severity. The benchmark should establish whether the proposed configuration meets that bound while retaining useful automation coverage.

With zero observed false acceptances in `n` independent, representative nonconformant cases, the approximate one-sided 95% upper bound on the false-acceptance probability is `3/n` (the Rule of Three). The exact binomial bound is `1 - 0.05^(1/n)`.

| Zero-escape defective cases | Approximate upper error bound |
| ---: | ---: |
| 60 | 5% |
| 150 | 2% |
| 300 | 1% |
| 600 | 0.5% |

The denominator is known defective cases, not the entire dataset. This bound applies to the evaluated population under the stated assumptions, not to every future workflow or individual artifact. If errors occur, use an appropriate binomial confidence interval; if cases are clustered by workflow, account for that dependence. Critical defect categories may need separate validation rather than relying on a pooled average.

## 12. Gate enforcement and auditability

OpenSpec instructions and Claude Code skills can request a conformance check, but prompt compliance is not a security or authorization boundary. Enforcement must exist outside the LLM decision loop.

A deterministic command wrapper or controller should require a valid authorization record before starting the next phase. In `propose-design`, separate the finalization operation from the design-generation operation at an independently enforced phase boundary. A check at command entry or exit is insufficient for Gate 1. Inspect existing hooks and orchestration options; if they cannot enforce this boundary, use separate protected operations coordinated by the wrapper while retaining the user-facing command. Evaluate where protected repository or CI/CD controls are required so that a user cannot bypass local checks by invoking commands directly. Gate 3 should protect the relevant downstream integration or delivery boundary.

The authorization record should bind the verdict to the relevant upstream and downstream artifact digests, repository revision, applicable configuration, evaluator and policy versions, and any human adjudication. Store records in an appropriately protected location. A modification to an approved artifact invalidates the affected approval and dependent gate approvals.

Enforcement tests must cover unapproved draft, unanswered mandatory clarification, missing original PRD, stale approval, attempts to invoke design-generation early, resume after remediation, PASS, FAIL, REVIEW, missing records, stale or forged records, timeouts, malformed outputs, direct invocation, post-approval artifact changes, and authorized human resolution. If a human resolves an ambiguous or inconclusive finding, preserve the rationale and the identity of the approver. A confirmed mandatory violation should require remediation or a formally approved policy exception, not a silent override.

## 13. Proposed repository organization

The layout below is a starting point for discussion; align it with the existing OpenSpec and Graphite repositories before implementation.

```text
conformance/
  README.md
  policies/
    intent.yaml
    design.yaml
    implementation.yaml
  schemas/
    obligation.schema.json
    finding.schema.json
    workflow-ir.schema.json
    gate-report.schema.json
  evaluators/
    structural/
    semantic/
    invariant/
  workflow-extraction/
  benchmark/
    manifests/
    golden/
    mutations/
    runner/
  calibration/
  reports/
```

Keep sensitive business requirements, customer data, proprietary source examples, and evaluation evidence out of a public repository. Use synthetic fixtures or approved internal storage and avoid committing secrets to reports or benchmark manifests.

## 14. Proposed engineering sequence

1. Inspect the existing command scaffolding and approval workflow; persist original intent and implement the intra-command checkpoint. Agree on the gate boundaries, supported BPMN modeling profile, obligation taxonomy and verdict policy.
2. Establish a reviewed golden artifact chain and a small defect suite for each gate.
3. Prototype exporting the executable Graphite workflow into a normalized graph. Compare it against approved BPMN for a known conformant workflow and a deliberately misrouted transition.
4. Implement deterministic structural checks and normalize their outputs using the common finding contract.
5. Implement isolated semantic evaluators, validate evidence references, and compare evaluator configurations.
6. Add scenario-based execution and invariant verification. Clarify what is proved versus what is only tested.
7. Integrate verdict aggregation, protected authorization records and negative enforcement tests.
8. Run the framework in shadow mode, measure false acceptance and operational cost, calibrate the policy, and seek risk-owner approval before making probabilistic checks authoritative blocking controls.

## 15. Decisions requiring alignment

- How does the existing spec finalization/approval state work, where is the original PRD stored, and what enforceable phase boundary can the harness support?
- Which BPMN constructs are supported by the framework, and which require explicit human review?
- Can Graphite export the effective executable graph, including conditions, configuration-driven transitions and relevant runtime semantics?
- What implementation abstractions and behavior-preserving transformations are permitted during graph normalization?
- Who owns business invariant definitions, ground-truth labels, criticality, and adjudication?
- What false-acceptance tolerance and statistical evidence are necessary for each gate?
- Where is the non-bypassable enforcement boundary in the current authoring and delivery architecture?

The proposal is to make conformance a first-class engineering control within spec-driven development, not simply another LLM verification command. The architecture combines deterministic evidence where possible, calibrated semantic evaluation where necessary, and an explicit authorization policy at each transformation boundary.


---

## 16. Detailed evaluation and real-transaction benchmark specification

### 1. Three different things being evaluated

Do not conflate the authoring system's ability to generate a conformant artifact, the conformance evaluator's ability to detect defects, and the generated application's runtime behavior. Measure all three. A gate verdict applies to the exact artifact snapshot and the obligations due at that gate; it does not certify every future execution. Gate 1 still runs inside `propose-design` after the final spec approval and BPMN reconciliation. Gate 2 authorizes `apply`; Gate 3 authorizes protected delivery. Both FAIL and HUMAN_REVIEW block the corresponding next phase.

### 2. Gate-specific dimensions and evidence

Each row defines an evaluation dimension (not an arbitrary weight). Derive atomic obligations independently from the effective intent and applicable platform policy, then link each dimension to checks and evidence. Count each mandatory obligation once in the gate aggregate, even when several evaluators assess it. Report each dimension separately. Define mandatory/advisory status before running evaluation. A bidirectional mapping is required to detect both omissions and invented behavior. Human review is required for missing source truth, unsupported constructs, or genuinely unresolved semantic findings.

| ID / Gate | Dimension | Measure / evidence | Example defect |
|---|---|---|---|
| G1.1 | Intent baseline and approval integrity | Required baseline/clarification/approval checks satisfied; artifact hashes and authorization | Edited approved spec, missing PRD, unauthorized amendment |
| G1.2 | Requirement completeness | Satisfied source requirements / applicable approved source requirements; citations into spec | Dropped eligibility rule |
| G1.3 | Semantic correctness and scope soundness | Supported target obligations / applicable target obligations, with independent source evidence; contradictions and hallucinations counted | Reversed predicate, invented fee |
| G1.4 | Spec quality and testability | Valid required scenario fields / applicable fields; measurable acceptance criteria, explicit assumptions, unresolved blocking questions | Ambiguous threshold |
| G1.5 | BPMN structural integrity | XML/schema and graph checks, valid endpoints, reachability, supported gateways, loop/termination claims where supported | Dangling transition, disconnected node |
| G1.6 | BPMN semantic fidelity and path coverage | Mapped required scenarios / expected scenarios; guarded paths checked for intended and forbidden behaviors; independently derived expected scenarios | Missing reject branch or wrong gateway |
| G1.7 | Invariant capture | Correctly specified invariant obligations / approved invariant obligations; enforcement scope and data dependency defined | Missing invariant or unknown schema dependency glossed over |
| G2.1 | Requirement realization | Approved requirements satisfied by design / applicable requirements; source-to-design links and evidence | Design omits authorization |
| G2.2 | Design fidelity and cross-artifact consistency | Satisfied semantic constraints / applicable constraints; proposal/design/tasks consistent with spec and BPMN | Architecture contradicts retry semantics |
| G2.3 | Task coverage and dependencies | Required implementation/test work mapped / required work; invalid references and dependencies; not just checkbox count | Missing negative test |
| G2.4 | Technical feasibility and failure handling | Applicable platform/contract/error/recovery constraints satisfied; evidence from real SDK and dependencies | Unsupported Graphite construct |
| G2.5 | Invariant enforceability and test strategy | Invariants with sufficient enforcement, runtime decision point, evidence plan and failure action / applicable invariants | LLM controls irreversible side effect without guard |
| G2.6 | JIT input contract readiness | Required policies for schema acquisition, validation, compatibility, timing, trust and unavailable inputs satisfied | Missing policy for schema drift |
| G3.1 | Architectural traceability | Required business nodes mapped / required nodes; ArchUnit or equivalent checks | Missing node annotation |
| G3.2 | Structural/control-flow equivalence | Node/edge precision and recall, reachability, gateway/join/exception semantics from actual executable graph | All tags intact but wrong transition |
| G3.3 | Node/predicate semantic fidelity | Satisfied node behavior and guard obligations / applicable obligations; source/target evidence, tests | Reversed condition with correct topology |
| G3.4 | Behavioral scenario conformance | Expected business scenarios independently exercised / applicable scenarios; expected vs observed outcomes, traces, side effects; distinguish test coverage from test success | Happy-path-only testing, incorrect terminal state |
| G3.5 | Code-enforced invariant assurance | Required invariant implementation obligations satisfied; proof/static/transactional/test evidence as required | Duplicate disbursement, race |
| G3.6 | Inference-enforced invariant assurance | Runtime inference policy and guard integration verified; labeled inference cases measured for accuracy/recall/unsafe acceptance and evidence | Model accepts unsupported conclusion |
| G3.7 | Data/JIT-schema-dependent invariant assurance | Runtime adapter/contract/validation/evidence and failure behavior verified against representative snapshots, missing/stale/malformed/drift cases | Evaluates against stale file/schema |
| G3.8 | Verification and release evidence | Required tests executed and passed, exact source/build/config/model/policy provenance, no stale or bypassed authorizations | Changed implementation after PASS |

Do not count absence of an evaluator finding as conformance. For an inventory of expected paths, use bounded exploration or formal reachability/model checking appropriate to the supported BPMN subset; parallel interleavings and loops need an explicit bound or property-based reasoning. A path count without a trustworthy expected denominator is diagnostic only. For normalized graph comparisons, match transitions using identities, endpoints and supported transition semantics rather than merely matching source and target node pairs when multiple edges are possible. Compare against the actual executable definition with no dependency on the intended BPMN in the actual-graph extractor.

### 3. Invariant taxonomy: enforcement and evidence are separate axes

An invariant is a business property with a scope, trigger, predicate, required evidence and consequence when violated or unknown. The categories below are not mutually exclusive. A single invariant may need data acquisition, inference, and deterministic enforcement. Store the classification as two axes: `executionMechanisms` (CODE, LLM_INFERENCE, DATA_DEPENDENT; multiple allowed) and `evaluationMethods` (STATIC, DETERMINISTIC_TEST, FORMAL, SEMANTIC_JUDGE, LABELED_INFERENCE_EVAL, RUNTIME_TRACE, DATA_CONTRACT, HUMAN). Criticality and when the obligation is due (G1, G2, G3, RUNTIME) are independent attributes. Do not automatically use an LLM judge simply because a business action uses an LLM.

| Category | Gate 1 | Gate 2 | Gate 3 (pre-delivery) | Runtime |
|---|---|---|---|---|
| Code-enforced | Capture exact predicate and scope | Define guard, transaction boundary, recovery, tests | Verify actual enforcement; boundary, negative, failure, concurrency/property tests and stronger proof when required | Assert before side effects; audit violation; enforce atomicity/idempotency |
| LLM-inference-dependent | Identify semantic judgment and acceptable outputs, grounding and abstention expectations | Choose model/evidence/rubric, structured output, independent guard or human escalation | Benchmark actual inference and decision guard against SME labels, red-team and repeated trials; test malformed output/timeout | Validate output/evidence, apply calibrated policy and deterministic allow/deny/abstain guard before action |
| Data-dependent / just-in-time schema | Capture required facts, source/owner, timing, semantic field meaning and unknown behavior | Define schema acquisition/authorization, mapping, versions, validation, snapshot/freshness and compatibility policy | Test adapters with representative approved file snapshots, alternate schema versions and hostile/missing inputs; verify gating/instrumentation | Resolve approved file and schema as of transaction time; validate schema and data, evaluate predicate, bind finding to exact input/version; fail closed or route to review if unresolved |

Examples are illustrative; map to actual business transaction requirements instead of making up business policy. CODE: no transaction may commit twice for the same idempotency key. LLM_INFERENCE: a free-text reason must be supported by the supplied evidence under an approved rubric (a model's confidence alone is not evidence). DATA_DEPENDENT: a transaction must satisfy an eligibility/limit rule using the authoritative file and schema effective at the relevant instant. HYBRID: extract the relevant evidence with an LLM, validate against a trusted schema, and allow the transactional side effect only through a deterministic guard. An inherently semantic rule must not become a deterministic assertion merely because the LLM returns JSON.

**Data/JIT design:** Define a trusted schema resolver or contract (source, schema ID/version or digest, effective interval, semantic mapping, authorization) separately from raw file input. A schema inferred from a file/LLM is provisional until validated against approved semantics; validating against a self-invented schema is circular. For each transaction, capture `transactionId`, event time, source/locator and snapshot version or file digest, schema identity/digest, resolver version, freshness and validation outcomes, selected fields or redacted evidence refs, invariant ID, actual result and action. Keep raw sensitive data out of Git and prompts unless specifically authorized. Test syntactically valid but semantically wrong files, missing required fields, incompatible type/unit/effective-date changes, stale/late data, duplicates, corrupt files, schema/data mismatch, unavailable dependency, and unauthorized source. No silent defaults. For time-sensitive data or updates between validation and action, bind the decision to the exact snapshot and revalidate or use an atomic operation as required. Replay using the as-of snapshots rather than present-day values.

**Important lifecycle distinction:** Before release, G3 can assess that the runtime invariant enforcement mechanism is correctly implemented and validated using representative data and tests. It cannot assert satisfaction of an invariant for a future transaction whose real file or schema does not yet exist. Represent these as two linked obligations: the mandatory G3 `ENFORCEMENT_READINESS` obligation and the mandatory per-transaction `RUNTIME_SATISFACTION` obligation with a trigger and guard. The latter is not due at G3 only when the approved business policy permits deferral; it remains explicit in the report. If a file/schema is already required for G3 evidence, its absence is HUMAN_REVIEW. Do not mark it satisfied or simply omit it. A G3 PASS is not a runtime PASS. At runtime, only authorized PASS can enable the protected side effect; FAIL or HUMAN_REVIEW prevents it (or follows another explicitly authorized safe outcome), including missing schema, data or inference evidence. This is a runtime enforcement control in addition to the three authoring gates, not a relocation of Gate 3. If current scope does not permit runtime integration, report that gap and do not claim certification of runtime-dependent invariants.

### 4. Evaluation contracts and score calculation

Version a registry of `obligationId`, `gate`, `dimensionId`, `phaseDue`, `sourceRefs`, `criticality`, `mandatory`, `applicabilityRule`, `acceptancePredicate`, `executionMechanisms`, `evaluationMethods`, `evidenceRequirements`, `dependencies`, and `failureAction`. Evaluate applicability independently, and record justified NOT_APPLICABLE/NOT_DUE separately. An unclassified obligation cannot be silently dropped. Separate checks from obligations: multiple checks produce one consolidated obligation status using a predefined evidence policy. Findings contain status, check/evaluator/model/prompt versions, input and output evidence revisions, citations or counterexample, timestamp, and reason codes. Missing mandatory check or untrusted/incomplete evidence = INCONCLUSIVE unless another valid check conclusively establishes violation; a verified counterexample wins. Never count judge votes as separate obligations.

For each gate and dimension, let `N=S+V+U` applicable mandatory obligations due now; `S` satisfied, `V` confirmed violated, `U` inconclusive (including missing/unexecuted). Compute:

- confirmed conformance `C = S/N`; evidence coverage `E = (S+V)/N`; uncertainty `U/N`; violation rate `V/N`.
- trace/requirement recall `matched approved obligations / expected obligations`; precision `supported target obligations / target obligations`; use directional metrics where appropriate. Node/edge precision and recall use the same definitions on normalized graph entities.
- scenario coverage `distinct required scenarios exercised / required scenarios`; outcome success `scenarios with verified expected outcomes / exercised scenarios`. Report missing scenarios, forbidden-path counterexamples and runtime data/inference cases separately. Do not claim exhaustive coverage outside the supported domain/bounds.
- invariant enforcement coverage `verified mandatory enforcement-readiness obligations / applicable readiness obligations`; runtime satisfaction rate `satisfied due invariant instances / all due invariant instances`; also report runtime inconclusive and violations. Runtime denominator is invariant instances keyed by transaction ID and invariant ID, not number of source files or judge votes.
- Optional advisory or weighted diagnostic scores may be reported separately with versioned weights and rationale. Never use an aggregate to compensate for a mandatory failure. Zero denominator is N/A, never an automatic 100%; empty mandatory scope requires independently validated applicability. Do not average the three gate scores or interpret `C` as probability of correctness.

Gate policy (deterministic, versioned, independently testable): missing final approval means NOT_READY and design cannot begin. For a ready gate, confirmed mandatory violation -> FAIL; otherwise any mandatory obligation unresolved, evidence stale/untrusted, material disagreement unresolved, extraction incomplete, or applicable calibrated confidence policy unmet -> HUMAN_REVIEW; otherwise PASS when all mandatory obligations are satisfied and evidence/policy/authorization checks pass. Technical failures use explicit reason codes and block. Shadow verdicts are never release authorization. Human review needs auditable resolution and rerun; exceptions require an explicit separate authorized policy and cannot be a silent PASS. Record artifact/approval/policy hashes, applicable counts, dimension scorecard, unresolved obligations, semantic calibration support, verdict and action. Test decision table including 99% conformance with one critical failure, 100% reported satisfaction with an untrusted evidence dependency, N=0, duplicate checks and missing outputs.

### 5. Metrics to measure the evaluators, authoring pipeline and runtime inference

For the benchmark, use independently labeled obligations, defects and expected gate verdicts. Report raw numerator/denominator, confidence intervals where valid, and stratification by gate, dimension, severity, invariant category, model/config version, workflow family, complexity and schema/data version. Use positive = actual defect when computing detection precision/recall. Do not treat a REVIEW as a confirmed detection; distinguish it from prevention of unsafe progression. Report a three-class confusion matrix (expected vs actual PASS/FAIL/REVIEW) for each gate, plus separate NOT_READY/technical error counts if applicable.

| Metric | Definition |
|---|---|
| Gate error: false acceptance | Known nonconformant cases actually PASS / known nonconformant cases |
| Unsafe progression | Expected FAIL or REVIEW actually permitted to progress / expected FAIL or REVIEW cases; separately report unsafe PASS vs enforcement bypass |
| Critical escape | Critical-defective cases allowed / critical-defective cases; also report defects by invariant ID |
| False rejection | Expected PASS cases actually FAIL / expected PASS cases |
| Unnecessary review | Expected PASS cases reviewed / expected PASS cases |
| Defect precision, recall, F1 | TP/(TP+FP), TP/(TP+FN), 2PR/(P+R); match defects to labeled obligation IDs and evidence; unmatched findings are false positives after adjudication |
| Gate accuracy and automation | Correct three-way verdicts / labeled cases; definitive automated PASS or FAIL / eligible cases |
| Review rate and approved residual risk | REVIEW / eligible cases; defective PASS / all PASS (depends on sample prevalence) |
| Verdict stability | Same-case repeat agreement (report pairwise agreement or fraction all repeats identical and definition); inter-judge agreement reported separately |
| Calibration | Reliability plot by predicted-probability bin, observed correctness, sample counts, Brier score = mean((p-y)^2) for defined binary outcome, ECE = frequency-weighted absolute bin gap; gate-level PASS reliability separately |
| Runtime invariant enforcement | Actual violations blocked / known violating runtime events; violating events allowed / known violating events; due invariant instance completeness; unavailable-data and stale-schema rates; false blocks and runtime review |
| Runtime LLM inference | Class-wise precision/recall/F1 and confusion matrix on SME labels, abstention rate, evidence citation correctness/groundedness, unsafe inference acceptance, stability across repeats and model/prompt versions; numeric extraction exact/ tolerance match if applicable |
| Data/schema contracts | Schema retrieval success, required-field validity, freshness/compatibility compliance, mismatch detection recall, unavailable-source rate; separate business-data truth from schema validity |
| Authoring system | First-attempt gate pass rate, final pass rate after bounded remediation, requirement/defect counts by stage, clarification rounds, remediation attempts, generated tests vs independent oracle results, full-chain safe delivery rate |
| Operations | Evaluation and full-chain p50/p95 latency, token input/output, actual model/tool cost when available, timeout rate, human review effort; report runtime overhead separately |

An escaped defect at Gate 1 might cause Gate 2 and Gate 3 to agree with its incorrect spec. Test end-to-end against original effective intent, not only against the previous artifact. Report conditional performance among cases reaching each gate and separately isolated gate performance using valid frozen predecessor artifacts. Report blocked/not reached explicitly. A system that blocks everything has zero escapes but no useful automation, so report both risk and coverage.

### 6. Calibration and configuration selection

A score is not calibrated confidence. Compare current verify, deterministic only, deterministic + one isolated LLM judge, + two/+ three independent judges, and adaptive escalation. For G3 ablate tagging, reverse extraction, semantic and runtime checks. Use same frozen cases and versioned rubric for fairness. Judges see source, target and obligation evidence, not author history or other initial votes. Support findings with verifiable citations/counterexamples; unresolved disagreement routes to review. Never use the authoring model as the sole source of ground truth. Record raw judge signals, evidence completeness and observed outcome; initial empirical buckets may use agreement pattern, check family and evidence quality. An estimate of P(conclusion correct | evidence pattern) needs labeled calibration data; calibrate automatic PASS risk directly at gate level (or explicitly validate aggregation), not by averaging per-obligation probabilities. Distinguish runtime inference calibration from evaluator calibration and from authoring success. Use separate development, calibration and held-out workflow families (and tenant/time/schema versions where applicable); no label leakage or repeated cases counted as independent. Use prospective real prevalence to estimate approved residual risk; defect-rich tests estimate conditional detection, not deployment prevalence.

Choose policies on calibration data by minimizing review/cost subject to risk-owner-approved limits on critical escapes and false acceptance, then test untouched held-out cases. With zero observed false accepts in n independent representative known defective cases, the exact one-sided 95% upper error bound is `1 - 0.05^(1/n)` (approximately `3/n`); ~300 such cases bound error around 1%, not a guarantee. For nonzero errors use an appropriate interval; clustered mutations/repeats need dependence-aware analysis. Insufficient samples mean uncalibrated, not 100% confidence. Do not invent 90/95/98% thresholds; provisional policy may run in shadow/review only. Deterministic checks still need benchmarked correctness and coverage. Compare performance by dimension and risk stratum, not just pooled mean.

### 7. Real-world end-to-end conformance benchmark — two complementary tracks

The actual repository paths, data contracts and business rules have not been supplied to this handoff. Discover them in the authorized local repo or request the exact PRD, transaction samples, source files and JIT schema providers; do not invent domain requirements. Start with one real, approved, versioned business PRD and expand to multiple distinct workflow families. Use a sandbox/worktree and approved, de-identified representative transaction/file snapshots. Never run live financial operations, mutate production data, or upload proprietary PRDs/files to an unapproved model. If real inputs are unavailable, label synthetic substitutes and report the real-data track as blocked.

**Track A — isolated gate benchmark (fixed artifacts):** Obtain the real PRD and authorized clarifications and have business/engineering SMEs create a requirement/invariant oracle, scenario inputs, expected outputs and forbidden side effects independently of the generated files. Capture a clean reviewed artifact chain (including one or more valid alternative implementations), approval provenance and expected verdicts. Freeze it. For each gate inject a single known defect only in the target artifact, keeping prior artifacts and approvals valid as appropriate; label expected outcomes and target obligation IDs. Add combinations, equivalent refactors, genuinely unresolved inputs and naturally observed defects. Run evaluator configurations on the identical frozen cases. This isolates detection from generation quality. For G1 exercise mutations after finalization, ensure authorized approval references the intended test snapshot (or deliberately stale approval if that is the defect), and test clarified intent and BPMN synchronization. For G3 mutate actual executable transitions and node logic while keeping annotations intact; run independent behavioral tests, not only generated unit tests. Include schema/data and runtime-inference mutations, including failures with unchanged graph structure.

**Track B — end-to-end actual authoring (real PRD -> newly generated code -> sandbox execution):**

1. Capture exact authorized PRD bytes/prose, source commit, config, model/prompt version, workflow family and run ID. Preserve baseline independent of Claude memory. Store private evidence under approved access; commit only de-identified manifests/fixtures as allowed.
2. Run the actual customized `propose-intent` command to generate draft spec/BPMN. Use scripted SME-approved answers only for repeatability, while preserving the true clarification/approval boundary. No fake production authority; use a test approver in the sandbox.
3. Start actual `propose-design`, resolve questions and obtain approval of exact finalized spec, reconcile BPMN, run G1, capture findings, raw dimensions, verdict and enforcement trace. If blocked, record and stop for a first-attempt run. For remediation track, explicitly repair and rerun on a new snapshot. No force-pass to collect downstream data; use Track A for isolated downstream testing.
4. On G1 PASS generate actual proposal/design/tasks, then run G2; only pass may invoke actual `apply`. Measure newly generated Java and generated tests; run build, component tests and verify. Use independently authored scenario/invariant oracles, not just tests generated by the same agent. Run G3 with actual workflow extraction and reverse comparison, node semantics and enforcement-readiness checks.
5. If allowed in the sandbox, execute the generated workflow with real representative business transaction snapshots; resolve actual approved JIT schemas and files as of the transaction time (or replay versioned snapshots), invoke the real approved inference integration for inference-dependent cases, use safe stubs only for irreversible external actions, and capture execution traces, results and attempted side effects. Test both nominal and fault-injected input cases. Compare observations to the independent oracle. Confirm runtime FAIL/REVIEW blocks side effects. Distinguish actual inference, live-but-authorized data access, replay, and mocks in evidence. No production deployment.
6. Repeat using controlled versions and distinct run IDs in clean worktrees, keeping the oracle fixed and evaluator configurations recorded. Track first-attempt and final safe pass rates, variance, remediation cost and stage where defects originate/caught. Repeated generations from one PRD measure stochastic behavior, not independent population size. If model cannot be pinned exactly, record available identity and timestamp. Label natural defects through SME adjudication before scoring.
7. Compare pipeline with and without the new framework in an isolated shadow-only baseline (same input families/config where possible); never disable production controls. Compare overall safe delivery and actual defect escapes, not just gate decisions. Report blocked downstream stages and effect of review, cost and latency. Select a pilot subset with risk owner approval before rollout.

Minimum initial cases (adapt expected rules to the PRD): correct nominal flow; boundary condition and negative condition; clarified business rule; missing or invented requirement; correct alternative implementation; same tags but invalid edge; correct graph but wrong code predicate; missing invariant guard; duplicate/retry/concurrent request; inference supported vs unsupported evidence, ambiguity, malformed response and timeout; real file/schema version A and approved version B; missing/stale/incompatible file or schema; semantic field/unit mismatch; valid schema with invalid business data; unavailable runtime dependency; invalidation after source/approval/data changes. Include attempted production side effect simulation and assert no external call is made on FAIL/REVIEW. Plan at least a small pilot with one real approved PRD and multiple transaction fixtures; expand across families, data contracts and risk categories before calibration/certification. No sample counts presented as empirical results.

### 8. Evidence artifacts and reporting expected from implementation

Machine-readable artifacts (names conceptual; align with repo): `obligation-registry.json`, `gate-policy.yaml`, `dimension-metrics.json`, `gate-report.json`, `calibration-profile.json`, `benchmark-manifest.jsonl`, `benchmark-results.jsonl`, `runtime-invariant-results.jsonl`, aggregate CSV/Markdown scorecards and a reproducible command/runbook. Benchmark manifest fields: caseId, runId, familyId, gate or runtime phase, source/revision hashes, data/schema version IDs, expected verdict (or NOT_READY), expected defect IDs/criticality, oracle refs, injected/natural/control variant, actual evaluator profile, observed verdict, enforcement observation, duration/tokens/cost, evidence refs and adjudication. Keep labels inaccessible to evaluators. For each dimension emit applicable/satisfied/violated/inconclusive/not-due counts, value/numerator/denominator, status, evidence coverage, calibration status and reason codes. Show runtime readiness vs transaction satisfaction separately. Record actual observations only; absent metrics are UNMEASURED with reasons. Separate benchmark-run outcomes from gate-policy authorization and preserve exact artifact hashes. No fabricated results.

Illustrative scorecard: G3 has 40 due mandatory obligations, 38 satisfied, 1 confirmed code invariant violation, 1 inconclusive JIT adapter readiness. Conformance 38/40=95%, evidence coverage 39/40=97.5%, unresolved 1/40=2.5%, verdict FAIL, protected delivery blocked. Separately two future transaction properties are not due at G3 under an approved deferral policy; report them as runtime obligations, not as satisfied. If the violation were fixed while the required JIT readiness evidence remained missing, verdict HUMAN_REVIEW. With all due obligations and policy satisfied, G3 PASS only certifies the snapshot/readiness; a later transaction with a missing required schema is runtime REVIEW and cannot proceed through its protected action.


---

## V7 mandatory reporting and benchmark contract

This is the authoritative refinement to the prior I=E design. Apply it to Gate 1, Gate 2 and Gate 3 independently. A gate is an executable control, not a quality dashboard. The current artifact can progress only on a current, valid PASS issued by the gate policy and verified at the protected boundary. Benchmark results qualify the evaluator/configuration for use; they do not authorize an individual change. A benchmark case's expected label is never an input to the live evaluator or verdict engine.

## 1. Execution boundaries and report timing

| Gate | Trigger and inputs | Protected next phase |
|---|---|---|
| G1 | Inside propose-design, after human approval of finalized spec and reconciliation of BPMN. Original persisted PRD plus authorized clarifications/amendments, final spec/BPMN, approval provenance | Technical proposal/design/tasks generation within the same command |
| G2 | After technical design artifacts are generated; current G1 authorization and exact approved spec/BPMN, proposal/design/tasks | Apply / code generation |
| G3 | After actual Java implementation/build/test/verify; current upstream authorizations, approved artifacts, executable workflow and independent test evidence | Protected downstream delivery (e.g. CI release authorization, exact boundary to discover) |

At each reached gate, freeze input revisions, evaluate due obligations, aggregate evidence, calculate scores, resolve confidence and apply policy. Persist immutable attempt-specific findings, dimension scorecard and verdict atomically before issuing a PASS authorization. Record actual enforcement at the boundary, including rejected attempts. For benchmark runs, join the private expected label to the observed gate result only after the decision and record a case-level benchmark result immediately; update the gate-specific aggregate report for that run. Finalize it when that gate's benchmark batch completes. Do not delay normal gate authorization to compute aggregate benchmark statistics; a previously validated policy/profile or explicit pilot policy controls authorization. If reporting or authorization persistence fails, deny continuation. No cross-gate score or global verdict can override a blocked gate.

Execution status and verdict are separate. `NOT_EXECUTED` means an upstream block prevented entry; `NOT_READY` means the prerequisite/approval was absent at the attempted entry; neither is a conformance verdict. A started evaluator with missing evidence or technical failure yields HUMAN_REVIEW unless a confirmed mandatory violation establishes FAIL. Record the reason and deny progression. Human adjudication supplies evidence or approved requirement change and reruns; it is not an arbitrary override. Benchmark mode labels are `PASS`, `FAIL`, `HUMAN_REVIEW` on ready cases, with additional readiness/enforcement cases tracked separately. Persist downstream NOT_EXECUTED placeholders in the lifecycle ledger, not fake conformance scores or verdicts. Across remediation attempts preserve the first outcome and all subsequent results under distinct attempt IDs; do not overwrite failures.

## 2. Independent gate and end-to-end modes

**ISOLATED_GATE:** select a gate, freeze independently validated predecessor artifacts and approvals, inject or select known defects at the target gate. Run its actual evaluator + deterministic decision policy and exercise a test-only protected operation. The test harness may provision approved predecessor fixtures in an isolated worktree; it cannot disable or mint real production authorization. Compare with independently labeled obligations, expected verdict, required block/allow and forbidden effects. Generate a separate report for each gate even if another gate fails a different test. Positive cases must include equivalent representations/refactors. Negative cases include a single defect, combined defects and natural real authoring errors. Include unresolved/ambiguous cases, schema failures and technical errors.

**END_TO_END:** ingest a real authorized PRD; execute actual propose-intent, propose-design clarification/approval and G1, design and G2, apply/verify and G3 in sequence. No bypass. Record an independent case result at each reached gate; independently adjudicate whether each frozen output matches effective original intent (not merely its predecessor), including authoring errors propagated across gates. On block record downstream NOT_EXECUTED and reason. A remediation experiment uses a new attempt and rechecks affected approvals/revisions. After G3 PASS, execute newly generated code in a safe sandbox with authorized representative transaction/file snapshots, actual approved inference, as-of trusted JIT schema resolution and no irreversible effects. Capture runtime invariant instance results separately, not as a fourth authoring gate. If real data/model/SDK is unavailable, report BLOCKED and keep synthetic/mocked experiments distinct.

End-to-end results at G2/G3 are conditional on reaching that gate. Do not pool with isolated results for certification. Report both a progression funnel (eligible, reached, completed, pass, fail, review, not-ready, not-executed) and gate-local metrics. First-attempt and final-after-remediation are separate cohorts. Report counts of unique workflow families and repeated runs. Synthetic mutation clusters and repeated model calls are not independent population samples.

## 3. Mandatory output layout

Use equivalent paths in the actual repo; retain the following logical separations. Reports are run- and attempt-scoped; never overwrite. JSON is authoritative; Markdown is an accessible rendering. Access-controlled stores hold private data and evidence; Git stores only allowed redacted references.

```text
conformance/<change-id>/<run-id>/
  gate-1/<attempt-id>/{findings.json,evidence.json,dimension-scores.json,verdict.json,conformance-report.md}
  gate-2/<attempt-id>/{...same contract...}
  gate-3/<attempt-id>/{...same contract...}
  lifecycle-summary.json
benchmarks/<experiment-id>/<mode>/<evaluator-config-id>/
  gate-1/{case-results.jsonl,confusion-matrix.json,metrics.json,benchmark-report.md}
  gate-2/{...same contract...}
  gate-3/{...same contract...}
  progression-funnel.json  # end-to-end only
  runtime/{case-results.jsonl,metrics.json,report.md}  # if reached and authorized
  summary.md               # cross-gate visibility, not authorization
calibration/<gate>/<config-id>/<profile-version>/
  profile.json             # immutable validated profile, support counts, split IDs
  certification-report.md  # risk limits, uncertainty, coverage, held-out assessment
```

Authorization remains in the trusted policy/enforcement store, bound to gate, change/run/snapshot IDs, upstream verdict digests, approved inputs, policy/evaluator/config versions, scope and freshness; verify current hashes at use. Prevent TOCTOU using immutable snapshots/transactional checks. A mutable report file is not itself permission to proceed. Gate and benchmark service identities should be distinct; label store is unavailable to author/evaluator. Benchmark reports may link to the verdict digest; never write or mutate that verdict.

## 4. Metric contract per gate

For every metric return `{metricId, value, numerator, denominator, unit, status, reason, cohort, gate, dimension, configId}`. Use null/NOT_APPLICABLE for undefined zero-denominator metrics and null/UNMEASURED for unavailable data. Never substitute 0 or 100. For latency/quantile/calibration metrics include sample count and method instead of a misleading ratio. Each scorecard includes obligation counts S/V/U and not-due/not-applicable counts; deduplicate checks to one obligation. Define N=S+V+U for applicable due mandatory obligations; conformance=S/N, coverage=(S+V)/N. Report dimensions G1.1–G3.8 from the context and directional precision/recall for traceability, graph and coverage. Report invariant mechanism, evidence type and due phase separately. A missing required obligation must not vanish from N. The policy may use calibrated evidence reliability for probabilistic checks, but a confirmed mandatory violation always FAILs regardless of aggregate score or majority vote.

For each gate and each isolated or end-to-end cohort publish all of the following, including absolute counts:

| Metric | Numerator / denominator or definition |
|---|---|
| Three-way verdict matrix | Expected PASS/FAIL/HUMAN_REVIEW by actual PASS/FAIL/HUMAN_REVIEW on labeled ready completed cases; publish missing/error/not-ready counts outside matrix |
| False acceptance | Known FAIL cases receiving PASS / all known FAIL cases attempted (report technical/noncompleted counts and completed-only rate too) |
| Unsafe progression | Expected FAIL or HUMAN_REVIEW cases actually allowed / all expected FAIL or HUMAN_REVIEW cases attempted; separate wrong PASS from bypass |
| Critical escape | Known critical-defective cases actually allowed / known critical-defective cases attempted |
| False rejection | Expected PASS cases returning FAIL / expected PASS cases attempted |
| Unnecessary review | Expected PASS returning HUMAN_REVIEW / expected PASS attempted |
| Defect precision / recall / F1 | Match adjudicated findings to labeled defect IDs; TP/(TP+FP), TP/(TP+FN), harmonic mean; REVIEW is not defect detection by itself |
| Accuracy | Exact three-way matches / labeled ready completed cases; also report completion coverage |
| Automation / review | PASS or FAIL / ready attempted; HUMAN_REVIEW / ready attempted; report uncompleted separately |
| Stability | Same-case repeated verdict agreement (state definition), separate inter-judge agreement |
| Calibration | Gate-level automatic PASS correctness and risk bounds; reliability bins, support counts, Brier score and ECE for a defined probabilistic outcome; no probability when uncalibrated |
| Operational measures | p50/p95 latency, tokens, cost, human effort, evaluator errors, remediation; store observation count and provenance |

Break down by gate, dimension, defect type, severity, workflow family/complexity, invariant mechanism, schema/config version and real/synthetic/replay/mock provenance. Report per-gate and per-configuration certification separately from per-artifact verdict. Compare isolated configurations on same held-out cases, with independent development/calibration/holdout families. Set decision thresholds based on calibrated risk-coverage trade-off and approved false-acceptance/critical escape bounds. Report uncertainty and sample support; no invented thresholds or fake measured values. At runtime measure actual inference classification, grounding, abstention, contract/data quality and transaction-level invariant escapes separately from G3 readiness.

## 5. Worked illustrative case (not measured)

| Gate | Expected | Actual | Allowed? | Interpretation |
|---|---|---|---|---|
| G1, run A | PASS | PASS | Yes | approved spec and reconciled BPMN satisfy due checks |
| G2, run A | FAIL | FAIL | No | design omits mandatory idempotency guard, even if other 19/20 obligations satisfied |
| G3, run A | not reached | NOT_EXECUTED | No | do not count as correct verdict, or as a failed implementation |
| G3, isolated run B | FAIL | PASS | Yes (test stub) | all annotations intact, wrong executable edge escaped; unsafe progression and false acceptance increment |
| G3, isolated run C | PASS | PASS | Yes (test stub) | correct graph and all readiness obligations satisfied; future data-dependent properties still due at runtime |

No benchmark labels should be visible to the gate when it produces these outcomes. A G3 FAIL fixture in isolation uses a valid frozen G1/G2 predecessor. No actual delivery occurs in the test sandbox.

## 6. Required implementation acceptance tests

1. Each ready gate emits a complete conformance report and independent verdict with scores and validated evidence. Fixture expected PASS/FAIL/REVIEW for every gate. Gate 1 runs at the intra-command boundary, after spec approval; no premature design writes.
2. Benchmark runner emits case result per reached gate and separate aggregate G1/G2/G3 reports with the same metric definitions. Verify expected labels are excluded from evaluator context and reports cannot authorize delivery.
3. G1 FAIL and REVIEW block design; G2 blocks apply; G3 blocks delivery; timeouts, malformed output, report write failure, missing evidence and stale snapshot block. Test actual protected invocation including direct invocation within trust boundary. Record attempted vs allowed operations.
4. In end-to-end run, G1 FAIL -> G2/G3 NOT_EXECUTED; G2 FAIL -> G3 NOT_EXECUTED. No downstream phantom scores or labels in confusion matrix. Test pass-all run and blocker remediation under new attempt IDs. Validate all cohort denominators manually on a small known fixture.
5. Isolated G3 cases run independently using validated upstream fixtures regardless of failures in separate G1/G2 cases. Mutate actual executable graph while annotation tags remain correct; distinguish node semantics and runtime invariant checks.
6. Distinguish actual real code generation, representative transaction replay, approved real model inference and synthetic fakes. Missing JIT file/schema or ungrounded inference blocks the runtime action; future not-due properties do not count as satisfied at G3.
7. Calibration records are versioned per gate/config and benchmark cohort. A changed rubric/model/checker invalidates applicability until reviewed/revalidated. Uncalibrated semantic decisions requiring calibration cannot auto-pass production. Verify 99% conformance with a mandatory violation fails, unresolved obligations review, zero denominators nonnumeric, and audit trail reproducible.

## 7. Decisions still required from the repository and risk owners

Discover the actual Graphite executable DAG introspection API, supported BPMN subset, intra-command protection, CI trust boundary, approved models, real PRDs, transaction access, schema resolver, and independent SME oracle. Proposed layout and field names can adapt to existing conventions; semantic requirements and blocking boundaries cannot. Neither these design documents nor illustrative fixtures are empirical certification. Do not claim production readiness or implement live financial side effects.


## Visual references

- [Authoring lifecycle and independent reports](diagrams/lifecycle.svg)
- [Gate engine and reporting separation](diagrams/gate-reporting.svg)
- [Isolated vs sequential benchmark modes](diagrams/benchmark-modes.svg)
- [Reverse extraction](diagrams/round-trip.svg)
- [Runtime invariant checks](diagrams/runtime-invariants.svg)


## V7 normative additions — evidence, reasoning, metrics and integration

Read [Evidence and reasoning contract](EVIDENCE_AND_REASONING_CONTRACT.md), [Measurement and execution architecture](MEASUREMENT_AND_EXECUTION_ARCHITECTURE.md) and [Architecture decisions](ARCHITECTURE_DECISIONS.md) (paths relative to handoff root). These supplement, and where wire formats differ supersede, earlier conceptual JSON examples in this file. Use Draft 2020-12 schemas in `schemas/` and coherent examples in `examples/contracts/`; original examples are legacy arithmetic fixtures only. Validate shape and cross-record semantics. Persist structured evidence-grounded rationale (criteria, expected/observed, evidence IDs, assumptions, limitations, verified counterexamples), aggregation rationale and deterministic policy rule trace; do not store hidden chain-of-thought. Use typed evidence fetch requests and responses, versioned manifests, access-controlled storage, actual execution instrumentation, and durable artifact-bound authorization. Reuse native OpenSpec Validate/Verify and benchmark its incremental value; do not assume capabilities of our customized version. Measure authoring, evaluator and application execution time separately. The new prompts `08-evidence-contract-and-audit.md` and `09-native-baseline-and-agentic-loop.md` are required, but run prompt 08 immediately after Stage 1 (before gates) and prompt 09 after Stage 4 (before benchmarks), as described in updated sequence. Implementation must include negative tests for data retrieval, provenance, rationale/reference integrity, policy trace and actual protected progression.
